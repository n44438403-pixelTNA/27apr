
import React, { useEffect, useState, useRef } from 'react';
import { User, ViewState, SystemSettings, Subject, Chapter, MCQItem, RecoveryRequest, ActivityLogEntry, LeaderboardEntry, RecycleBinItem, Stream, Board, ClassLevel, GiftCode, SubscriptionPlan, CreditPackage, SpinReward, HtmlModule, PremiumNoteSlot, ContentInfoConfig, ContentInfoItem, SubscriptionHistoryEntry, UniversalAnalysisLog, ContentType, LessonContent, DeepDiveEntry, AdditionalNoteEntry, TeacherStorePlan, TeacherCode, HomeworkItem, LucentNoteEntry, LucentPageNote, AppNotification } from '../types';
import { List, GraduationCap, LayoutDashboard, Users, Search, Trash2, Save, X, Eye, EyeOff, Shield, Megaphone, CheckCircle, ListChecks, Database, FileText, Monitor, Sparkles, Banknote, BrainCircuit, AlertOctagon, ArrowLeft, ArrowRight, Key, Bell, ShieldCheck, Lock, Globe, Layers, Zap, PenTool, RefreshCw, RotateCcw, Plus, LogOut, Download, Upload, CreditCard, Ticket, Video, Image as ImageIcon, Type, Link, FileJson, Activity, AlertTriangle, Gift, Book, Mail, Edit3, MessageSquare, ShoppingBag, Cloud, Rocket, Code2, Layers as LayersIcon, Wifi, WifiOff, Copy, Crown, Gamepad2, Calendar, BookOpen, Image, HelpCircle, Youtube, Play, Star, Trophy, Palette, Settings, Headphones, Layout, Bot, LayoutDashboard as DashboardIcon, Loader2, Gauge, LayoutGrid, ArrowUpCircle, KeyRound, Award } from 'lucide-react';
import { getSubjectsList, DEFAULT_SUBJECTS, DEFAULT_APP_FEATURES, ALL_APP_FEATURES, STUDENT_APP_FEATURES, DEFAULT_CONTENT_INFO_CONFIG, ADMIN_PERMISSIONS, APP_VERSION, STATIC_SYLLABUS, LEVEL_UNLOCKABLE_FEATURES } from '../constants';
import { fetchChapters, fetchLessonContent } from '../services/groq';
import { runAutoPilot, runCommandMode } from '../services/autoPilot';
import { parseMCQText } from '../utils/mcqParser';
import { generateSecureRandomString, generateSecureRandomId } from '../utils/cryptoUtils';
import { saveChapterData, bulkSaveLinks, checkFirebaseConnection, saveSystemSettings, subscribeToUsers, rtdb, saveUserToLive, db, getChapterData, saveCustomSyllabus, deleteCustomSyllabus, subscribeToUniversalAnalysis, saveAiInteraction, saveSecureKeys, getSecureKeys, subscribeToApiUsage, subscribeToDrafts, resetAllContent, subscribeToDemands } from '../firebase'; // IMPORT FIREBASE
import { ref, set, onValue, update, push, get } from "firebase/database";
import { doc, deleteDoc, setDoc } from "firebase/firestore";
import { storage } from '../utils/storage';
import { SimpleRichTextEditor } from './SimpleRichTextEditor';
import { ImageCropper } from './ImageCropper';
import { DEFAULT_SYLLABUS, MonthlySyllabus } from '../syllabus_data';
import { CustomAlert } from './CustomDialogs';
import { UniversalChat } from './UniversalChat';
import { ChallengeCreator20 } from './admin/ChallengeCreator20';
import { FeatureAccessPage } from './admin/FeatureAccessPage';
import { AdminPowerManager } from './AdminPowerManager';
import { SyllabusManager } from './SyllabusManager';
import { FeatureGroupList } from './admin/FeatureGroupList';
import { ALL_FEATURES } from '../utils/featureRegistry';
import { DocumentationTab } from './admin/DocumentationTab';
import { NstaFeatureManager } from './admin/NstaFeatureManager';
// @ts-ignore
import JSZip from 'jszip';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';
import QRCode from "react-qr-code";

// Configure PDF Worker (CDN for stability)
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

const DEFAULT_BASIC_FEATURES = [
    'Daily Login Bonus: 10 Credits/Day',
    'Full MCQs Unlocked',
    'Premium Notes (Standard)',
    'Audio Library (Standard)',
    'AI Videos (2D Basic)',
    'Team Support',
    'Spin Wheel (5 Spins/Day)'
];

const DEFAULT_ULTRA_FEATURES = [
    'Daily Login Bonus: 20 Credits/Day',
    'Everything in Basic Unlocked',
    'Premium Notes (Deep Dive)',
    'Ultra Podcast (Studio HD)',
    'AI Videos (2D + 3D Deep Dive)',
    'Competitive Mode Unlocked 🏆',
    'Spin Wheel (10 Spins/Day)'
];

const QUESTION_START_REGEX = /^(\*\*)?(\*\*Question\s*\d+\*\*|Q\s*\d+[.:)]?|\d+[.:)]|Question\s*\d+[.:)]?)(\*\*)?\s*/i;

const looksLikeQuestionBlock = (lines: string[], index: number): boolean => {
    // Check if line index + 5 (Answer line) exists
    if (index + 5 >= lines.length) return false;

    // Check Answer pattern on line index + 5
    const ansLine = lines[index + 5];
    // Remove Markdown Bolding (**Answer**) if present
    const cleanAnsLine = ansLine.replace(/^\*\*|\*\*$/g, '');

    // Check if it starts with Answer/Ans/Correct/उत्तर/✅ Correct Answer
    return /^(✅\s*)?(Correct Answer|Answer|Ans|Correct|उत्तर)\s*[:\s-]*\s*/i.test(cleanAnsLine);
};

interface Props {
  onNavigate: (view: ViewState) => void;
  settings?: SystemSettings;
  onUpdateSettings?: (s: SystemSettings) => void;
  onImpersonate?: (user: User) => void;
  logActivity: (action: string, details: string) => void;
}

// --- TAB DEFINITIONS ---
type AdminTab = 
  | 'DASHBOARD' 
  | 'USERS' 
  | 'NOTIFY_USERS' // NEW
  | 'SUBSCRIPTION_MANAGER'
  | 'STORE_MANAGER'
  | 'CODES'
  | 'SUBJECTS_MGR'
  /* | 'LEADERBOARD' - REMOVED */
  | 'NOTICES' 
  | 'DATABASE'
  | 'ACCESS' 
  | 'SUB_ADMINS'
  /* | 'LOGS' - REMOVED */
  | 'DEMAND' 
  | 'RECYCLE' 
  | 'SYLLABUS_MANAGER' 
  | 'CONTENT_PDF' 
  | 'CONTENT_VIDEO'
  | 'CONTENT_AUDIO'
  | 'CONTENT_MCQ' 
  | 'CONTENT_TEST' 
  | 'BULK_UPLOAD'    
  | 'CONFIG_GENERAL' 
  | 'CONFIG_SECURITY' 
  | 'CONFIG_VISIBILITY' 
  | 'CONFIG_AI' 
  | 'CONFIG_GAME'
  | 'CONFIG_PAYMENT'
  | 'CONFIG_EXTERNAL_APPS'
  | 'CONFIG_APP_STORE'
  | 'PRICING_MGMT'
  | 'SUBSCRIPTION_PLANS_EDITOR'
  | 'CONFIG_REWARDS'
  | 'CONFIG_PRIZES' // NEW: Prize Configuration
  | 'FEATURED_CONTENT'
  | 'CONFIG_CHAT'
  | 'UNIVERSAL_PLAYLIST'
  | 'CONFIG_CHALLENGE'
  | 'CHALLENGE_CREATOR_20'
  | 'BLOGGER_HUB'
  | 'CONFIG_GATING'
  | 'WHATSAPP_CONNECT'
  | 'POWER_MANAGER'
  | 'REVISION_LOGIC' // NEW
  | 'PLAN_MATRIX'
  | 'DEPLOY'
  | 'EVENT_MANAGER' // NEW
  | 'NSTA_CONTROL' // NEW - Replaces APP_SOUL
  | 'DOCUMENTATION'
  | 'HOMEWORK_MANAGER' // NEW
  | 'DAILY_GK_MANAGER' // NEW
  | 'TEACHERS'; // NEW

interface ContentConfig {
    freeLink?: string;
    premiumLink?: string;
    freeVideoLink?: string;
    premiumVideoLink?: string;
    freeNotesHtml?: string;
    premiumNotesHtml?: string;
    schoolFreeNotesHtml?: string;
    schoolPremiumNotesHtml?: string;
    competitionFreeNotesHtml?: string;
    competitionPremiumNotesHtml?: string;
    videoCreditsCost?: number;
    price?: number;
    ultraPdfLink?: string;
    ultraPdfPrice?: number;
    aiImageLink?: string; // NEW: AI Generated Image Notes
    aiHtmlContent?: string; // NEW: AI HTML Notes
    competitionAiHtmlContent?: string; // NEW: AI HTML Notes for Competition
    draftFreeNotesHtml?: string; // NEW: Draft for Free Notes
    draftPremiumNotesHtml?: string; // NEW: Draft for Premium Notes
    draftCompetitionFreeNotesHtml?: string; // NEW: Draft for Competition Free Notes
    draftCompetitionPremiumNotesHtml?: string; // NEW: Draft for Competition Premium Notes
    aiImagePrice?: number; // Price for AI Image Notes
    chapterAiImage?: string; // NEW: Per-Chapter AI Loading Image

    // UNLIMITED NOTES (NEW)
    schoolFreeNotesList?: {title: string, url: string, type: 'PDF' | 'HTML', content?: string}[];
    competitionFreeNotesList?: {title: string, url: string, type: 'PDF' | 'HTML', content?: string}[];
    schoolPremiumNotesList?: {title: string, url: string, type: 'PDF' | 'HTML', content?: string}[];
    competitionPremiumNotesList?: {title: string, url: string, type: 'PDF' | 'HTML', content?: string}[];
    teachingStrategyHtml?: string; // NEW: For Teacher Mode (Legacy)
    teachingStrategyNotes?: {id: string, title: string, content: string, type: 'HTML', audioUrl?: string}[]; // NEW: Unlimited Teacher Notes
    freeNotesLabel?: string; // Custom Label for Free Notes Button

    schoolVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
    competitionVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
    schoolPremiumVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
    competitionPremiumVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
    schoolAudioPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
    competitionAudioPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
    schoolPdfLink?: string;
    schoolPdfPrice?: number;
    competitionPdfLink?: string;
    competitionPdfPrice?: number;
    schoolPdfPremiumSlots?: PremiumNoteSlot[];
    competitionPdfPremiumSlots?: PremiumNoteSlot[];

    // NEW: Deep Dive & Additional Notes
    deepDiveEntries?: DeepDiveEntry[];
    additionalNotes?: AdditionalNoteEntry[];

    videoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[]; // Legacy
    audioPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[]; // Legacy
    htmlModules?: HtmlModule[]; // NEW: HTML Modules
    premiumNoteSlots?: PremiumNoteSlot[]; // NEW: 20 Slots for Premium Notes
    manualMcqData?: MCQItem[];
    weeklyTestMcqData?: MCQItem[];
    
    // VISIBILITY FLAGS
    isNotesHidden?: boolean;
    isMcqHidden?: boolean;
    isVideoHidden?: boolean;
    isAudioHidden?: boolean;
}

interface Props {
  onNavigate: (view: ViewState) => void;
  settings?: SystemSettings;
  onUpdateSettings?: (s: SystemSettings) => void;
  onImpersonate?: (user: User) => void;
  logActivity: (action: string, details: string) => void;
  user?: User; // Pass current user to check permissions
  isDarkMode?: boolean;
  onToggleDarkMode?: (v: boolean) => void;
}

export const AdminDashboard: React.FC<Props> = (props) => {
  return <AdminDashboardInner {...props} />;
};

const MODELS = [
    "llama-3.1-8b-instant",
    "llama-3.1-70b-versatile",
    "mixtral-8x7b-32768"
];

const AdminDashboardInner: React.FC<Props> = ({ onNavigate, settings, onUpdateSettings, onImpersonate, logActivity, isDarkMode, onToggleDarkMode, user }) => {

  const [activeTab, setActiveTab] = useState<AdminTab>('DASHBOARD');
  const [activeNoteTab, setActiveNoteTab] = useState<'PREMIUM' | 'DEEP_DIVE' | 'ADDITIONAL' | 'TEACHER'>('PREMIUM');
  const [powerTab, setPowerTab] = useState<'LIMITS' | 'PLAN_MATRIX' | 'FEATURE_LISTS'>('LIMITS');
  const [customBloggerCode, setCustomBloggerCode] = useState('');
  const [showVisibilityControls, setShowVisibilityControls] = useState(false); // NEW: Master Visibility Toggle
  const [mcqGenCount, setMcqGenCount] = useState(20); // NEW: Custom MCQ Quantity

  // --- API KEY TESTING STATE ---
  const [keyStatus, setKeyStatus] = useState<Record<number, string>>({});
  const [isTestingKeys, setIsTestingKeys] = useState(false);

  // --- REDEEM CODE MODAL STATE ---
  const [codeModal, setCodeModal] = useState<{
      isOpen: boolean;
      type: 'NOTES' | 'VIDEO' | 'AUDIO' | 'MCQ' | 'TOPIC_NOTE';
      contentId: string;
      title?: string;
  } | null>(null);
  const [codeDuration, setCodeDuration] = useState(24); // Hours
  const [codeMaxUses, setCodeMaxUses] = useState(1);

  // PILOT COMMAND STATE

  // CURRENT USER CONTEXT (From Props or LocalStorage if missing)
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  useEffect(() => {
      if (user) {
          setCurrentUser(user);
      } else {
          const stored = localStorage.getItem('nst_current_user');
          if (stored) setCurrentUser(JSON.parse(stored));
      }
  }, [user]);

  // --- PERMISSION HELPER ---
  const hasPermission = (perm: string) => {
      if (!currentUser) return false;
      if (currentUser.role === 'ADMIN') return true; // Main Admin has all
      if (currentUser.role === 'SUB_ADMIN') {
          return (currentUser.permissions || []).includes(perm);
      }
      return false;
  };

  const [universalVideos, setUniversalVideos] = useState<any[]>([]);
  const [universalNotes, setUniversalNotes] = useState<any[]>([]);
  const [aiGenType, setAiGenType] = useState<ContentType>('NOTES_SIMPLE');
  const [aiPreview, setAiPreview] = useState<LessonContent | null>(null);
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  // --- SECURE KEYS STATE ---
  // const [secureKeys, setSecureKeys] = useState<string[]>([]); // Removed in favor of groqApiKeys
  const [newSecureKey, setNewSecureKey] = useState('');
  const [newGeminiKey, setNewGeminiKey] = useState('');
  
  // --- LOAD SECURE KEYS ---
  useEffect(() => {
      const loadKeys = async () => {
          if (currentUser?.role === 'ADMIN') {
              // 1. Try Global Secure Keys from RTDB (Primary & Persistent)
              try {
                  const snap = await get(ref(rtdb, 'secure_keys/list'));
                  if (snap.exists()) {
                      const data = snap.val();
                      if (Array.isArray(data)) {
                          setLocalSettings(prev => ({...prev, groqApiKeys: data}));
                          return;
                      }
                  }
              } catch(e) { console.error("RTDB Key Load Error", e); }

              // 2. Fallback to Firestore (Legacy)
              getSecureKeys().then(keys => {
                  if (keys && keys.length > 0) setLocalSettings(prev => ({...prev, groqApiKeys: keys}));
              });
          }
      };
      loadKeys();
  }, [currentUser]);

  // --- SUBSCRIBE TO UNIVERSAL ANALYSIS ---
  useEffect(() => {
      const unsubscribe = subscribeToUniversalAnalysis((logs) => {
          setAnalysisLogs(logs);
      });
      return () => {
          if (unsubscribe) unsubscribe();
      };
  }, []);

  // --- AI AUTO-PILOT STATE ---

  // --- AI API MONITOR STATE ---
  
  useEffect(() => {
  }, [activeTab]);

  const testKeys = async () => {
      setIsTestingKeys(true);
      const statuses: Record<number, string> = {};
      const keys = localSettings.groqApiKeys || [];
      
      for (let i = 0; i < keys.length; i++) {
          const key = keys[i]?.trim(); // STRICT TRIM
          if (!key) {
              statuses[i] = "Empty";
              continue;
          }
          try {
              const response = await fetch("/api/groq", {
                  method: "POST",
                  headers: { 
                      "Content-Type": "application/json" 
                  },
                  body: JSON.stringify({
                      key: key,
                      model: "llama-3.1-8b-instant",
                      messages: [{ role: "user", content: "Hi" }],
                      max_tokens: 1
                  })
              });
              
              if (response.ok) {
                  statuses[i] = "Valid";
              } else {
                  const errText = await response.text();
                  if (response.status === 429) {
                      statuses[i] = "⚠️ Rate Limit";
                  } else if (response.status === 401) {
                      statuses[i] = "🔴 Invalid Key";
                  } else {
                      statuses[i] = `❌ ${response.status}`;
                  }
              }
          } catch (e: any) {
              console.error(`Key ${i} failed:`, e);
              statuses[i] = `❌ Error`;
          }
      }
      setKeyStatus(statuses);
      setIsTestingKeys(false);
  };

  // UNIVERSAL PLAYLIST LOADER
  useEffect(() => {
      if (activeTab === 'UNIVERSAL_PLAYLIST') {
          getChapterData('nst_universal_playlist').then(data => {
              if (data && data.videoPlaylist) setUniversalVideos(data.videoPlaylist);
              else setUniversalVideos([]);
          });
      }
      if (activeTab === 'UNIVERSAL_NOTES') {
          getChapterData('nst_universal_notes').then(data => {
              if (data && data.notesPlaylist) setUniversalNotes(data.notesPlaylist);
              else setUniversalNotes([]);
          });
      }
  }, [activeTab]);

  const saveUniversalPlaylist = async () => {
      await saveChapterData('nst_universal_playlist', { videoPlaylist: universalVideos });
      alert("Universal Playlist Saved!");
  };

  const saveUniversalNotes = async () => {
      await saveChapterData('nst_universal_notes', { notesPlaylist: universalNotes });
      alert("Universal Notes Saved!");
  };
  const [showChat, setShowChat] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isFirebaseConnected, setIsFirebaseConnected] = useState(false);
  
  // NOTIFICATION STATE
  const [alertConfig, setAlertConfig] = useState<{isOpen: boolean, message: string}>({isOpen: false, message: ''});
  const prevUsersRef = useRef<User[]>([]);

  // --- DATA LISTS ---
  const [logs, setLogs] = useState<ActivityLogEntry[]>([]);
  const [recycleBin, setRecycleBin] = useState<RecycleBinItem[]>([]);
  const [recoveryRequests, setRecoveryRequests] = useState<RecoveryRequest[]>([]);
  const [demands, setDemands] = useState<{id:string, details:string, timestamp:string}[]>([]);
  const [giftCodes, setGiftCodes] = useState<GiftCode[]>([]);
  const [teacherCodes, setTeacherCodes] = useState<TeacherCode[]>([]); // NEW: Teacher Codes

  // --- DATABASE EDITOR ---
  const [dbKey, setDbKey] = useState('nst_users');
  const [dbContent, setDbContent] = useState('');

  // Calculate Online Users (Active in last 5 mins)
  const onlineCount = users.filter(u => {
      if (!u.lastActiveTime) return false;
      try {
          const diff = Date.now() - new Date(u.lastActiveTime).getTime();
          return diff < 5 * 60 * 1000;
      } catch(e) { return false; }
  }).length;

  // --- IMAGE CROPPER STATE ---
  const [cropImageSrc, setCropImageSrc] = useState<string | null>(null);


  // --- DAILY GK STATE ---
  // --- HOMEWORK STATE ---
  const [homeworkTab, setHomeworkTab] = useState<'ADD' | 'HISTORY' | 'COMP_MCQ'>('ADD');
  const [newCompMcqText, setNewCompMcqText] = useState('');
  const [newHomework, setNewHomework] = useState({ date: new Date().toISOString().split('T')[0], title: '', notes: '', mcqText: '', audioUrl: '', videoUrl: '', pdfUrl: '', targetSubject: 'none', pageNo: '' });

  // --- LUCENT NOTES STATE (special form when targetSubject === 'lucent') ---
  const LUCENT_SUBJECT_OPTIONS: { id: string; name: string }[] = [
    { id: 'biology', name: 'जीव विज्ञान (Biology)' },
    { id: 'chemistry', name: 'रसायन शास्त्र (Chemistry)' },
    { id: 'physics', name: 'भौतिकी (Physics)' },
    { id: 'economics', name: 'अर्थशास्त्र (Economics)' },
    { id: 'geography', name: 'भूगोल (Geography)' },
    { id: 'polity', name: 'राजनीति विज्ञान (Polity)' },
    { id: 'history', name: 'इतिहास (History)' },
  ];
  const [newLucent, setNewLucent] = useState<{ subject: string; lessonTitle: string; pages: LucentPageNote[] }>({
    subject: 'biology',
    lessonTitle: '',
    pages: [{ id: Date.now().toString(), pageNo: '1', content: '' }],
  });

  const [gkTab, setGkTab] = useState<'ADD' | 'HISTORY'>('ADD');
  const [newGk, setNewGk] = useState({ date: new Date().toISOString().split('T')[0], question: '', answer: '' });

  const copyRandomGk = (count: number) => {
      const gks = localSettings.dailyGk || [];
      if (gks.length === 0) return alert('No GK entries available.');
      const shuffled = [...gks].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, count);
      let text = `Daily GK (Random ${selected.length})\n\n`;
      selected.forEach((gk, idx) => {
          text += `Q${idx + 1}. ${gk.question}\nAns: ${gk.answer}\n\n`;
      });
      navigator.clipboard.writeText(text);
      setAlertConfig({ isOpen: true, message: `✅ Copied ${selected.length} random GK entries to clipboard!` });
  };

  // --- SETTINGS STATE ---
  const [localSettings, setLocalSettings] = useState<SystemSettings>(settings || {
      appName: 'IIC',
      themeColor: '#3b82f6',
      maintenanceMode: false,
      maintenanceMessage: 'We are upgrading our servers.',
      customCSS: '',
      apiKeys: [],
      adminCode: '', adminEmail: '', adminPhones: [{id: '1', number: '8227070298', name: 'Admin', isDefault: true}], footerText: '',
      showFooter: true,
      footerColor: '',
      welcomeTitle: 'Unlock Smart Learning', 
      welcomeMessage: 'Experience the power of AI-driven education. Leon karo AI filters out the noise of traditional textbooks to deliver only the essential, high-yield topics you need for success. Study smarter, not harder.',
      termsText: 'By using this app, you agree to our terms. Content is for personal use only. Sharing accounts may lead to a permanent ban.', supportEmail: 'nadiman0636indo@gmail.com', aiModel: 'llama3-8b-8192',
      aiInstruction: '',
      marqueeLines: ["Welcome to Leon karo ONLINE CLASSES"],
      liveMessage1: '', liveMessage2: '',
      wheelRewards: [0,1,2,5],
      chatCost: 1, dailyReward: 3, signupBonus: 2,
      isChatEnabled: true, isGameEnabled: true, allowSignup: true, showGoogleLogin: true, loginMessage: '',
      gameCost: 0, spinLimitUltra: 10, spinLimitBasic: 5, spinLimitFree: 2,
      allowedClasses: ['6', '7', '8', '9', '10', '11', '12'],
      allowedBoards: ['CBSE', 'BSEB'], allowedStreams: ['Science', 'Commerce', 'Arts'],
      hiddenSubjects: [], storageCapacity: '100 GB',
      isPaymentEnabled: true, upiId: '', upiName: '', qrCodeUrl: '', paymentInstructions: '',
      syllabusType: 'DUAL',
      playerBrandingText: 'NSTA',
      playerBlockShare: true,
      packages: [
          { id: 'pkg-1', name: 'Starter Pack', price: 100, credits: 150 },
          { id: 'pkg-2', name: 'Value Pack', price: 200, credits: 350 },
          { id: 'pkg-3', name: 'Pro Pack', price: 500, credits: 1500 },
          { id: 'pkg-4', name: 'Ultra Pack', price: 1000, credits: 3000 },
          { id: 'pkg-5', name: 'Mega Pack', price: 2000, credits: 7000 },
          { id: 'pkg-6', name: 'Giga Pack', price: 3000, credits: 12000 },
          { id: 'pkg-7', name: 'Ultimate Pack', price: 5000, credits: 20000 }
      ],
      subscriptionPlans: [
          { id: 'weekly', name: 'Weekly', duration: '7 days', basicPrice: 49, basicOriginalPrice: 99, ultraPrice: 79, ultraOriginalPrice: 149, features: ['Premium Content'], popular: false },
          { id: 'monthly', name: 'Monthly', duration: '30 days', basicPrice: 149, basicOriginalPrice: 299, ultraPrice: 199, ultraOriginalPrice: 399, features: ['Everything in Weekly', 'Live Chat'], popular: true },
          { id: 'quarterly', name: 'Quarterly', duration: '3 months', basicPrice: 399, basicOriginalPrice: 799, ultraPrice: 499, ultraOriginalPrice: 999, features: ['Everything in Monthly', 'Priority Support'], popular: false },
          { id: 'yearly', name: 'Yearly', duration: '365 days', basicPrice: 999, basicOriginalPrice: 1999, ultraPrice: 1499, ultraOriginalPrice: 2999, features: ['Everything in Quarterly', 'Priority Support'], popular: false },
          { id: 'lifetime', name: 'Yearly Plus', duration: '365 days', basicPrice: 4999, basicOriginalPrice: 9999, ultraPrice: 7499, ultraOriginalPrice: 14999, features: ['VIP Status'], popular: true }
      ],
      startupAd: { 
          enabled: true, 
          duration: 10, 
          title: "🚀 UPGRADE TO ULTRA PREMIUM", 
          features: [
              "💎 All Subject PDF Notes Unlocked",
              "🎥 Ad-Free 4K Video Lectures",
              "🏆 Exclusive Weekly Mock Tests",
              "🤖 AI Homework Helper Access",
              "📉 Detailed Performance Analytics",
              "🏅 VIP Badge on Leaderboard",
              "🎁 Monthly 500 Bonus Credits",
              "📞 1-on-1 Teacher Support",
              "🔄 Offline Video Download Mode",
              "📅 Personal Study Planner"
          ], 
          bgColor: "#581c87", 
          textColor: "#ffffff" 
      },
      featurePopup: {
      enabled: true,
      intervalMinutes: 60,
      freeFeatures: [
        "📝 Normal Video Lessons",
        "📄 Basic Subject Notes",
        "❓ Chapter MCQs (Limit: 50)",
        "📈 Daily Study Streak Tracker",
        "🎮 2 Daily Spin Wheel Games",
        "📱 Mobile Access Anywhere",
        "🏆 Global Leaderboard View",
        "📅 Academic Calendar Support",
        "💬 Public Chatroom Access",
        "🎁 Daily 3-Coin Login Bonus"
      ],
      premiumFeatures: [
        "💎 Deep Concept Long Videos",
        "🎞️ Animated Educational Content",
        "📚 Detailed Multi-Part Notes",
        "🖼️ Diagrams & Visual Figures",
        "🎰 Unlimited Spin (100+ daily)",
        "❓ Full Chapter MCQs Access",
        "🏆 Weekly Pro Mock Tests & Prizes",
        "🏅 VIP Badge & Custom Profile",
        "🎁 500+ Monthly Bonus Credits",
        "📞 Direct Teacher Support Access",
        "🔄 Offline Video Downloads"
      ],
      showToPremiumUsers: true,
      showNearExpiryHours: 24
    },
    dailyChallengeConfig: {
      mode: 'AUTO',
      rewardPercentage: 90,
      selectedChapterIds: []
    },
    themeConfig: {
      freeTheme: 'BASIC',
      enableTop3Gold: true
    }
  });

  // SYNC WITH PROP UPDATES (Ensure Admin sees live changes)
  // NOTE: Local edits take precedence over incoming cloud sync so that
  // a Firestore listener firing mid-edit cannot revert what the admin is typing.
  useEffect(() => {
      if (settings) {
          setLocalSettings(prev => ({ ...settings, ...prev }));
      }
  }, [settings]);

  // Sync teacher codes with localSettings
  useEffect(() => {
      if (localSettings.teacherCodes) {
          setTeacherCodes(localSettings.teacherCodes);
      }
      if (localSettings.teacherStorePlans) {
          setTeacherStorePlans(localSettings.teacherStorePlans);
      }
  }, [localSettings.teacherCodes, localSettings.teacherStorePlans]);

  // --- TEACHER MANAGER STATE ---
  const [newTeacherCodePrice, setNewTeacherCodePrice] = useState('299');
  const [newTeacherCodeDuration, setNewTeacherCodeDuration] = useState('365');
  const [teacherStorePlans, setTeacherStorePlans] = useState<TeacherStorePlan[]>([]);

  // --- PACKAGE MANAGER STATE ---
  const [newPkgName, setNewPkgName] = useState('');
  const [newPkgPrice, setNewPkgPrice] = useState('');
  const [newPkgCredits, setNewPkgCredits] = useState('');
  const [newPkgDummyPrice, setNewPkgDummyPrice] = useState('');

  // --- GLOBAL BOARD CONTEXT (STRICT ISOLATION) ---
  const [adminBoardContext, setAdminBoardContext] = useState<Board>('CBSE');

  // PERSISTENT BOARD SELECTION
  useEffect(() => {
      if (currentUser?.id) {
          const storedBoard = localStorage.getItem(`nst_admin_board_pref_${currentUser.id}`);
          if (storedBoard && (storedBoard === 'CBSE' || storedBoard === 'BSEB')) {
              setAdminBoardContext(storedBoard as Board);
          }
      }
  }, [currentUser]);

  const handleBoardChange = (board: Board) => {
      setAdminBoardContext(board);
      if (currentUser?.id) {
          localStorage.setItem(`nst_admin_board_pref_${currentUser.id}`, board);
      }
  };

  // --- CONTENT SELECTION STATE ---
  const [selBoard, setSelBoard] = useState<Board>('CBSE');
  
  // Sync selBoard with Context
  useEffect(() => {
    setSelBoard(adminBoardContext);
    setSelSubject(null); 
    setSelChapters([]);
  }, [adminBoardContext]);

  const [selClass, setSelClass] = useState<ClassLevel>('10');
  const [selStream, setSelStream] = useState<Stream>('Science');
  const [selSubject, setSelSubject] = useState<Subject | null>(null);
  const [selChapters, setSelChapters] = useState<Chapter[]>([]);
  const [isLoadingChapters, setIsLoadingChapters] = useState(false);
  
  // --- UNIVERSAL ANALYSIS STATE ---
  const [analysisLogs, setAnalysisLogs] = useState<UniversalAnalysisLog[]>([]);
  const [aiLogs, setAiLogs] = useState<any[]>([]);

  // --- BULK UPLOAD STATE ---
  const [bulkData, setBulkData] = useState<Record<string, {free: string, premium: string, price: number}>>({});

  // --- EDITING STATE ---
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);
  const [syllabusMode, setSyllabusMode] = useState<'SCHOOL' | 'COMPETITION'>('SCHOOL');
  const [managerMode, setManagerMode] = useState<'SCHOOL' | 'COMPETITION'>('SCHOOL'); // New State for AI Notes Manager
  const [whatsappStatus, setWhatsappStatus] = useState<'CONNECTED' | 'DISCONNECTED' | 'SCAN_QR'>('DISCONNECTED');
  const [whatsappQr, setWhatsappQr] = useState('');
  const [notesStatusMap, setNotesStatusMap] = useState<Record<string, any>>({});
  const [isSyncingNotes, setIsSyncingNotes] = useState(false);

  // Helper to get correct field based on mode
  const getModeField = (baseField: string) => {
    if (syllabusMode === 'SCHOOL') return `school${baseField.charAt(0).toUpperCase() + baseField.slice(1)}`;
    return `competition${baseField.charAt(0).toUpperCase() + baseField.slice(1)}`;
  };

  const handleModeSwitch = (newMode: 'SCHOOL' | 'COMPETITION') => {
      if (newMode === syllabusMode) return;
      
      // 1. Save current UI state to local config
      const currentVideoField = syllabusMode === 'SCHOOL' ? 'schoolVideoPlaylist' : 'competitionVideoPlaylist';
      const currentPremiumVideoField = syllabusMode === 'SCHOOL' ? 'schoolPremiumVideoPlaylist' : 'competitionPremiumVideoPlaylist';
      const currentAudioField = syllabusMode === 'SCHOOL' ? 'schoolAudioPlaylist' : 'competitionAudioPlaylist';
      const currentSlotsField = syllabusMode === 'SCHOOL' ? 'schoolPdfPremiumSlots' : 'competitionPdfPremiumSlots';
      const currentFreeNotesField = syllabusMode === 'SCHOOL' ? 'schoolFreeNotesList' : 'competitionFreeNotesList';
      const currentPremiumNotesField = syllabusMode === 'SCHOOL' ? 'schoolPremiumNotesList' : 'competitionPremiumNotesList';
      
      // NEW FIELDS
      const currentDeepDiveField = syllabusMode === 'SCHOOL' ? 'schoolDeepDiveEntries' : 'competitionDeepDiveEntries';
      const currentAdditionalField = syllabusMode === 'SCHOOL' ? 'schoolAdditionalNotes' : 'competitionAdditionalNotes';

      const updatedConfig = {
          ...editConfig,
          [currentVideoField]: videoPlaylist,
          [currentPremiumVideoField]: premiumVideoPlaylist,
          [currentAudioField]: audioPlaylist,
          [currentSlotsField]: premiumNoteSlots,
          [currentFreeNotesField]: freeNotesList,
          [currentPremiumNotesField]: premiumNotesList,
          [currentDeepDiveField]: deepDiveEntries,
          [currentAdditionalField]: additionalNotes,
          teachingStrategyHtml: teachingStrategyHtml,
          teachingStrategyNotes: teachingStrategyNotes
      };
      setEditConfig(updatedConfig);

      // 2. Load new mode data
      // STRICT SEPARATION: Only fallback to legacy for SCHOOL mode
      if (newMode === 'SCHOOL') {
          // @ts-ignore
          setVideoPlaylist(updatedConfig.schoolVideoPlaylist || updatedConfig.videoPlaylist || []);
          // @ts-ignore
          setPremiumVideoPlaylist(updatedConfig.schoolPremiumVideoPlaylist || []);
          // @ts-ignore
          setAudioPlaylist(updatedConfig.schoolAudioPlaylist || updatedConfig.audioPlaylist || []);
          // @ts-ignore
          setPremiumNoteSlots(updatedConfig.schoolPdfPremiumSlots || updatedConfig.premiumNoteSlots || []);
          // @ts-ignore
          setFreeNotesList(updatedConfig.schoolFreeNotesList || []);
          // @ts-ignore
          setPremiumNotesList(updatedConfig.schoolPremiumNotesList || []);
          // @ts-ignore
          setDeepDiveEntries(updatedConfig.schoolDeepDiveEntries || updatedConfig.deepDiveEntries || []);
          // @ts-ignore
          setAdditionalNotes(updatedConfig.schoolAdditionalNotes || updatedConfig.additionalNotes || []);
      } else {
          // @ts-ignore
          setVideoPlaylist(updatedConfig.competitionVideoPlaylist || []);
          // @ts-ignore
          setPremiumVideoPlaylist(updatedConfig.competitionPremiumVideoPlaylist || []);
          // @ts-ignore
          setAudioPlaylist(updatedConfig.competitionAudioPlaylist || []);
          // @ts-ignore
          setPremiumNoteSlots(updatedConfig.competitionPdfPremiumSlots || []);
          // @ts-ignore
          setFreeNotesList(updatedConfig.competitionFreeNotesList || []);
          // @ts-ignore
          setPremiumNotesList(updatedConfig.competitionPremiumNotesList || []);
          // @ts-ignore
          setDeepDiveEntries(updatedConfig.competitionDeepDiveEntries || []);
          // @ts-ignore
          setAdditionalNotes(updatedConfig.competitionAdditionalNotes || []);
      }
      
      setSyllabusMode(newMode);
  };

  const [isContentLoading, setIsContentLoading] = useState(false);
  const [isSettingsSaving, setIsSettingsSaving] = useState(false);
  const [editConfig, setEditConfig] = useState<ContentConfig>({ freeLink: '', premiumLink: '', price: 0 });
  const [videoPlaylist, setVideoPlaylist] = useState<{title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[]>([]);
  const [premiumVideoPlaylist, setPremiumVideoPlaylist] = useState<{title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[]>([]);
  const [audioPlaylist, setAudioPlaylist] = useState<{title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[]>([]);
  const [premiumNoteSlots, setPremiumNoteSlots] = useState<PremiumNoteSlot[]>([]);

  // NEW: Deep Dive & Additional Notes State
  const [deepDiveEntries, setDeepDiveEntries] = useState<DeepDiveEntry[]>([]);
  const [additionalNotes, setAdditionalNotes] = useState<AdditionalNoteEntry[]>([]);

  // UNLIMITED NOTES STATE (NEW)
  const [freeNotesList, setFreeNotesList] = useState<{title: string, url: string, type: 'PDF' | 'HTML', content?: string}[]>([]);
  const [premiumNotesList, setPremiumNotesList] = useState<{title: string, url: string, type: 'PDF' | 'HTML', content?: string, audioUrl?: string}[]>([]);

  // NEW TOPIC CONTENT STATE
  const [topicNotes, setTopicNotes] = useState<{ id: string, title: string, content: string, isPremium: boolean, topic: string }[]>([]);
  const [topicVideos, setTopicVideos] = useState<{ id: string, title: string, url: string, isPremium: boolean, topic: string }[]>([]);
  const [teachingStrategyHtml, setTeachingStrategyHtml] = useState<string>(''); // NEW: Teaching Strategy content

  // MOVE CHAPTER STATE
  const [movingChapter, setMovingChapter] = useState<{ chapter: Chapter, index: number } | null>(null);
  const [moveTargetBoard, setMoveTargetBoard] = useState<Board>('CBSE');
  const [moveTargetClass, setMoveTargetClass] = useState<ClassLevel>('10');
  const [moveTargetStream, setMoveTargetStream] = useState<Stream>('Science');
  const [moveTargetSubject, setMoveTargetSubject] = useState<Subject | null>(null);
  const [isMoving, setIsMoving] = useState(false);
  const [teachingStrategyNotes, setTeachingStrategyNotes] = useState<{ id: string, title: string, content: string, type: 'HTML', audioUrl?: string }[]>([]); // NEW: Unlimited Teaching Strategy Notes
  const [editingMcqs, setEditingMcqs] = useState<MCQItem[]>([]);
  const [editingTestMcqs, setEditingTestMcqs] = useState<MCQItem[]>([]);
  const [importText, setImportText] = useState('');
  const [importFormatMode, setImportFormatMode] = useState<'AUTO' | 'ADVANCED_EMOJI' | 'STANDARD_TSV'>('AUTO');
  const [syllabusImportText, setSyllabusImportText] = useState('');
  
  // --- PDF PREVIEW STATE ---
  const [previewPdfFile, setPreviewPdfFile] = useState<File | null>(null);
  const [numPages, setNumPages] = useState<number>(0);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
      setNumPages(numPages);
  }

  // --- PRICING MANAGEMENT STATE ---
  const [editingPlanIdx, setEditingPlanIdx] = useState<number | null>(null);
  const [editingPkg, setEditingPkg] = useState<{id: string, name: string, credits: number, price: number} | null>(null);
  
  // --- SUB-ADMIN STATE ---
  const [subAdminSearch, setSubAdminSearch] = useState('');
  const [newSubAdminId, setNewSubAdminId] = useState('');
  const [viewingSubAdminReport, setViewingSubAdminReport] = useState<string | null>(null);
  const [viewingUserHistory, setViewingUserHistory] = useState<User | null>(null); // NEW: User History Modal
  
  // --- USER EDIT MODAL STATE ---
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editUserCredits, setEditUserCredits] = useState(0);
  const [editUserPass, setEditUserPass] = useState('');
  const [dmText, setDmText] = useState('');
  const [dmUser, setDmUser] = useState<User | null>(null);
  const [giftType, setGiftType] = useState<'NONE' | 'CREDITS' | 'SUBSCRIPTION' | 'ANIMATION'>('NONE');
  const [giftValue, setGiftValue] = useState<string | number>('');
  const [giftDuration, setGiftDuration] = useState(24); // Hours
  const [editSubscriptionTier, setEditSubscriptionTier] = useState<'FREE' | 'WEEKLY' | 'MONTHLY' | '3_MONTHLY' | 'YEARLY' | 'LIFETIME' | 'CUSTOM'>('FREE');
  const [editSubscriptionLevel, setEditSubscriptionLevel] = useState<'BASIC' | 'ULTRA'>('BASIC');
  const [editSubscriptionYears, setEditSubscriptionYears] = useState(0);
  const [editSubscriptionMonths, setEditSubscriptionMonths] = useState(0);
  const [editSubscriptionDays, setEditSubscriptionDays] = useState(0);
  const [editSubscriptionHours, setEditSubscriptionHours] = useState(0);
  const [editSubscriptionMinutes, setEditSubscriptionMinutes] = useState(0);
  const [editSubscriptionSeconds, setEditSubscriptionSeconds] = useState(0);
  const [editSubscriptionPrice, setEditSubscriptionPrice] = useState(0);
  const [editCustomSubName, setEditCustomSubName] = useState('');
  
  // SUBSCRIPTION PRICES (ADMIN CUSTOMIZABLE)
  const [subPrices, setSubPrices] = useState<{
    WEEKLY: { BASIC: number, ULTRA: number },
    MONTHLY: { BASIC: number, ULTRA: number },
    "3_MONTHLY": { BASIC: number, ULTRA: number },
    YEARLY: { BASIC: number, ULTRA: number },
    LIFETIME: { BASIC: number, ULTRA: number }
  }>({
      WEEKLY: { BASIC: 49, ULTRA: 99 },
      MONTHLY: { BASIC: 199, ULTRA: 399 },
      "3_MONTHLY": { BASIC: 499, ULTRA: 899 },
      YEARLY: { BASIC: 1999, ULTRA: 4999 },
      LIFETIME: { BASIC: 4999, ULTRA: 9999 }
  });

  // Sync subPrices with localSettings
  useEffect(() => {
      if (localSettings.subscriptionPlans) {
          const newPrices = { ...subPrices };
          localSettings.subscriptionPlans.forEach((plan: any) => {
              const tier = plan.id.toUpperCase() as keyof typeof subPrices;
              if (newPrices[tier]) {
                  newPrices[tier].BASIC = plan.basicPrice || newPrices[tier].BASIC;
                  newPrices[tier].ULTRA = plan.ultraPrice || newPrices[tier].ULTRA;
              }
          });
          setSubPrices(newPrices);
      }
  }, [localSettings.subscriptionPlans]);

  // --- DISCOUNT CONFIG STATE ---
  const [eventYears, setEventYears] = useState(localSettings.specialDiscountEvent?.duration?.years || 0);
  const [eventMonths, setEventMonths] = useState(localSettings.specialDiscountEvent?.duration?.months || 0);
  const [eventDays, setEventDays] = useState(localSettings.specialDiscountEvent?.duration?.days || 0);
  const [eventHours, setEventHours] = useState(localSettings.specialDiscountEvent?.duration?.hours || 0);
  const [eventMinutes, setEventMinutes] = useState(localSettings.specialDiscountEvent?.duration?.minutes || 0);
  const [eventSeconds, setEventSeconds] = useState(localSettings.specialDiscountEvent?.duration?.seconds || 0);

  const [cdYears, setCdYears] = useState(localSettings.specialDiscountEvent?.cooldownSettings?.years || 0);
  const [cdMonths, setCdMonths] = useState(localSettings.specialDiscountEvent?.cooldownSettings?.months || 0);
  const [cdDays, setCdDays] = useState(localSettings.specialDiscountEvent?.cooldownSettings?.days || 0);
  const [cdHours, setCdHours] = useState(localSettings.specialDiscountEvent?.cooldownSettings?.hours || 0);
  const [cdMinutes, setCdMinutes] = useState(localSettings.specialDiscountEvent?.cooldownSettings?.minutes || 0);
  const [cdSeconds, setCdSeconds] = useState(localSettings.specialDiscountEvent?.cooldownSettings?.seconds || 0);

  const calculateStartTime = () => {
      const now = new Date();
      now.setFullYear(now.getFullYear() + cdYears);
      now.setMonth(now.getMonth() + cdMonths);
      now.setDate(now.getDate() + cdDays);
      now.setHours(now.getHours() + cdHours);
      now.setMinutes(now.getMinutes() + cdMinutes);
      now.setSeconds(now.getSeconds() + cdSeconds);
      return now.toISOString();
  };

  const calculateEndTimeFromStart = (startTime: string) => {
      const start = new Date(startTime);
      start.setFullYear(start.getFullYear() + eventYears);
      start.setMonth(start.getMonth() + eventMonths);
      start.setDate(start.getDate() + eventDays);
      start.setHours(start.getHours() + eventHours);
      start.setMinutes(start.getMinutes() + eventMinutes);
      start.setSeconds(start.getSeconds() + eventSeconds);
      return start.toISOString();
  };

  const updatePriceForSelection = (tier: typeof editSubscriptionTier, level: typeof editSubscriptionLevel) => {
      if (tier !== 'FREE' && tier !== 'CUSTOM' && editingUser) {
          const tierPrices = subPrices[tier as keyof typeof subPrices];
          if (tierPrices) {
              let basePrice = tierPrices[level];

              // Apply Event Discount + Renewal Bonus Logic (Consistent with Store.tsx)
              const event = localSettings.specialDiscountEvent;
              let discountPercentVal = 0;
              const isSubscribed = editingUser.isPremium && editingUser.subscriptionEndDate && new Date(editingUser.subscriptionEndDate) > new Date();

              // 1. Check Event Validity
              let isEventActive = !!event?.enabled; // Assume true if enabled
              if (event?.enabled && event.startsAt && event.endsAt) {
                  const now = Date.now();
                  const startTime = new Date(event.startsAt).getTime();
                  const endTime = new Date(event.endsAt).getTime();
                  if (startTime === endTime) {
                      isEventActive = now >= startTime;
                  } else {
                      isEventActive = now >= startTime && now < endTime;
                  }
              }

              if (isEventActive) {
                  if ((isSubscribed && event?.showToPremiumUsers) || (!isSubscribed && event?.showToFreeUsers)) {
                      discountPercentVal += (event?.discountPercent || 0);
                  }
              }

              // 2. Renewal Bonus (Check Premium or History)
              if (editingUser.isPremium || (editingUser.subscriptionHistory && editingUser.subscriptionHistory.length > 0)) {
                  discountPercentVal += 5;
              }

              if (discountPercentVal > 0) {
                  basePrice = Math.round(basePrice * (1 - discountPercentVal / 100));
              }

              setEditSubscriptionPrice(basePrice);
          }
      } else if (tier === 'CUSTOM') {
          setEditSubscriptionPrice(0);
      }
  };
  // --- SAVE CONTENT LOGIC (UPDATED) ---
  const handleGenerateCodeConfirm = async () => {
      if (!codeModal) return;

      let prefix = 'ITEM';
      if (codeModal.type === 'NOTES') prefix = 'N';
      if (codeModal.type === 'VIDEO') prefix = 'V';
      if (codeModal.type === 'AUDIO') prefix = 'A';
      if (codeModal.type === 'MCQ') prefix = 'MCQ';
      if (codeModal.type === 'TOPIC_NOTE') prefix = 'N';

      const randomPart = generateSecureRandomId(6).toUpperCase();
      const finalCode = `${prefix}-${randomPart}`;

      const newGiftCode: GiftCode = {
          id: Date.now().toString(),
          code: finalCode,
          type: 'CONTENT_UNLOCK',
          contentId: codeModal.contentId,
          contentType: 'LESSON', // Generic type, handled by modal type mapping if needed
          createdAt: new Date().toISOString(),
          isRedeemed: false,
          generatedBy: 'ADMIN',
          maxUses: codeMaxUses || 1,
          usedCount: 0,
          redeemedBy: [],
          duration: {
              years: 0,
              months: 0,
              days: Math.floor(codeDuration / 24),
              hours: codeDuration % 24,
              minutes: 0,
              seconds: 0
          }
      };

      try {
          await set(ref(rtdb, `redeem_codes/${finalCode}`), newGiftCode);
          alert(`Code Generated: ${finalCode}\n(Copied to Clipboard)`);
          navigator.clipboard.writeText(finalCode);
          setCodeModal(null);
      } catch (e) {
          alert("Error generating code: " + e);
      }
  };

  const saveChapterContent = async () => {
    if (!editingChapterId || !selSubject) return;
    setIsContentLoading(true);
    
    // STRICT KEY MATCHING (Must match VideoPlaylistView logic)
    const streamKey = (selClass === '11' || selClass === '12') && selStream ? `-${selStream}` : '';
    const key = `nst_content_${selBoard}_${selClass}${streamKey}_${selSubject.name}_${editingChapterId}`;
    
    try {
      const existing = await storage.getItem(key);
      const existingData = existing || {};
      
      const modePrefix = syllabusMode === 'SCHOOL' ? 'school' : 'competition';

      // Ensure content field is set correctly based on what was entered (Preserved from old saveChapterContent)
      let finalContent = '';
      if (editConfig.premiumLink && editConfig.premiumLink.startsWith('http')) {
          finalContent = editConfig.premiumLink;
      } else if (editConfig.premiumNotesHtml && editConfig.premiumNotesHtml.trim() !== '' && editConfig.premiumNotesHtml !== '<p><br></p>') {
          finalContent = editConfig.premiumNotesHtml;
      } else if (aiGenType === 'NOTES_IMAGE_AI' && editConfig.aiImageLink) {
          finalContent = editConfig.aiImageLink;
      } else if (aiGenType === 'NOTES_AI' && editConfig.aiHtmlContent) {
          finalContent = editConfig.aiHtmlContent;
      } else {
          finalContent = editConfig.premiumNotesHtml || '';
      }

      const newData = {
          ...existingData,
          ...editConfig,
          
          // DYNAMIC SAVE: Save current UI arrays to the correct mode-specific field
          [syllabusMode === 'SCHOOL' ? 'schoolVideoPlaylist' : 'competitionVideoPlaylist']: videoPlaylist,
          [syllabusMode === 'SCHOOL' ? 'schoolPremiumVideoPlaylist' : 'competitionPremiumVideoPlaylist']: premiumVideoPlaylist,
          [syllabusMode === 'SCHOOL' ? 'schoolAudioPlaylist' : 'competitionAudioPlaylist']: audioPlaylist,
          [syllabusMode === 'SCHOOL' ? 'schoolPdfPremiumSlots' : 'competitionPdfPremiumSlots']: premiumNoteSlots,
          [syllabusMode === 'SCHOOL' ? 'schoolFreeNotesList' : 'competitionFreeNotesList']: freeNotesList,
          [syllabusMode === 'SCHOOL' ? 'schoolPremiumNotesList' : 'competitionPremiumNotesList']: premiumNotesList,

          // NEW: Mode Specific Unlimited Entries
          [syllabusMode === 'SCHOOL' ? 'schoolDeepDiveEntries' : 'competitionDeepDiveEntries']: deepDiveEntries,
          [syllabusMode === 'SCHOOL' ? 'schoolAdditionalNotes' : 'competitionAdditionalNotes']: additionalNotes,

          // Legacy sync (ONLY Update if in SCHOOL mode to protect separation)
          // We DO NOT sync to legacy fields if in Competition mode to prevent pollution
          ...(syllabusMode === 'SCHOOL' ? {
              videoPlaylist: videoPlaylist,
              audioPlaylist: audioPlaylist,
              premiumNoteSlots: premiumNoteSlots,
              deepDiveEntries: deepDiveEntries, // Fallback
              additionalNotes: additionalNotes // Fallback
          } : {}),
          ...(syllabusMode === 'SCHOOL' ? {
              videoPlaylist: videoPlaylist,
              audioPlaylist: audioPlaylist,
              premiumNoteSlots: premiumNoteSlots
          } : {}),

          // For MCQ Data, we might need separation too if requested later, but currently user asked for content (Notes/Video/Audio)
          // For now, MCQs are shared unless separated. The user prompt specifically mentioned "school mode wala content aajaraha hai" referring to notes.
          // Let's ensure notes separation in PdfView is matched here by the keys above.
          
          manualMcqData: editingMcqs,
          weeklyTestMcqData: editingTestMcqs,
          type: aiGenType,
          content: finalContent,

          // SAVE NEW TOPIC CONTENT
          topicNotes: topicNotes,
          topicVideos: topicVideos,

          // SAVE TEACHER STRATEGY
          teachingStrategyHtml: teachingStrategyHtml,
          teachingStrategyNotes: teachingStrategyNotes
      };
      
      // Save locally AND to Firebase
      await storage.setItem(key, newData);

      try {
          await saveChapterData(key, newData); // <--- FIREBASE SAVE

          // Log Universal Update
          const chapterTitle = selChapters.find(c => c.id === editingChapterId)?.title || 'Chapter';
          const updateMsg = {
              id: `update-${Date.now()}`,
              text: `New Content Available: ${selSubject.name} - ${chapterTitle}`,
              type: 'CONTENT',
              timestamp: new Date().toISOString()
          };
          push(ref(rtdb, 'universal_updates'), updateMsg);

          if (!isFirebaseConnected) {
              alert("✅ Content Saved Locally & Queued for Cloud Sync (Offline)");
          } else {
              alert("✅ Content Saved to Firebase Database!");
          }
      } catch(e: any) {
          console.error("Firebase Save Failed:", e);
          alert("⚠️ Saved Locally, but Cloud Sync Failed: " + e.message);
      }

    } catch (error) {
      console.error("Save Error:", error);
      alert("Failed to save content.");
    } finally {
      setIsContentLoading(false);
    }
  };

  const handleBulkGenerateMCQs = async () => {
      if (!selSubject || !editingChapterId) {
          alert("Please select a subject and chapter first.");
          return;
      }
      setIsAiGenerating(true);
      try {
          const lang = selBoard === 'BSEB' ? 'Hindi' : 'English';
          const content = await fetchLessonContent(
              selBoard,
              selClass,
              selStream,
              selSubject,
              { id: editingChapterId, title: selChapters.find(c => c.id === editingChapterId)?.title || 'Chapter' },
              lang,
              'MCQ_SIMPLE',
              0,
              true,
              mcqGenCount, 
              "",
              true,
              syllabusMode,
              true
          );
          if (content && content.mcqData) {
              if (activeTab === 'CONTENT_TEST') {
                  setEditingTestMcqs([...editingTestMcqs, ...content.mcqData]);
              } else {
                  setEditingMcqs([...editingMcqs, ...content.mcqData]);
              }
              alert(`Successfully generated ${content.mcqData.length} MCQs!`);
          }
      } catch (error) {
          console.error("Bulk Gen Error:", error);
          alert("Failed to generate bulk MCQs. Check API keys.");
      } finally {
          setIsAiGenerating(false);
      }
  };

  // --- GENERATE NOTES FROM MCQS ---
  const generateNotePlaceholders = () => {
      const mcqList = activeTab === 'CONTENT_TEST' ? editingTestMcqs : editingMcqs;
      if (mcqList.length === 0) {
          alert("No MCQs found. Please add questions first.");
          return;
      }

      const uniqueTopics = Array.from(new Set(mcqList.map(q => q.topic).filter(t => t && t.trim() !== '')));
      if (uniqueTopics.length === 0) {
          alert("No topics found in MCQs. Please ensure questions have 'Topic' assigned.");
          return;
      }

      let addedCount = 0;
      const newNotes = [...topicNotes];

      uniqueTopics.forEach(topic => {
          const normalizedTopic = topic!.trim();
          // Check if note exists
          const exists = newNotes.some(n => (n.topic || '').toLowerCase() === (normalizedTopic || '').toLowerCase());

          if (!exists) {
              newNotes.push({
                  id: `note-${Date.now()}-${generateSecureRandomId(9)}`,
                  title: `Notes: ${normalizedTopic}`,
                  topic: normalizedTopic,
                  content: '', // Placeholder
                  isPremium: true // Default to premium as per requirement
              });
              addedCount++;
          }
      });

      if (addedCount > 0) {
          setTopicNotes(newNotes);
          alert(`✅ Added ${addedCount} placeholder notes for topics: ${uniqueTopics.join(', ')}`);
      } else {
          alert("ℹ️ Notes already exist for all topics found.");
      }
  };

  // --- GIFT CODE STATE ---
  const [newCodeType, setNewCodeType] = useState<'CREDITS' | 'SUBSCRIPTION' | 'DISCOUNT' | 'CONTENT_UNLOCK'>('CREDITS');
  const [newCodeAmount, setNewCodeAmount] = useState(10);
  const [newCodeDiscount, setNewCodeDiscount] = useState(10); // NEW
  const [newCodeSubTier, setNewCodeSubTier] = useState<any>('WEEKLY');
  const [newCodeSubLevel, setNewCodeSubLevel] = useState<any>('BASIC');

  // NEW: State for Content Unlock codes
  const [newCodeContentType, setNewCodeContentType] = useState<'VIDEO' | 'PDF' | 'MCQ' | 'AUDIO'>('VIDEO');
  const [newCodeContentBoard, setNewCodeContentBoard] = useState<Board>('CBSE');
  const [newCodeContentClass, setNewCodeContentClass] = useState<ClassLevel>('10');
  const [newCodeContentSubject, setNewCodeContentSubject] = useState<string>('');
  const [newCodeContentChapter, setNewCodeContentChapter] = useState<string>('');
  const [newCodeContentChaptersList, setNewCodeContentChaptersList] = useState<Chapter[]>([]);

  const [newCodeCount, setNewCodeCount] = useState(1);
  const [newCodeMaxUses, setNewCodeMaxUses] = useState(1); // Default 1 (Single Use)

  // --- SPIN GAME CONFIG STATE ---
  const [newReward, setNewReward] = useState<SpinReward>({ id: '', type: 'COINS', value: 10, label: '10 Coins', color: '#3b82f6' });

  // --- CHAT MANAGER STATE ---
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomDesc, setNewRoomDesc] = useState('');

  // --- SUBJECT MANAGER STATE ---
  const [customSubjects, setCustomSubjects] = useState<any>({});
  const [newSubName, setNewSubName] = useState('');
  const [newSubIcon, setNewSubIcon] = useState('book');
  const [newSubColor, setNewSubColor] = useState('bg-slate-50 text-slate-600');
  const [newNotifTitle, setNewNotifTitle] = useState('');
  const [newNotifBody, setNewNotifBody] = useState('');
  const [newNotifType, setNewNotifType] = useState<'info' | 'reward'>('info');
  const [newNotifCredits, setNewNotifCredits] = useState('');

  // --- WEEKLY TEST CREATION STATE ---
  const [testName, setTestName] = useState('');
  const [testDesc, setTestDesc] = useState('');
  const [testDuration, setTestDuration] = useState(120);
  const [testPassScore, setTestPassScore] = useState(50);
  const [testSelectedSubjects, setTestSelectedSubjects] = useState<string[]>([]);
  const [testSelectedChapters, setTestSelectedChapters] = useState<string[]>([]);
  const [testClassLevel, setTestClassLevel] = useState<ClassLevel>('10');

  // --- WEEKLY TEST SAVE HANDLER (NEW) ---
  const handleSaveWeeklyTest = () => {
      if (!testName || editingTestMcqs.length === 0) {
          alert("Please provide a Test Name and add at least one question.");
          return;
      }

      const newTest = {
          id: `test-${Date.now()}`,
          name: testName,
          description: testDesc,
          isActive: true,
          classLevel: testClassLevel,
          questions: editingTestMcqs,
          totalQuestions: editingTestMcqs.length,
          passingScore: testPassScore,
          createdAt: new Date().toISOString(),
          durationMinutes: testDuration,
          selectedSubjects: testSelectedSubjects,
          selectedChapters: testSelectedChapters,
          autoSubmitEnabled: true
      };

      const updatedTests = [...(localSettings.weeklyTests || []), newTest];
      setLocalSettings({...localSettings, weeklyTests: updatedTests});
      
      // Save immediately
      localStorage.setItem('nst_system_settings', JSON.stringify({...localSettings, weeklyTests: updatedTests}));
      
      // Reset Form
      setTestName('');
      setTestDesc('');
      setEditingTestMcqs([]);
      setTestSelectedSubjects([]);
      setTestSelectedChapters([]);
      alert("✅ Weekly Test Created Successfully!");
  };

  // --- INITIAL LOAD & AUTO REFRESH ---
  useEffect(() => {
      loadData();
      
      // Initial Check
      setIsFirebaseConnected(checkFirebaseConnection());
      
      const interval = setInterval(() => {
          loadData();
          // Poll Connection Status
          setIsFirebaseConnected(checkFirebaseConnection());
      }, 5000); 

      // SUBSCRIBE TO USERS (Live Sync)
      const unsubUsers = subscribeToUsers((cloudUsers) => {
          if (cloudUsers && cloudUsers.length > 0) {
              // 1. Detect New Users (Real-time)
              const prevUsers = prevUsersRef.current;
              if (prevUsers.length > 0) { 
                  const newUsers = cloudUsers.filter(u => !prevUsers.some(p => p.id === u.id));
                  if (newUsers.length > 0) {
                      const names = newUsers.map(u => u.name).join(', ');
                      // Disabled new user popup as per request
                      // setAlertConfig({
                      //     isOpen: true, 
                      //     message: `🎉 New Student Registered: ${names}`
                      // });
                  }
              }

              // 2. Sort by CreatedAt DESC (Newest First)
              const sortedUsers = [...cloudUsers].sort((a,b) => {
                  const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                  const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                  return dateB - dateA;
              });

              setUsers(sortedUsers);
              prevUsersRef.current = sortedUsers;
              localStorage.setItem('nst_users', JSON.stringify(sortedUsers));
          }
      });

      // SUBSCRIBE TO RECOVERY REQUESTS (Live Sync)
      const reqRef = ref(rtdb, 'recovery_requests');
      const unsubReqs = onValue(reqRef, (snapshot) => {
          const data = snapshot.val();
          if (data) {
              const reqList: RecoveryRequest[] = Object.values(data);
              setRecoveryRequests(reqList.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
          } else {
              setRecoveryRequests([]);
          }
      });

      // SUBSCRIBE TO DEMANDS (Live Sync)
      const unsubDemands = subscribeToDemands((liveDemands) => {
          setDemands(liveDemands);
      });

      return () => {
          clearInterval(interval);
          unsubUsers();
          unsubReqs();
          if (unsubDemands) unsubDemands();
      };
  }, []);

  useEffect(() => {
      if (activeTab === 'DATABASE') {
          setDbContent(localStorage.getItem(dbKey) || '');
      }
  }, [activeTab, dbKey]);

  // Clear selections when switching main tabs
  useEffect(() => {
      if (!['SYLLABUS_MANAGER', 'CONTENT_PDF', 'CONTENT_VIDEO', 'CONTENT_MCQ', 'CONTENT_TEST', 'CONTENT_NOTES', 'BULK_UPLOAD'].includes(activeTab)) {
          setSelSubject(null);
          setEditingChapterId(null);
      }
  }, [activeTab]);

  const handleCropComplete = (croppedImage: string) => {
      setLocalSettings({ ...localSettings, appLogo: croppedImage });
      setCropImageSrc(null);
  };

  const loadData = () => {
      const savedBloggerCode = localStorage.getItem('nst_custom_blogger_page');
      if (savedBloggerCode) setCustomBloggerCode(savedBloggerCode);

      const storedUsersStr = localStorage.getItem('nst_users');
      if (storedUsersStr) setUsers(JSON.parse(storedUsersStr));
      
      // const reqStr = localStorage.getItem('nst_recovery_requests');
      // if (reqStr) setRecoveryRequests(JSON.parse(reqStr));

      const logsStr = localStorage.getItem('nst_activity_log');
      if (logsStr) setLogs(JSON.parse(logsStr));

      const codesStr = localStorage.getItem('nst_admin_codes');
      if (codesStr) setGiftCodes(JSON.parse(codesStr));

      const subStr = localStorage.getItem('nst_custom_subjects_pool');
      if (subStr) setCustomSubjects(JSON.parse(subStr));

      const binStr = localStorage.getItem('nst_recycle_bin');
      if (binStr) {
          const binItems: RecycleBinItem[] = JSON.parse(binStr);
          const now = new Date();
          const validItems = binItems.filter(item => new Date(item.expiresAt) > now);
          if (validItems.length !== binItems.length) {
              localStorage.setItem('nst_recycle_bin', JSON.stringify(validItems));
          }
          setRecycleBin(validItems);
      }

      const boardNotesStr = localStorage.getItem('nst_board_notes');
      if (boardNotesStr) setBoardNotes(JSON.parse(boardNotesStr));

  };

  // --- AI AUTO-PILOT LOGIC ---



  // --- SETTINGS HANDLERS ---
  // --- DRAGGABLE BUTTON STATE ---
  const [buttonPos, setButtonPos] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number } | null>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: buttonPos.x,
      initialY: buttonPos.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !dragRef.current) return;
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      setButtonPos({
        x: dragRef.current.initialX + dx,
        y: dragRef.current.initialY + dy,
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      dragRef.current = null;
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);






  const handleSaveSettings = async (overrideSettings?: SystemSettings | any) => {
      if (isSettingsSaving) return;
      setIsSettingsSaving(true);

      let safeSettings = overrideSettings;
      // Prevent Event object from being treated as settings
      if (safeSettings && (safeSettings.nativeEvent || safeSettings.type === 'click')) {
          safeSettings = undefined;
      }

      const settingsToUse = safeSettings || localSettings;

      try {
          if (onUpdateSettings) {
              const settingsToSave = { ...settingsToUse };
              delete settingsToSave.apiKeys; // REMOVE KEYS FROM PUBLIC

              onUpdateSettings(settingsToUse);
              localStorage.setItem('nst_system_settings', JSON.stringify(settingsToSave));

              // SYNC TO FIREBASE (Attempt always, ignore isFirebaseConnected which can be unreliable)
              try {
                  await saveSystemSettings(settingsToSave);

                  // SAVE TO GLOBAL RTDB (Secure Recovery Path)
                  set(ref(rtdb, 'secure_keys/list'), settingsToUse.groqApiKeys || [])
                    .then(() => console.log("✅ Keys secured in Global Recovery Path"))
                    .catch(e => console.error("Key Backup Error:", e));

                  setAlertConfig({isOpen: true, message: "✅ Settings Saved to Cloud Successfully!"});
              } catch (cloudError: any) {
                  console.error("Cloud Save Error:", cloudError);
                  // Since Firebase JS SDK offline mode might buffer writes, we let it try anyway.
                  setAlertConfig({isOpen: true, message: "⚠️ Cloud Save Requested. If offline, it will sync when connected. Error: " + cloudError.message});
              }

              logActivity("SETTINGS_UPDATE", "Updated system settings");
          }
      } catch (error: any) {
          console.error("Save Failed:", error);
          setAlertConfig({isOpen: true, message: "❌ FAILED TO SAVE SETTINGS: " + error.message});
      } finally {
          setIsSettingsSaving(false);
      }
  };

  const toggleSetting = (key: keyof SystemSettings) => {
      const newVal = !localSettings[key];
      const updated = { ...localSettings, [key]: newVal };
      setLocalSettings(updated);
      if(onUpdateSettings) onUpdateSettings(updated);
      localStorage.setItem('nst_system_settings', JSON.stringify(updated));
      logActivity("SETTINGS_TOGGLED", `Toggled ${key} to ${newVal}`);
      handleSaveSettings(updated);
  };

  const toggleItemInList = <T extends string>(list: T[] | undefined, item: T): T[] => {
      const current = list || [];
      return current.includes(item) ? current.filter(i => i !== item) : [...current, item];
  };


  // --- RECYCLE BIN HANDLERS ---
  const softDelete = (type: RecycleBinItem['type'], name: string, data: any, originalKey?: string, originalId?: string) => {
      if (!window.confirm(`DELETE "${name}"?\n(Moved to Recycle Bin for 90 days)`)) return false;

      const newItem: RecycleBinItem = {
          id: Date.now().toString(),
          originalId: originalId || Date.now().toString(),
          type,
          name,
          data,
          deletedAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
          restoreKey: originalKey
      };

      const newBin = [...recycleBin, newItem];
      setRecycleBin(newBin);
      localStorage.setItem('nst_recycle_bin', JSON.stringify(newBin));
      return true;
  };

  const handleRestoreItem = (item: RecycleBinItem) => {
      if (!window.confirm(`Restore "${item.name}"?`)) return;

      if (item.type === 'USER') {
          const stored = localStorage.getItem('nst_users');
          const users: User[] = stored ? JSON.parse(stored) : [];
          if (!users.some(u => u.id === item.data.id)) {
              users.push(item.data);
              localStorage.setItem('nst_users', JSON.stringify(users));
          } else {
              alert("User ID already exists. Cannot restore.");
              return;
          }
      } else if (item.type === 'MCQ_BATCH' && item.restoreKey) {
          const stored = localStorage.getItem(item.restoreKey);
          const current = stored ? JSON.parse(stored) : {};
          const isTest = item.data.isTest;
          if (isTest) {
              current.weeklyTestMcqData = [...(current.weeklyTestMcqData || []), ...item.data.mcqs];
          } else {
              current.manualMcqData = [...(current.manualMcqData || []), ...item.data.mcqs];
          }
          localStorage.setItem(item.restoreKey, JSON.stringify(current));
          if (isFirebaseConnected) saveChapterData(item.restoreKey, current);

      } else if (item.restoreKey) {
          if (item.type === 'CHAPTER') {
              const listStr = localStorage.getItem(item.restoreKey);
              const list = listStr ? JSON.parse(listStr) : [];
              list.push(item.data);
              localStorage.setItem(item.restoreKey, JSON.stringify(list));
          } else {
              localStorage.setItem(item.restoreKey, JSON.stringify(item.data));
          }
      }

      const newBin = recycleBin.filter(i => i.id !== item.id);
      setRecycleBin(newBin);
      localStorage.setItem('nst_recycle_bin', JSON.stringify(newBin));
      alert("Item Restored!");
      loadData(); 
  };

  const handlePermanentDelete = (id: string) => {
      if (window.confirm("PERMANENTLY DELETE? This cannot be undone.")) {
          const newBin = recycleBin.filter(i => i.id !== id);
          setRecycleBin(newBin);
          localStorage.setItem('nst_recycle_bin', JSON.stringify(newBin));
      }
  };

  // --- USER MANAGEMENT (Enhanced) ---
  const deleteUser = async (userId: string) => {
      const userToDelete = users.find(u => u.id === userId);
      if (!userToDelete) return;
      if (softDelete('USER', userToDelete.name, userToDelete, undefined, userToDelete.id)) {
          // Local Update
          const updated = users.filter(u => u.id !== userId);
          setUsers(updated);
          localStorage.setItem('nst_users', JSON.stringify(updated));
          
          // Cloud Update
          if (isFirebaseConnected) {
              try {
                  await deleteDoc(doc(db, "users", userId));
              } catch(e) { console.error("Cloud Delete Error:", e); }
          }

          logActivity("USER_DELETE", `Moved user ${userId} to Recycle Bin`);
      }
  };

  const openEditUser = (user: User) => {
      setEditingUser(user);
      setEditUserCredits(user.credits);
      setEditUserPass(user.password);
      setEditSubscriptionTier(user.subscriptionTier || 'FREE');
      setEditSubscriptionLevel(user.subscriptionLevel || 'BASIC');
      
      // Default customized values based on tier
      if (user.subscriptionTier === 'WEEKLY') setEditSubscriptionDays(7);
      else if (user.subscriptionTier === 'MONTHLY') setEditSubscriptionDays(30);
      else if (user.subscriptionTier === '3_MONTHLY') setEditSubscriptionDays(90);
      else if (user.subscriptionTier === 'YEARLY') setEditSubscriptionDays(365);
      else setEditSubscriptionDays(0);
      
      setEditSubscriptionHours(0);
      setEditSubscriptionMinutes(0);
      setEditSubscriptionSeconds(0);
      
      // Auto-fill price from store settings with Discount Logic
      if (user.subscriptionTier && user.subscriptionTier !== 'FREE' && user.subscriptionTier !== 'CUSTOM') {
          const tierPrices = subPrices[user.subscriptionTier as keyof typeof subPrices];
          const level = user.subscriptionLevel || 'BASIC';
          let basePrice = tierPrices ? tierPrices[level as keyof typeof tierPrices] : 0;

          // Apply Event Discount + Renewal Bonus Logic (Same as Store.tsx)
          const event = localSettings.specialDiscountEvent;
          let discountPercentVal = 0;
          const isSubscribed = user.isPremium && user.subscriptionEndDate && new Date(user.subscriptionEndDate) > new Date();

          // 1. Check Event Validity
          let isEventActive = !!event?.enabled; // Assume true if enabled
          if (event?.enabled && event.startsAt && event.endsAt) {
              const now = Date.now();
              const startTime = new Date(event.startsAt).getTime();
              const endTime = new Date(event.endsAt).getTime();
              if (startTime === endTime) {
                  isEventActive = now >= startTime;
              } else {
                  isEventActive = now >= startTime && now < endTime;
              }
          }

          if (isEventActive) {
              if ((isSubscribed && event?.showToPremiumUsers) || (!isSubscribed && event?.showToFreeUsers)) {
                  discountPercentVal += (event?.discountPercent || 0);
              }
          }

          // 2. Renewal Bonus (Check Premium or History)
          if (user.isPremium || (user.subscriptionHistory && user.subscriptionHistory.length > 0)) {
              discountPercentVal += 5;
          }

          if (discountPercentVal > 0) {
              basePrice = Math.round(basePrice * (1 - discountPercentVal / 100));
          }

          setEditSubscriptionPrice(basePrice);
      } else {
          setEditSubscriptionPrice(0);
      }
      
      setEditCustomSubName(user.customSubscriptionName || '');
  };

  const saveEditedUser = async () => {
      if (!editingUser) return;
      
      let endDate = undefined;
      const now = new Date();
      if (editSubscriptionTier !== 'FREE') {
          if (editSubscriptionTier === 'WEEKLY') {
              endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === 'MONTHLY') {
              endDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === '3_MONTHLY') {
              endDate = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === 'YEARLY') {
              endDate = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === 'LIFETIME') {
              endDate = new Date(now.getTime() + 5 * 365 * 24 * 60 * 60 * 1000); // 5 Years
          } else if (editSubscriptionTier === 'CUSTOM') {
              const totalMs = (editSubscriptionYears * 365 * 24 * 60 * 60 * 1000) +
                              (editSubscriptionMonths * 30 * 24 * 60 * 60 * 1000) +
                              (editSubscriptionDays * 24 * 60 * 60 * 1000) + 
                              (editSubscriptionHours * 60 * 60 * 1000) + 
                              (editSubscriptionMinutes * 60 * 1000) +
                              (editSubscriptionSeconds * 1000);
              endDate = new Date(now.getTime() + totalMs);
          }
      }

      const isoEndDate = endDate ? endDate.toISOString() : (endDate === null ? undefined : undefined);

      // RECORD HISTORY
      let newHistory = editingUser.subscriptionHistory || [];
      if (editSubscriptionTier !== 'FREE') {
          const historyEntry: SubscriptionHistoryEntry = {
              id: `hist-${Date.now()}`,
              tier: editSubscriptionTier,
              level: editSubscriptionLevel,
              startDate: now.toISOString(),
              endDate: isoEndDate || 'LIFETIME',
              durationHours: endDate ? Math.round((endDate.getTime() - now.getTime()) / (1000 * 60 * 60)) : 999999,
              price: 0,
              originalPrice: editSubscriptionPrice,
              isFree: true,
              grantSource: 'ADMIN'
          };
          newHistory = [historyEntry, ...newHistory];
      }

      const updatedUser: User = { 
          ...editingUser, 
          credits: editUserCredits, 
          password: editUserPass,
          subscriptionTier: editSubscriptionTier,
          subscriptionLevel: editSubscriptionLevel,
          subscriptionEndDate: isoEndDate,
          subscriptionPrice: editSubscriptionPrice,
          grantedByAdmin: true,
          isPremium: editSubscriptionTier !== 'FREE',
          subscriptionHistory: newHistory,
          customSubscriptionName: editSubscriptionTier === 'CUSTOM' ? editCustomSubName : undefined,
          customSubscriptionDuration: editSubscriptionTier === 'CUSTOM' ? {
              years: editSubscriptionYears,
              months: editSubscriptionMonths,
              days: editSubscriptionDays,
              hours: editSubscriptionHours,
              minutes: editSubscriptionMinutes,
              seconds: editSubscriptionSeconds
          } : undefined
      };
      // 1. Determine GRANT MODE
      // The logic is moved to `handleGrantSubscription`. This function is deprecated or replaced.
      return; 
  };

  const handleGrantSubscription = async (mode: 'FREE' | 'PAID') => {
      if (!editingUser) return;
      
      let endDate = undefined;
      const now = new Date();
      
      if (editSubscriptionTier !== 'FREE') {
          if (editSubscriptionTier === 'WEEKLY') {
              endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === 'MONTHLY') {
              endDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === '3_MONTHLY') {
              endDate = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === 'YEARLY') {
              endDate = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
          } else if (editSubscriptionTier === 'LIFETIME') {
              endDate = new Date(now.getTime() + 5 * 365 * 24 * 60 * 60 * 1000); // 5 Years
          } else if (editSubscriptionTier === 'CUSTOM') {
              const totalMs = (editSubscriptionYears * 365 * 24 * 60 * 60 * 1000) +
                              (editSubscriptionMonths * 30 * 24 * 60 * 60 * 1000) +
                              (editSubscriptionDays * 24 * 60 * 60 * 1000) + 
                              (editSubscriptionHours * 60 * 60 * 1000) + 
                              (editSubscriptionMinutes * 60 * 1000) +
                              (editSubscriptionSeconds * 1000);
              endDate = new Date(now.getTime() + totalMs);
          }
      }

      const isoEndDate = endDate ? endDate.toISOString() : (endDate === null ? undefined : undefined);

      // RECORD HISTORY
      let newHistory = editingUser.subscriptionHistory || [];
      if (editSubscriptionTier !== 'FREE') {
          const historyEntry: SubscriptionHistoryEntry = {
              id: `hist-${Date.now()}`,
              tier: editSubscriptionTier,
              level: editSubscriptionLevel,
              startDate: now.toISOString(),
              endDate: isoEndDate || 'LIFETIME',
              durationHours: endDate ? Math.round((endDate.getTime() - now.getTime()) / (1000 * 60 * 60)) : 999999,
              price: mode === 'PAID' ? editSubscriptionPrice : 0,
              originalPrice: editSubscriptionPrice,
              isFree: mode === 'FREE',
              grantSource: mode === 'FREE' ? 'ADMIN' : 'PURCHASE',
              grantedBy: currentUser?.id,
              grantedByName: currentUser?.name
          };
          newHistory = [historyEntry, ...newHistory];
      }

      const updatedUser: User = { 
          ...editingUser, 
          credits: editUserCredits, 
          password: editUserPass,
          subscriptionTier: editSubscriptionTier,
          subscriptionLevel: editSubscriptionLevel,
          subscriptionEndDate: isoEndDate,
          subscriptionPrice: editSubscriptionPrice,
          grantedByAdmin: mode === 'FREE',
          isPremium: editSubscriptionTier !== 'FREE',
          subscriptionHistory: newHistory,
          customSubscriptionName: editSubscriptionTier === 'CUSTOM' ? editCustomSubName : undefined,
          customSubscriptionDuration: editSubscriptionTier === 'CUSTOM' ? {
              years: editSubscriptionYears,
              months: editSubscriptionMonths,
              days: editSubscriptionDays,
              hours: editSubscriptionHours,
              minutes: editSubscriptionMinutes,
              seconds: editSubscriptionSeconds
          } : undefined
      };

      const updatedList = users.map(u => u.id === editingUser.id ? updatedUser : u);
      setUsers(updatedList);
      localStorage.setItem('nst_users', JSON.stringify(updatedList));

      // Cloud Sync
      if (isFirebaseConnected) {
          await saveUserToLive(updatedUser);
      }

      setEditingUser(null);
      alert(`✅ ${editingUser.name} subscription updated! (${mode} Grant)`);
  };

  const sendDirectMessage = async () => {
      if (!dmUser || !dmText) return;
      
      let giftPayload = undefined;
      if (giftType !== 'NONE') {
          giftPayload = {
              type: giftType,
              value: giftValue,
              durationHours: giftDuration
          };
      }

      const newMsg = { 
          id: `msg-${Date.now()}`, 
          text: dmText, 
          date: new Date().toISOString(), 
          read: false,
          type: giftType !== 'NONE' ? 'GIFT' : 'TEXT',
          gift: giftPayload,
          isClaimed: false
      };

      const updatedUser = { ...dmUser, inbox: [newMsg, ...(dmUser.inbox || [])] };
      const updatedList = users.map(u => u.id === dmUser.id ? updatedUser : u);
      setUsers(updatedList);
      localStorage.setItem('nst_users', JSON.stringify(updatedList));
      
      // Cloud Sync
      if (isFirebaseConnected) {
          await saveUserToLive(updatedUser);
      }

      setDmUser(null);
      setDmText('');
      setGiftType('NONE');
      alert("Message & Gift Sent!");
  };

  // --- GIFT CODE MANAGER (New) ---
  const generateCodes = async () => {
      // Allow force try even if status is offline (navigator.onLine can be flaky)
      if (!isFirebaseConnected && !confirm("System appears offline. Try to generate codes anyway?")) {
          return;
      }

      if (newCodeType === 'CONTENT_UNLOCK' && !newCodeContentChapter) {
          alert("Please select a Chapter to unlock.");
          return;
      }

      const newCodes: GiftCode[] = [];
      
      try {
          for (let i = 0; i < (newCodeCount || 1); i++) {
              // Generate 12-char random mixed case string (Simpler and reliable)
              const codeChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Exclude ambiguous chars like O, 0, I, 1
              let code = generateSecureRandomString(12, codeChars);

              let prefix = 'C';
              if (newCodeType === 'CONTENT_UNLOCK') {
                  if (newCodeContentType === 'VIDEO') prefix = 'V';
                  if (newCodeContentType === 'PDF') prefix = 'N';
                  if (newCodeContentType === 'MCQ') prefix = 'M';
                  if (newCodeContentType === 'AUDIO') prefix = 'A';
                  code = prefix + '-' + code.substring(0, 8);
              }

              const newGiftCode: GiftCode = {
                  id: Date.now().toString() + i,
                  code: code.toUpperCase(),
                  type: newCodeType || 'CREDITS',
                  ...(newCodeType === 'CREDITS' ? { amount: newCodeAmount || 10 } : {}),
                  ...(newCodeType === 'DISCOUNT' ? { discountPercent: newCodeDiscount || 10 } : {}),
                  ...(newCodeType === 'SUBSCRIPTION' ? { subTier: newCodeSubTier || 'WEEKLY', subLevel: newCodeSubLevel || 'BASIC' } : {}),
                  ...(newCodeType === 'CONTENT_UNLOCK' ? { contentId: newCodeContentChapter, contentType: newCodeContentType } : {}),
                  createdAt: new Date().toISOString(),
                  isRedeemed: false,
                  generatedBy: 'ADMIN',
                  maxUses: newCodeMaxUses || 1,
                  usedCount: 0,
                  redeemedBy: []
              };
              newCodes.push(newGiftCode);
              // Write to Firestore first (admin has guaranteed create permission), RTDB as backup
              let saved = false;
              try {
                  await setDoc(doc(db, 'redeem_codes', newGiftCode.code), newGiftCode);
                  saved = true;
              } catch (fsError) {
                  console.warn("Firestore setDoc failed, trying RTDB:", fsError);
              }
              if (!saved) {
                  try {
                      await set(ref(rtdb, `redeem_codes/${newGiftCode.code}`), newGiftCode);
                      saved = true;
                  } catch (dbError) {
                      console.error("RTDB Set Error:", dbError);
                      throw dbError;
                  }
              }
              // Also mirror to RTDB for fast reads (best-effort)
              if (saved) {
                  try { await set(ref(rtdb, `redeem_codes/${newGiftCode.code}`), newGiftCode); } catch (_) {}
              }
          }
          const updated = [...newCodes, ...giftCodes];
          setGiftCodes(updated);
          localStorage.setItem('nst_admin_codes', JSON.stringify(updated));
          alert(`${newCodeCount} Codes Generated Successfully!`);
      } catch (error: any) {
          console.error("Code Generation Error:", error);
          alert(`Failed to generate codes: ${error.message}`);
      }
  };

  const deleteCode = (id: string) => {
      const updated = giftCodes.filter(c => c.id !== id);
      setGiftCodes(updated);
      localStorage.setItem('nst_admin_codes', JSON.stringify(updated));
  };

  // --- SUBJECT MANAGER (New) ---
  const addSubject = () => {
      if (!newSubName) return;
      const id = (newSubName || '').toLowerCase().replace(/\s+/g, '');
      const newSubject = { id, name: newSubName, icon: newSubIcon, color: newSubColor };
      const updatedPool = { ...DEFAULT_SUBJECTS, ...customSubjects, [id]: newSubject };
      setCustomSubjects(updatedPool); // This only stores custom ones technically in state, but logic handles merge
      localStorage.setItem('nst_custom_subjects_pool', JSON.stringify(updatedPool));
      setNewSubName('');
      alert("Subject Added!");
  };

  // --- PACKAGE MANAGER (New) ---
  const addPackage = () => {
      if (!newPkgName || !newPkgPrice || !newPkgCredits) return;
      const newPkg = {
          id: `pkg-${Date.now()}`,
          name: newPkgName,
          price: Number(newPkgPrice),
          credits: Number(newPkgCredits),
          dummyPrice: newPkgDummyPrice ? Number(newPkgDummyPrice) : undefined
      };
      const currentPkgs = localSettings.packages || [];
      const updatedPkgs = [...currentPkgs, newPkg];
      setLocalSettings({ ...localSettings, packages: updatedPkgs });
      setNewPkgName(''); setNewPkgPrice(''); setNewPkgCredits(''); setNewPkgDummyPrice('');
  };

  const removePackage = (id: string) => {
      const currentPkgs = localSettings.packages || [];
      setLocalSettings({ ...localSettings, packages: currentPkgs.filter(p => p.id !== id) });
  };

  // --- CONTENT & SYLLABUS LOGIC ---
  const handleDownloadFullSyllabus = () => {
      const blob = new Blob([JSON.stringify(STATIC_SYLLABUS, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `full_syllabus_v${APP_VERSION}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      alert("Full Syllabus Downloaded!");
  };

  const handleCopyFullSyllabus = () => {
      let text = "FULL APP SYLLABUS\n=================\n\n";
      Object.keys(STATIC_SYLLABUS).sort().forEach(key => {
          text += `[ ${key} ]\n`;
          // @ts-ignore
          const items = STATIC_SYLLABUS[key];
          if (Array.isArray(items)) {
              items.forEach((item: string, i: number) => {
                  text += `${i + 1}. ${item}\n`;
              });
          }
          text += "\n";
      });
      navigator.clipboard.writeText(text);
      alert("Full Syllabus Copied to Clipboard!");
  };

  const handleSubjectClick = async (s: Subject) => {
      setSelSubject(s);
      setIsLoadingChapters(true);
      try {
          const lang = selBoard === 'BSEB' ? 'Hindi' : 'English';
          const ch = await fetchChapters(selBoard, selClass, selStream, s, lang);
          setSelChapters(ch);
          
          if (activeTab === 'BULK_UPLOAD') {
              const streamKey = (selClass === '11' || selClass === '12') ? `-${selStream}` : '';
              const tempBulk: any = {};
              ch.forEach(c => {
                  const key = `nst_content_${selBoard}_${selClass}${streamKey}_${s.name}_${c.id}`;
                  const stored = localStorage.getItem(key);
                  if (stored) {
                      const d = JSON.parse(stored);
                      tempBulk[c.id] = { free: d.freeLink || '', premium: d.premiumLink || '', price: d.price || 5 };
                  } else {
                      tempBulk[c.id] = { free: '', premium: '', price: 5 };
                  }
              });
              setBulkData(tempBulk);
          }

      } catch (e) { console.error(e); setSelChapters([]); }
      setIsLoadingChapters(false);
  };

  const loadChapterContent = async (chId: string) => {
      setEditingChapterId(chId); 
      setIsContentLoading(true); // Lock inputs
      
      // STRICT KEY MATCHING (Must match VideoPlaylistView logic)
      const streamKey = (selClass === '11' || selClass === '12') && selStream ? `-${selStream}` : '';
      const key = `nst_content_${selBoard}_${selClass}${streamKey}_${selSubject?.name}_${chId}`;
      
      // 1. Try Local First (Instant Load)
      const stored = await storage.getItem(key);
      if (stored) {
          applyContentData(stored);
      } else {
          // Default State
          setEditConfig({ freeLink: '', premiumLink: '', price: 5 });
          setEditingMcqs([]);
          setEditingTestMcqs([]);
          setVideoPlaylist([]);
          setPremiumVideoPlaylist([]);
          setAudioPlaylist([]);
          setDeepDiveEntries([]);
          setAdditionalNotes([]);
      }

      // 2. Fetch from Cloud (Background Sync to ensure Persistence)
      if (isFirebaseConnected) {
          try {
              const cloudData = await getChapterData(key);
              if (cloudData) {
                  // Update Storage & State with Cloud Data (Source of Truth)
                  await storage.setItem(key, cloudData);
                  applyContentData(cloudData);
              }
          } catch(e) { console.error("Cloud Fetch Error", e); }
      }
      setIsContentLoading(false); // Unlock inputs
  };

  const applyContentData = (data: any) => {
      setEditConfig(data);
      setEditingMcqs(data.manualMcqData || []);
      setEditingTestMcqs(data.weeklyTestMcqData || []);
      
      // Load based on CURRENT mode (default SCHOOL)
      // STRICT SEPARATION: Only fallback to legacy for SCHOOL mode
      if (syllabusMode === 'SCHOOL') {
          setVideoPlaylist(data.schoolVideoPlaylist || data.videoPlaylist || []);
          setPremiumVideoPlaylist(data.schoolPremiumVideoPlaylist || []);
          setAudioPlaylist(data.schoolAudioPlaylist || data.audioPlaylist || []); 
          setPremiumNoteSlots(data.schoolPdfPremiumSlots || data.premiumNoteSlots || []);
          setFreeNotesList(data.schoolFreeNotesList || []);
          setPremiumNotesList(data.schoolPremiumNotesList || []);

          setDeepDiveEntries(data.schoolDeepDiveEntries || data.deepDiveEntries || []);
          setAdditionalNotes(data.schoolAdditionalNotes || data.additionalNotes || []);
      } else {
          setVideoPlaylist(data.competitionVideoPlaylist || []); // No fallback
          setPremiumVideoPlaylist(data.competitionPremiumVideoPlaylist || []);
          setAudioPlaylist(data.competitionAudioPlaylist || []); // No fallback
          setPremiumNoteSlots(data.competitionPdfPremiumSlots || []); // No fallback
          setFreeNotesList(data.competitionFreeNotesList || []);
          setPremiumNotesList(data.competitionPremiumNotesList || []);

          setDeepDiveEntries(data.competitionDeepDiveEntries || []);
          setAdditionalNotes(data.competitionAdditionalNotes || []);
      }

      // Load Topic Content (Shared)
      setTopicNotes(data.topicNotes || []);
      setTopicVideos(data.topicVideos || []);
      setTeachingStrategyHtml(data.teachingStrategyHtml || '');
      setTeachingStrategyNotes(data.teachingStrategyNotes || []);
  };


  const generateDirectCode = (type: 'NOTES' | 'VIDEO' | 'AUDIO' | 'MCQ' | 'TOPIC_NOTE', contentId: string) => {
      setCodeModal({
          isOpen: true,
          type,
          contentId,
          title: `Generate Code for ${type}`
      });
      // Defaults
      setCodeDuration(24);
      setCodeMaxUses(1);
  };

  // --- UPDATED BULK SAVE FUNCTION (WRITES TO FIREBASE) ---
  const saveBulkData = async () => {
      if (!selSubject) return;
      const streamKey = (selClass === '11' || selClass === '12') ? `-${selStream}` : '';
      
      const updates: Record<string, any> = {};

      Object.keys(bulkData).forEach(chId => {
          const d = bulkData[chId];
          const key = `nst_content_${selBoard}_${selClass}${streamKey}_${selSubject.name}_${chId}`;
          const existing = localStorage.getItem(key);
          const existingData = existing ? JSON.parse(existing) : {};
          
          const newData = {
              ...existingData,
              freeLink: d.free,
              premiumLink: d.premium,
              price: d.price
          };
          localStorage.setItem(key, JSON.stringify(newData));
          updates[key] = newData;
      });

      try {
          await bulkSaveLinks(updates); 
          if (!isFirebaseConnected) {
              alert(`✅ Saved links for ${Object.keys(bulkData).length} chapters locally. Will sync to CLOUD when online.`);
          } else {
              alert(`✅ Saved links for ${Object.keys(bulkData).length} chapters to CLOUD!\n\nStudents will see these updates instantly without redownloading the app.`);
          }
      } catch(e) {
          console.error("Bulk Save Error", e);
          alert("⚠️ Saved Locally ONLY. Cloud sync failed.");
      }
  };

  const saveSyllabusList = async () => {
      if (!selSubject) return;
      const streamKey = (selClass === '11' || selClass === '12') && selStream ? `-${selStream}` : '';
      const baseKey = `${selBoard}-${selClass}${streamKey}-${selSubject.name}`;
      
      const cacheKey = `nst_custom_chapters_${baseKey}-English`;
      localStorage.setItem(cacheKey, JSON.stringify(selChapters));
      // Save Hindi fallback
      const cacheKeyHindi = `nst_custom_chapters_${baseKey}-Hindi`;
      localStorage.setItem(cacheKeyHindi, JSON.stringify(selChapters));

      try {
          await saveCustomSyllabus(`${baseKey}-English`, selChapters);
          await saveCustomSyllabus(`${baseKey}-Hindi`, selChapters);
          if (!isFirebaseConnected) {
              alert("✅ Syllabus Structure Saved Locally (Queued for Cloud)");
          } else {
              alert("✅ Syllabus Structure Saved to Cloud!");
          }
      } catch(e) {
          console.error("Syllabus Save Error", e);
          alert("⚠️ Syllabus Saved Locally ONLY. Cloud sync failed.");
      }
  };

  const deleteChapter = (idx: number) => {
      const ch = selChapters[idx];
      const streamKey = (selClass === '11' || selClass === '12') ? `-${selStream}` : '';
      const cacheKey = `nst_custom_chapters_${selBoard}-${selClass}${streamKey}-${selSubject?.name}-English`;
      
      if (softDelete('CHAPTER', ch.title, ch, cacheKey)) {
          const updated = selChapters.filter((_, i) => i !== idx);
          setSelChapters(updated);
      }
  };

  const handleConfirmMoveChapter = async () => {
      if (!movingChapter || !moveTargetSubject || !selSubject) return;

      const confirmMsg = `Are you sure you want to move "${movingChapter.chapter.title}" to ${moveTargetClass} - ${moveTargetSubject.name}?`;
      if (!window.confirm(confirmMsg)) return;

      setIsMoving(true);
      try {
          // 1. Fetch Old Data
          const oldStreamKey = (selClass === '11' || selClass === '12') && selStream ? `-${selStream}` : '';
          const oldContentKey = `nst_content_${selBoard}_${selClass}${oldStreamKey}_${selSubject.name}_${movingChapter.chapter.id}`;
          const oldData = await getChapterData(oldContentKey);

          // 2. Compute New Keys
          const newStreamKey = (moveTargetClass === '11' || moveTargetClass === '12') && moveTargetStream ? `-${moveTargetStream}` : '';
          const newSyllabusBaseKey = `${moveTargetBoard}-${moveTargetClass}${newStreamKey}-${moveTargetSubject.name}`;
          const newContentKey = `nst_content_${moveTargetBoard}_${moveTargetClass}${newStreamKey}_${moveTargetSubject.name}_${movingChapter.chapter.id}`;

          // 3. Save Data to New Key
          if (oldData) {
              await saveChapterData(newContentKey, oldData);
          }

          // 4. Update Target Syllabus
          let targetSyllabus = await fetchChapters(moveTargetBoard, moveTargetClass, moveTargetStream, moveTargetSubject, 'English');
          targetSyllabus.push(movingChapter.chapter);
          await saveCustomSyllabus(`${newSyllabusBaseKey}-English`, targetSyllabus);
          await saveCustomSyllabus(`${newSyllabusBaseKey}-Hindi`, targetSyllabus);

          // 5. Update Current Syllabus (Remove)
          const updatedCurrentSyllabus = selChapters.filter(c => c.id !== movingChapter.chapter.id);
          setSelChapters(updatedCurrentSyllabus);
          const currentSyllabusKey = `${selBoard}-${selClass}${oldStreamKey}-${selSubject.name}`;
          await saveCustomSyllabus(`${currentSyllabusKey}-English`, updatedCurrentSyllabus);
          await saveCustomSyllabus(`${currentSyllabusKey}-Hindi`, updatedCurrentSyllabus);

          alert("✅ Chapter Moved Successfully with all content!");
          setMovingChapter(null);
      } catch (e: any) {
          console.error(e);
          alert("⚠️ Failed to move chapter: " + e.message);
      } finally {
          setIsMoving(false);
      }
  };

  // --- MCQ EDITING HELPERS ---
  const updateMcq = (isTest: boolean, idx: number, field: keyof MCQItem, val: any) => {
      const list = isTest ? editingTestMcqs : editingMcqs;
      const updated = [...list];
      updated[idx] = { ...updated[idx], [field]: val };
      isTest ? setEditingTestMcqs(updated) : setEditingMcqs(updated);
  };
  const updateMcqOption = (isTest: boolean, qIdx: number, oIdx: number, val: string) => {
      const list = isTest ? editingTestMcqs : editingMcqs;
      const updated = [...list];
      updated[qIdx].options[oIdx] = val;
      isTest ? setEditingTestMcqs(updated) : setEditingMcqs(updated);
  };
  const addMcq = (isTest: boolean) => {
      const newItem: MCQItem = { question: 'New Question', options: ['A','B','C','D'], correctAnswer: 0, explanation: '' };
      isTest ? setEditingTestMcqs([...editingTestMcqs, newItem]) : setEditingMcqs([...editingMcqs, newItem]);
  };
  const removeMcq = (isTest: boolean, idx: number) => {
      const list = isTest ? editingTestMcqs : editingMcqs;
      const updated = list.filter((_, i) => i !== idx);
      isTest ? setEditingTestMcqs(updated) : setEditingMcqs(updated);
  };

  const deleteAllMcqs = (isTest: boolean) => {
      const list = isTest ? editingTestMcqs : editingMcqs;
      if (list.length === 0) return;
      
      if (!window.confirm(`DELETE ALL ${list.length} Questions?\nThey will be moved to Recycle Bin.`)) return;

      const streamKey = (selClass === '11' || selClass === '12') && selStream ? `-${selStream}` : '';
      const key = `nst_content_${selBoard}_${selClass}${streamKey}_${selSubject?.name}_${editingChapterId}`;
      
      if (softDelete('MCQ_BATCH', `${isTest ? 'Test' : 'Practice'} MCQs (${list.length}) - ${selSubject?.name}`, { mcqs: list, isTest }, key)) {
          isTest ? setEditingTestMcqs([]) : setEditingMcqs([]);
      }
  };

  // --- GOOGLE SHEET IMPORT HANDLER (ROBUST & ASYNC) ---
  const handleGoogleSheetImport = (isTest: boolean) => {
      if (!importText.trim()) {
          alert("Please paste data first!");
          return;
      }

      setIsContentLoading(true); // Lock UI

      // Use timeout to allow UI render before heavy processing
      setTimeout(() => {
          try {
              const rawText = importText.trim();

              const parsed = parseMCQText(rawText);
              let newQuestions: MCQItem[] = parsed.questions;

              // If it didn't find any questions using the new robust parser, fallback to old TSV/Vertical logic
              if (newQuestions.length === 0) {
                  // MODE A: Tab-Separated (Excel/Sheets/Copy-Paste) - PREFERRED
                  if (rawText.includes('\t')) {
                  const rows = rawText.split('\n').filter(r => r.trim());
                  newQuestions = rows.map((row, idx) => {
                      let cols = row.split('\t');
                      
                      // Handle mixed CSV fallback
                      if (cols.length < 3 && row.includes(',')) cols = row.split(',');

                      cols = cols.map(c => c.trim());

                      // Flexible Column Check (Min: Q + 4 Opts + Ans = 6)
                      if (cols.length < 6) {
                          // Skip invalid rows gracefully in bulk mode, or log error
                          console.warn(`Row ${idx + 1} invalid. Found ${cols.length} columns.`);
                          return null; 
                      }

                      // Parse Answer (1-4 or A-D)
                      let ansIdx = parseInt(cols[5]) - 1;
                      if (isNaN(ansIdx)) {
                          const map: any = { 'A': 0, 'B': 1, 'C': 2, 'D': 3, 'a': 0, 'b': 1, 'c': 2, 'd': 3 };
                          if (map[cols[5]] !== undefined) ansIdx = map[cols[5]];
                      }

                      // Check for Topic in 8th column (Index 7)
                      let topic = '';
                      if (cols.length > 7) {
                          topic = cols[7];
                      }

                      return {
                          question: cols[0],
                          options: [cols[1], cols[2], cols[3], cols[4]],
                          correctAnswer: (ansIdx >= 0 && ansIdx <= 3) ? ansIdx : 0, // Default to A if invalid
                          explanation: cols[6] || '',
                          topic: topic
                      };
                  }).filter(q => q !== null) as MCQItem[];
                  }
                  // MODE B: Vertical Block Format (Flexible for Long Explanation)
                  else {
                      const lines = rawText.split('\n').map(l => l.trim()).filter(l => l);
                      let i = 0;
                  
                  while (i < lines.length) {
                      const line = lines[i];
                      
                      // Check for Question Start
                      const isQuestionStart = QUESTION_START_REGEX.test(line) || looksLikeQuestionBlock(lines, i);

                      if (isQuestionStart) {
                          if (i + 5 >= lines.length) break;

                          // Clean Question Text (Remove Markdown ** if present)
                          const q = line.replace(/^\*\*|\*\*$/g, '');

                          const opts = [lines[i+1], lines[i+2], lines[i+3], lines[i+4]];

                          let ansLine = lines[i+5];
                          ansLine = ansLine.replace(/^\*\*|\*\*$/g, '');
                          let ansRaw = ansLine.replace(/^(Answer|Ans|Correct|उत्तर)\s*[:\s-]*\s*/i, '').trim();

                          let ansIdx = parseInt(ansRaw) - 1;
                          if (isNaN(ansIdx)) {
                              const firstChar = ansRaw.charAt(0).toUpperCase();
                              const map: any = { 'A': 0, 'B': 1, 'C': 2, 'D': 3 };
                              if (map[firstChar] !== undefined) ansIdx = map[firstChar];
                          }
                          if (ansIdx < 0 || ansIdx > 3) ansIdx = 0;

                          let expLines = [];
                          let nextIndex = i + 6;

                          while (nextIndex < lines.length) {
                              const line = lines[nextIndex];
                              const isNewQuestion = QUESTION_START_REGEX.test(line) || looksLikeQuestionBlock(lines, nextIndex);
                              if (isNewQuestion) break;
                              expLines.push(line);
                              nextIndex++;
                          }

                          let explanation = expLines.join('\n').trim();
                          // Improved Explanation Parsing
                          explanation = explanation.replace(/^\*\*/, '');
                          explanation = explanation.replace(/^(Explanation|Exp|व्याख्या)\s*[:\s-]*(\*\*)?\s*/i, '');
                          explanation = explanation.replace(/^\*\*/, '').trim();

                          let topic = '';
                          const topicMatch = explanation.match(/Topic:\s*(.*)/i);
                          if (topicMatch) {
                              topic = topicMatch[1].trim();
                              explanation = explanation.replace(/Topic:\s*.*$/im, '').trim();
                          }

                          newQuestions.push({
                              question: q,
                              options: opts,
                              correctAnswer: ansIdx,
                              explanation: explanation,
                              topic: topic
                          });

                          i = nextIndex;
                      } else {
                          i++;
                      }
                  }
                  }
              }

              if (newQuestions.length === 0 && parsed.notes.length === 0) {
                  throw new Error("No valid questions or notes detected. Use Tab-Separated columns OR Vertical Blocks.");
              }

              if (isTest) {
                  setEditingTestMcqs(prev => [...prev, ...newQuestions]);
              } else {
                  setEditingMcqs(prev => [...prev, ...newQuestions]);
              }

              if (parsed.notes.length > 0) {
                  const newTopicNotes = parsed.notes.map(n => ({
                      id: `note-${Date.now()}-${generateSecureRandomId(9)}`,
                      title: n.title,
                      topic: n.title,
                      content: `<p>${n.content.replace(/\n/g, '<br>')}</p>`,
                      isPremium: false
                  }));
                  setTopicNotes(prev => [...prev, ...newTopicNotes]);
              }
              
              setImportText('');
              alert(`Success! ${newQuestions.length} questions and ${parsed.notes.length} notes imported.`);

          } catch (error: any) {
              alert("Import Failed: " + error.message);
          } finally {
              setIsContentLoading(false); // Unlock UI
          }
      }, 100);
  };

  // --- UNIFIED IMPORT HANDLER (MCQ + NOTES) ---
  const handleUnifiedImport = (isTest: boolean) => {
      if (!importText.trim()) {
          alert("Please paste data first!");
          return;
      }

      setIsContentLoading(true);

      setTimeout(() => {
          try {
              let rawText = importText.trim();
              const newTopicNotes: typeof topicNotes = [];

              // 1. EXTRACT EXPLICIT <NOTE: > BLOCKS AND HTML NOTES
              let textForMcq = '';
              const noteRegex = /<NOTE:\s*(.*?)>([\s\S]*?)<\/NOTE>/gi;
              let intermediateText = rawText.replace(noteRegex, (match, p1, p2) => {
                  const titleClean = p1.trim().replace(/^Note:\s*/i, '');
                  newTopicNotes.push({
                      id: `note-${Date.now()}-${generateSecureRandomId(9)}`,
                      title: titleClean,
                      topic: titleClean,
                      content: p2.trim(),
                      isPremium: false
                  });
                  return "";
              });

              const lines = intermediateText.split('\n');
              let lineIdx = 0;
              let currentGlobalTopic = '';

              while (lineIdx < lines.length) {
                  const line = lines[lineIdx];

                  const topicMatch = line.match(/^(?:📖\s*)?Topic\s*[:\s-]*\s*(.*)/i) || line.match(/^<TOPIC:\s*(.*?)>/i);
                  if (topicMatch) {
                      currentGlobalTopic = topicMatch[1].trim();
                  }

                  const isHtmlStart = /^<(h[1-6]|div|p|ul|ol|li|b|strong|i|em|u|strike)/i.test(line.trim());

                  // Extract raw HTML blocks as topic notes if they appear between questions
                  if (isHtmlStart && !line.trim().includes('Options:') && !line.trim().includes('Question:')) {
                      let noteContent = '';
                      let noteTitle = line.replace(/<[^>]+>/g, '').trim() || 'Imported Note';
                      if (!noteTitle && line.trim().startsWith('<p>')) {
                           noteTitle = 'Important Note';
                      }

                      while (lineIdx < lines.length) {
                          const nextLine = lines[lineIdx];
                          const isNextQuestion = /^(\*\*)?(Question|Q)\s*\d+[.:)]?.*(\*\*)?\s*$/i.test(nextLine) || /^❓\s*Question/i.test(nextLine);
                          const isNextTopicTag = /^<TOPIC:\s*(.*?)>/i.test(nextLine);

                          if (isNextQuestion || isNextTopicTag) {
                              break;
                          }
                          noteContent += nextLine + '\n';
                          lineIdx++;
                      }

                      if (noteContent.trim()) {
                          newTopicNotes.push({
                              id: `note-${Date.now()}-${generateSecureRandomId(9)}`,
                              title: noteTitle.length > 50 ? noteTitle.substring(0,50) + '...' : noteTitle,
                              topic: currentGlobalTopic || noteTitle,
                              content: noteContent.trim(),
                              isPremium: false
                          });
                      }
                      continue;
                  }

                  textForMcq += line + '\n';
                  lineIdx++;
              }

              // Extract explicit <NOTE: Topic> blocks before parsing MCQs to prevent conflicts
              const explicitNoteRegex = /<NOTE:\s*([^>]+)>([\s\S]*?)<\/NOTE>/g;
              let noteMatch;
              let cleanMcqText = textForMcq;

              while ((noteMatch = explicitNoteRegex.exec(textForMcq)) !== null) {
                  const topicName = noteMatch[1].trim();
                  const noteContent = noteMatch[2].trim();

                  if (noteContent) {
                      newTopicNotes.push({
                          id: `note-${Date.now()}-${generateSecureRandomId(9)}`,
                          title: topicName.length > 50 ? topicName.substring(0, 50) + '...' : topicName,
                          topic: topicName,
                          content: noteContent,
                          isPremium: false
                      });
                  }
                  // Remove this block from the text so it doesn't confuse the MCQ parser
                  cleanMcqText = cleanMcqText.replace(noteMatch[0], '');
              }

              let newQuestions: MCQItem[] = [];
              const textToProcess = cleanMcqText;

              if (importFormatMode === 'AUTO' || importFormatMode === 'ADVANCED_EMOJI') {
                  // Try the new robust parser first for MCQs on the cleaned text
                  const parsed = parseMCQText(cleanMcqText);
                  newQuestions = parsed.questions;

                  if (parsed.notes.length > 0) {
                      newTopicNotes.push(...parsed.notes.map(n => ({
                          id: `note-${Date.now()}-${generateSecureRandomId(9)}`,
                          title: n.title,
                          topic: n.title,
                          content: `<p>${n.content.replace(/\n/g, '<br>')}</p>`,
                          isPremium: false
                      })));
                  }
              }

              // If it didn't find any questions using the new robust parser (or if forced standard), fallback to old TSV/Vertical logic
              if ((newQuestions.length === 0 && textToProcess.trim().length > 0 && importFormatMode === 'AUTO') || importFormatMode === 'STANDARD_TSV') {
                  // MODE A: Tab-Separated
                  if (textToProcess.includes('\t')) {
                      const rows = textToProcess.split('\n').filter(r => r.trim());
                      newQuestions = rows.map((row, idx) => {
                          let cols = row.split('\t');
                          if (cols.length < 3 && row.includes(',')) cols = row.split(',');
                          cols = cols.map(c => c.trim());
                          if (cols.length < 6) return null;

                          let ansIdx = parseInt(cols[5]) - 1;
                          if (isNaN(ansIdx)) {
                              const map: any = { 'A': 0, 'B': 1, 'C': 2, 'D': 3, 'a': 0, 'b': 1, 'c': 2, 'd': 3 };
                              if (map[cols[5]] !== undefined) ansIdx = map[cols[5]];
                          }

                          let topic = '';
                          if (cols.length > 7) topic = cols[7];

                          return {
                              question: cols[0],
                              options: [cols[1], cols[2], cols[3], cols[4]],
                              correctAnswer: (ansIdx >= 0 && ansIdx <= 3) ? ansIdx : 0,
                              explanation: cols[6] || '',
                              topic: topic
                          };
                      }).filter(q => q !== null) as MCQItem[];
                  }
                  // MODE B: Vertical Block (Improved Robustness)
                  else {
                      const lines = textForMcq.split('\n').map(l => l.trim()).filter(l => l);
                      let i = 0;
                      let currentGlobalTopic = '';

                      while (i < lines.length) {
                          const line = lines[i];

                          // 1. CHECK FOR TOPIC TAG
                          const topicTagMatch = line.match(/^<TOPIC:\s*(.*?)>/i);
                          if (topicTagMatch) {
                              currentGlobalTopic = topicTagMatch[1].trim();
                              i++;
                              continue;
                          }

                          // 2. CHECK FOR HTML BLOCKS AS NOTES
                          const isHtmlStart = /^<(h[1-6]|div)/i.test(line);
                          if (isHtmlStart) {
                              let noteContent = '';
                              let noteTitle = line.replace(/<[^>]+>/g, '').trim() || 'Imported Note';

                              while (i < lines.length) {
                                  const nextLine = lines[i];
                                  const isNextQuestion = /^(\*\*)?(Question|Q)\s*\d+[.:)]?.*(\*\*)?\s*$/i.test(nextLine) || /^❓\s*Question/i.test(nextLine);
                                  const isNextTopic = /^<TOPIC:\s*(.*?)>/i.test(nextLine);

                                  if (isNextQuestion || isNextTopic) break;
                                  noteContent += nextLine + '\n';
                                  i++;
                              }

                              if (noteContent.trim()) {
                                  newTopicNotes.push({
                                      id: `note-${Date.now()}-${generateSecureRandomId(9)}`,
                                      title: `Note: ${noteTitle}`,
                                      topic: currentGlobalTopic || noteTitle,
                                      content: noteContent.trim(),
                                      isPremium: false
                                  });
                              }
                              continue;
                          }

                          // 3. CHECK FOR QUESTION START
                          const isQuestionStart = /^(\*\*)?(Question|Q)\s*\d+[.:)]?.*(\*\*)?\s*$/i.test(line);

                          if (isQuestionStart) {
                              let currentQ = line.replace(/^\*\*|\*\*$/g, '').replace(/^(\*\*)?(Question|Q)\s*\d+[.:)]?(\*\*)?\s*/i, '').trim();

                              let opts: string[] = [];
                              let ansIdx = -1;
                              let explanation = '';
                              let concept = '';
                              let commonMistake = '';
                              let examTip = '';
                              let mnemonic = '';
                              let topic = currentGlobalTopic;

                              let nextIndex = i + 1;
                              let currentSection = 'meta'; // 'meta', 'question', 'options', 'answer', 'explanation', etc.

                              while (nextIndex < lines.length) {
                                  let nextLine = lines[nextIndex];

                                  const isNextQ = /^(\*\*)?(Question|Q)\s*\d+[.:)]?.*(\*\*)?\s*$/i.test(nextLine);
                                  const isNextTopic = /^<TOPIC:\s*(.*?)>/i.test(nextLine);
                                  const isNextHtml = /^<(h[1-6]|div)/i.test(nextLine);

                                  if (isNextQ || isNextTopic || isNextHtml) break;

                                  // Detect Sections
                                  if (/^❓\s*Question/i.test(nextLine)) {
                                      currentSection = 'question';
                                      nextIndex++;
                                      continue;
                                  } else if (/^(Options\s*:?|विकल्प\s*:?)/i.test(nextLine)) {
                                      currentSection = 'options_header';
                                      nextIndex++;
                                      continue;
                                  } else if (/^[A-D]\)|^[A-D]\.|^\([A-D]\)/i.test(nextLine) && opts.length < 4) {
                                      currentSection = 'options';
                                  } else if (/^(✅\s*)?(Correct Answer|Answer|Ans|उत्तर)\s*[:\s-]*\s*/i.test(nextLine)) {
                                      currentSection = 'answer';
                                  } else if (/^(💡\s*)?(Concept|संकल्पना)\s*[:\s-]*\s*/i.test(nextLine)) {
                                      currentSection = 'concept';
                                  } else if (/^(🔎\s*)?(Explanation|Exp|व्याख्या)\s*[:\s-]*\s*/i.test(nextLine)) {
                                      currentSection = 'explanation';
                                  } else if (/^(🎯\s*)?(Exam Tip|परीक्षा टिप)\s*[:\s-]*\s*/i.test(nextLine)) {
                                      currentSection = 'exam_tip';
                                  } else if (/^(⚠\s*)?(Common Mistake|सामान्य गलती)\s*[:\s-]*\s*/i.test(nextLine)) {
                                      currentSection = 'common_mistake';
                                  } else if (/^(🧠\s*)?(Memory Trick|मेमोरी ट्रिक)\s*[:\s-]*\s*/i.test(nextLine)) {
                                      currentSection = 'mnemonic';
                                  } else if (/^(📖\s*)?Topic\s*[:\s-]*\s*(.*)/i.test(nextLine)) {
                                      topic = nextLine.replace(/^(📖\s*)?Topic\s*[:\s-]*\s*/i, '').replace(/^\*\*|\*\*$/g, '').trim();
                                      nextIndex++;
                                      continue;
                                  } else if (/^(🔥\s*)?PYQ Inspired/i.test(nextLine) || /^(📊\s*)?Difficulty Level/i.test(nextLine)) {
                                      currentSection = 'meta';
                                      nextIndex++;
                                      continue;
                                  }

                                  // Process Sections
                                  if (currentSection === 'question') {
                                      if (nextLine) currentQ += (currentQ ? '\n' : '') + nextLine;
                                  } else if (currentSection === 'options') {
                                      opts.push(nextLine.replace(/^[A-D]\s*[.)]\s*|^\([A-D]\)\s*/i, '').trim());
                                  } else if (currentSection === 'answer') {
                                      let ansRaw = nextLine.replace(/^(✅\s*)?(Correct Answer|Answer|Ans|उत्तर)\s*[:\s-]*\s*/i, '').trim();

                                      // Flexible Answer Parsing
                                      if (/^\d+$/.test(ansRaw)) {
                                          ansIdx = parseInt(ansRaw) - 1;
                                      } else {
                                          // Extract first letter (A, B, C, D)
                                          const firstCharMatch = ansRaw.match(/^[A-D]/i);
                                          if (firstCharMatch) {
                                              const map: any = { 'A': 0, 'B': 1, 'C': 2, 'D': 3 };
                                              ansIdx = map[firstCharMatch[0].toUpperCase()];
                                          } else {
                                               // Check if the answer matches option text
                                               const optionIndex = opts.findIndex(o => ansRaw.includes(o));
                                               if (optionIndex !== -1) ansIdx = optionIndex;
                                          }
                                      }
                                      currentSection = 'post_answer';
                                  } else if (currentSection === 'concept') {
                                      concept += (concept ? '\n' : '') + nextLine.replace(/^(💡\s*)?(Concept|संकल्पना)\s*[:\s-]*\s*/i, '').trim();
                                  } else if (currentSection === 'explanation') {
                                      explanation += (explanation ? '\n' : '') + nextLine.replace(/^(🔎\s*)?(Explanation|Exp|व्याख्या)\s*[:\s-]*\s*/i, '').trim();
                                  } else if (currentSection === 'exam_tip') {
                                      examTip += (examTip ? '\n' : '') + nextLine.replace(/^(🎯\s*)?(Exam Tip|परीक्षा टिप)\s*[:\s-]*\s*/i, '').trim();
                                  } else if (currentSection === 'common_mistake') {
                                      commonMistake += (commonMistake ? '\n' : '') + nextLine.replace(/^(⚠\s*)?(Common Mistake|सामान्य गलती)\s*[:\s-]*\s*/i, '').trim();
                                  } else if (currentSection === 'mnemonic') {
                                      mnemonic += (mnemonic ? '\n' : '') + nextLine.replace(/^(🧠\s*)?(Memory Trick|मेमोरी ट्रिक)\s*[:\s-]*\s*/i, '').trim();
                                  }

                                  nextIndex++;
                              }

                              if (ansIdx < 0 || ansIdx > 3) ansIdx = 0;
                              if (opts.length < 4) {
                                  // Pad options if not enough were found
                                  while(opts.length < 4) opts.push("Option");
                              }

                              // Remove any trailing labels
                              currentQ = currentQ.replace(/^❓\s*Question\s*:?/i, '').trim();

                              newQuestions.push({
                                  question: currentQ.trim(),
                                  options: [opts[0], opts[1], opts[2], opts[3]],
                                  correctAnswer: ansIdx,
                                  explanation: explanation.trim(),
                                  concept: concept.trim(),
                                  commonMistake: commonMistake.trim(),
                                  examTip: examTip.trim(),
                                  mnemonic: mnemonic.trim(),
                                  topic: topic
                              });

                              i = nextIndex;
                          } else {
                              i++;
                          }
                      }
                  }
              }

              // Update Topic Notes State
              if (newTopicNotes.length > 0) {
                  setTopicNotes(prev => [...prev, ...newTopicNotes]);
              }

              if (newQuestions.length > 0) {
                  if (isTest) {
                      setEditingTestMcqs(prev => [...prev, ...newQuestions]);
                  } else {
                      setEditingMcqs(prev => [...prev, ...newQuestions]);
                  }
              }

              if (newQuestions.length === 0 && newTopicNotes.length === 0) {
                  throw new Error("No valid content found.");
              }

              setImportText('');
              alert(`Success! Imported ${newQuestions.length} MCQs and ${newTopicNotes.length} Notes.`);

          } catch (error: any) {
              alert("Import Failed: " + error.message);
          } finally {
              setIsContentLoading(false);
          }
      }, 100);
  };

  // --- ACCESS REQUEST HANDLERS ---
  const handleApproveRequest = async (req: RecoveryRequest) => {
      // 1. Update Request Status in RTDB
      const reqRef = ref(rtdb, `recovery_requests/${req.id}`);
      await update(reqRef, { status: 'RESOLVED' });

      // 2. Enable Passwordless Login for User
      const userToUpdate = users.find(u => u.id === req.id);
      if (userToUpdate) {
          const updatedUser = { ...userToUpdate, isPasswordless: true };
          // Save to Local & Cloud
          if (isFirebaseConnected) {
              await saveUserToLive(updatedUser);
          }
      }
      
      alert(`Access Approved for ${req.name}. They can now login without password.`);
  };

  // --- SUB ADMIN HANDLERS ---
  const promoteToSubAdmin = async (userId: string) => {
      const user = users.find(u => u.id === userId || u.email === userId);
      if (!user) {
          alert("User not found!");
          return;
      }
      
      const updatedUser: User = { 
          ...user, 
          role: 'SUB_ADMIN', 
          isSubAdmin: true,
          // Default Permissions: ONLY Subscription Management allowed initially
          permissions: ['MANAGE_SUBS'] 
      };
      
      // Update State
      const updatedList = users.map(u => u.id === user.id ? updatedUser : u);
      setUsers(updatedList);
      localStorage.setItem('nst_users', JSON.stringify(updatedList));
      
      // Update Cloud
      if (isFirebaseConnected) await saveUserToLive(updatedUser);
      
      alert(`✅ ${user.name} promoted to Sub-Admin!`);
      setNewSubAdminId('');
  };

  const demoteSubAdmin = async (userId: string) => {
      const user = users.find(u => u.id === userId);
      if (!user) return;
      
      if (!confirm(`Are you sure you want to remove Sub-Admin rights from ${user.name}?`)) return;

      const updatedUser: User = { 
          ...user, 
          role: 'STUDENT', 
          isSubAdmin: false,
          permissions: [] 
      };
      
      const updatedList = users.map(u => u.id === user.id ? updatedUser : u);
      setUsers(updatedList);
      localStorage.setItem('nst_users', JSON.stringify(updatedList));
      
      if (isFirebaseConnected) await saveUserToLive(updatedUser);
      
      alert(`ℹ️ ${user.name} is now a Student.`);
  };

  const toggleSubAdminPermission = async (userId: string, perm: string) => {
      const user = users.find(u => u.id === userId);
      if (!user) return;
      
      const currentPerms = user.permissions || [];
      const newPerms = currentPerms.includes(perm) 
          ? currentPerms.filter(p => p !== perm) 
          : [...currentPerms, perm];
          
      const updatedUser = { ...user, permissions: newPerms };
      
      const updatedList = users.map(u => u.id === user.id ? updatedUser : u);
      setUsers(updatedList);
      
      if (isFirebaseConnected) await saveUserToLive(updatedUser);
  };

  // --- SUB-COMPONENTS (RENDER HELPERS) ---
  const DashboardCard = ({ icon: Icon, label, onClick, color, count }: any) => (
      <button onClick={onClick} className={`p-4 rounded-2xl border-2 flex flex-col items-center justify-center gap-2 transition-all hover:scale-105 active:scale-95 bg-white border-slate-200 hover:border-${color}-400 hover:bg-${color}-50`}>
          <div className={`p-3 rounded-full bg-${color}-100 text-${color}-600`}>
              <Icon size={24} />
          </div>
          <span className="font-bold text-xs uppercase text-slate-600">{label}</span>
          {count !== undefined && <span className={`text-[10px] font-black px-2 py-0.5 rounded bg-slate-100 text-slate-600`}>{count}</span>}
      </button>
  );

  const SubjectSelector = () => {
      // 1. BOARD INDICATOR (Controlled via Header)
      const renderBoards = () => (
          <div className="flex items-center justify-between mb-4">
             <div className={`px-4 py-2 rounded-xl text-xs font-black tracking-widest border-2 flex items-center gap-2 ${selBoard === 'CBSE' ? 'bg-blue-50 text-blue-600 border-blue-200' : 'bg-orange-50 text-orange-600 border-orange-200'}`}>
                {selBoard === 'CBSE' ? <Book size={14}/> : <Globe size={14}/>}
                CURRENT BOARD: {selBoard}
             </div>
             
             {/* VISIBILITY TOGGLE BUTTON */}
             <button 
                onClick={() => setShowVisibilityControls(!showVisibilityControls)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${showVisibilityControls ? 'bg-slate-800 text-white shadow-lg' : 'bg-white border border-slate-200 text-slate-600'}`}
             >
                {showVisibilityControls ? <EyeOff size={14} /> : <Eye size={14} />}
                {showVisibilityControls ? 'Hide Controls' : 'Visibility Mode'}
             </button>
          </div>
      );

      // 2. CLASS BUTTONS (Explicit List)
      const renderClasses = () => (
          <div className="mb-4">
              <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">Select Class</p>
              <div className="flex flex-wrap gap-2">
                  {['6','7','8','9','10','11','12', 'COMPETITION', ...(localSettings.customClasses || [])].map(c => {
                      const isHidden = (localSettings.hiddenClasses || []).includes(c);
                      return (
                      <div key={c} className="relative">
                          <button 
                              onClick={() => setSelClass(c as ClassLevel)}
                              className={`w-10 h-10 rounded-lg flex items-center justify-center text-xs font-bold transition-all ${selClass === c ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 scale-110' : 'bg-white border border-slate-200 text-slate-600 hover:border-blue-300'} ${isHidden ? 'opacity-50 grayscale' : ''}`}
                              title={c === 'COMPETITION' ? 'Competitive Exam' : `Class ${c}`}
                          >
                              {c === 'COMPETITION' ? '🏆' : c}
                          </button>
                          {showVisibilityControls && (
                              <button 
                                  onClick={(e) => {
                                      e.stopPropagation();
                                      const updated = toggleItemInList(localSettings.hiddenClasses, c);
                                      setLocalSettings({...localSettings, hiddenClasses: updated});
                                  }}
                                  className={`absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center shadow-sm border ${isHidden ? 'bg-red-500 text-white border-red-600' : 'bg-white text-slate-500 border-slate-200'}`}
                              >
                                  {isHidden ? <EyeOff size={10} /> : <Eye size={10} />}
                              </button>
                          )}
                      </div>
                  )})}
                  {/* ADD CUSTOM CLASS BUTTON */}
                  {currentUser?.role === 'ADMIN' && activeTab === 'CONFIG_GENERAL' && (
                      <button 
                          onClick={() => {
                              const newClass = prompt("Enter new Class Name (e.g., 13 or Dropper):");
                              if (newClass) {
                                  const updatedClasses = [...(localSettings.customClasses || []), newClass];
                                  setLocalSettings({...localSettings, customClasses: updatedClasses});
                                  handleSaveSettings();
                              }
                          }}
                          className="w-10 h-10 rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-500 hover:text-blue-600 hover:border-blue-300"
                          title="Add Custom Class"
                      >
                          <Plus size={16} />
                      </button>
                  )}
              </div>
          </div>
      );

      // 3. STREAM BUTTONS (Conditional)
      const renderStreams = () => {
          if (!['11', '12'].includes(selClass)) return null;
          return (
              <div className="mb-4 animate-in fade-in slide-in-from-left-4">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">Select Stream</p>
                  <div className="flex gap-2">
                      {['Science', 'Commerce', 'Arts'].map(s => (
                          <button 
                              key={s}
                              onClick={() => setSelStream(s as Stream)}
                              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${selStream === s ? 'bg-purple-600 text-white shadow-lg' : 'bg-white border border-slate-200 text-slate-600 hover:bg-purple-50'}`}
                          >
                              {s}
                          </button>
                      ))}
                  </div>
              </div>
          );
      };

      // 4. SUBJECT BUTTONS
      const renderSubjects = () => (
          <div className="mb-4">
              <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">Select Subject</p>
              <div className="flex flex-wrap gap-2">
                  {getSubjectsList(selClass, selStream, selBoard).map(s => {
                      const isHidden = (localSettings.hiddenSubjects || []).includes(s.id);
                      return (
                      <div key={s.id} className="relative">
                          <button 
                              onClick={() => handleSubjectClick(s)}
                              className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all flex items-center gap-2 ${selSubject?.id === s.id ? 'bg-green-600 text-white border-green-600 shadow-md scale-105' : 'bg-white border-slate-200 text-slate-700 hover:bg-green-50'} ${isHidden ? 'opacity-50 grayscale' : ''}`}
                          >
                              {selSubject?.id === s.id && <CheckCircle size={12} />}
                              {s.name}
                          </button>
                          {showVisibilityControls && (
                              <button 
                                  onClick={(e) => {
                                      e.stopPropagation();
                                      const updated = toggleItemInList(localSettings.hiddenSubjects, s.id);
                                      setLocalSettings({...localSettings, hiddenSubjects: updated});
                                  }}
                                  className={`absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center shadow-sm border ${isHidden ? 'bg-red-500 text-white border-red-600' : 'bg-white text-slate-500 border-slate-200'}`}
                              >
                                  {isHidden ? <EyeOff size={10} /> : <Eye size={10} />}
                              </button>
                          )}
                      </div>
                  )})}
              </div>
          </div>
      );

      return (
          <div className="mb-8 bg-slate-50 p-4 rounded-3xl border border-slate-200 shadow-inner">
              {renderBoards()}
              {renderClasses()}
              {renderStreams()}
              {renderSubjects()}
              
              {isLoadingChapters && <div className="text-slate-600 text-sm font-bold py-4 animate-pulse text-center">Loading Chapters...</div>}
          </div>
      );
  };

  // --- MAIN RENDER ---

  // PILOT VIEW

  return (
    <div className="pb-20 bg-slate-50 min-h-screen">
      
      {/* 1. DASHBOARD HOME */}
      {activeTab === 'DASHBOARD' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 mb-6 animate-in fade-in">
              <div className="flex flex-col items-center justify-center mb-6 w-full space-y-4">
                  <div className="flex items-center gap-2">
                      <div className="bg-blue-600 p-2 rounded-lg text-white shadow-lg"><Shield size={20} /></div>
                      <h2 className="font-black text-slate-800 text-lg leading-none">Admin Console</h2>
                  </div>

                  <div className="flex items-center gap-2">
                      {/* STRICT BOARD SWITCHER */}
                      <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200">
                          <button onClick={() => handleBoardChange('CBSE')} className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${adminBoardContext === 'CBSE' ? 'bg-white shadow text-blue-600' : 'text-slate-500 hover:text-slate-600'}`}>CBSE</button>
                          <button onClick={() => handleBoardChange('BSEB')} className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${adminBoardContext === 'BSEB' ? 'bg-white shadow text-orange-600' : 'text-slate-500 hover:text-slate-600'}`}>BSEB</button>
                      </div>

                      {/* ONLINE USERS */}
                      <div className="flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200" title="Active Users (5m)">
                          <div className="relative">
                              <Users size={10} className="text-slate-600" />
                              <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-green-500 rounded-full border border-white animate-pulse"></div>
                          </div>
                          <span className="text-[9px] font-bold text-slate-600">{onlineCount}</span>
                      </div>

                      {/* FIREBASE STATUS INDICATOR */}
                      {isFirebaseConnected ? (
                          <span className="flex items-center gap-1 bg-green-100 text-green-700 text-[9px] px-2 py-0.5 rounded-full font-bold">
                              <Wifi size={10} /> Online
                          </span>
                      ) : (
                          <span className="flex items-center gap-1 bg-red-100 text-red-700 text-[9px] px-2 py-0.5 rounded-full font-bold animate-pulse">
                              <WifiOff size={10} /> Disconnected
                          </span>
                      )}
                  </div>

                  <div className="flex w-full md:w-auto gap-2 items-center flex-wrap">
                      <button
                          onClick={() => {
                              if (!isDarkMode) {
                                  // Switch to dark mode (default black)
                                  localStorage.setItem('nst_dark_theme_type', 'black');
                                  onToggleDarkMode && onToggleDarkMode(true);
                              } else {
                                  // Toggle theme type
                                  const currentType = localStorage.getItem('nst_dark_theme_type');
                                  if (currentType === 'black') {
                                      localStorage.setItem('nst_dark_theme_type', 'blue');
                                      onToggleDarkMode && onToggleDarkMode(true); // Re-trigger effect
                                  } else {
                                      // Switch back to light mode
                                      onToggleDarkMode && onToggleDarkMode(false);
                                  }
                              }
                          }}
                          className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-[10px] uppercase tracking-widest font-black transition-all shadow-sm ${isDarkMode ? (localStorage.getItem('nst_dark_theme_type') === 'blue' ? 'bg-blue-900 text-blue-300 border border-blue-800' : 'bg-slate-800 text-yellow-400 border border-slate-700') : 'bg-white text-slate-600 border border-slate-200'}`}
                      >
                          {isDarkMode ? <Sparkles size={14} /> : <Zap size={14} />}
                          {isDarkMode ? (localStorage.getItem('nst_dark_theme_type') === 'blue' ? 'Blue' : 'Black') : 'Light'}
                      </button>

                      <button 
                          onClick={() => {
                              if (confirm("⚠️ FORCE UPDATE ALL APPS?\n\nThis will trigger a reload on all student devices to apply latest changes immediately.")) {
                                  const ts = Date.now().toString();
                                  setLocalSettings({...localSettings, forceRefreshTimestamp: ts});
                                  if (onUpdateSettings) {
                                      const updated = {...localSettings, forceRefreshTimestamp: ts};
                                      onUpdateSettings(updated);
                                      saveSystemSettings(updated);
                                  }
                                  alert("✅ Update Command Sent!");
                              }
                          }}
                          className="flex-1 md:flex-none bg-red-100 text-red-600 border border-red-200 px-4 py-2.5 rounded-xl text-[10px] uppercase tracking-widest font-black hover:bg-red-200 flex items-center justify-center gap-2 transition-colors"
                      >
                          <RefreshCw size={14} /> Force Update
                      </button>

                      <button
                          onClick={() => handleSaveSettings()}
                          disabled={isSettingsSaving}
                          className={`flex-1 md:flex-none bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-[10px] uppercase tracking-widest font-black shadow-lg hover:bg-indigo-700 flex items-center justify-center gap-2 transition-colors ${isSettingsSaving ? 'opacity-70 cursor-wait' : ''}`}
                      >
                          {isSettingsSaving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                          {isSettingsSaving ? 'Saving...' : 'Save Settings'}
                      </button>
                  </div>
              </div>

              <FeatureGroupList
                  activeTab={activeTab}
                  onNavigate={(tab) => {
                      if (tab === 'EXIT') onNavigate('STUDENT_DASHBOARD');
                      else setActiveTab(tab as AdminTab);
                  }}
                  counts={{
                      'ADMIN_USERS': users.length,
                      'ADMIN_SUB_ADMINS': users.filter(u => u.role === 'SUB_ADMIN').length,
                      'ADMIN_DEMANDS': demands.length,
                      'ADMIN_ACCESS': recoveryRequests.filter(r => r.status === 'PENDING').length,
                      'ADMIN_RECYCLE': recycleBin.length
                  }}
                  hasPermission={hasPermission}
                  userRole={currentUser?.role || 'STUDENT'}
                  settings={localSettings}
              />
              <div className="mt-4 flex justify-end">
                  <button onClick={() => onNavigate('STUDENT_DASHBOARD')} className="bg-slate-800 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-slate-900 transition-all shadow-md text-xs">
                      <LogOut size={16} /> Exit
                  </button>
              </div>
          </div>
      )}

            {/* --- STORE MANAGER TAB --- */}
      {activeTab === 'STORE_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Store Manager</h3>
              </div>

              {/* STORE EVENTS & POPUPS */}
              <div className="mb-8 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Zap size={18} className="text-yellow-500" /> Advanced Store Events & Logic</h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                      {/* Revision Logic Toggle */}
                      <div className="flex flex-col gap-2 bg-white p-3 rounded-lg border border-slate-200">
                          <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-700">Revision Engine</span>
                              <input
                                  type="checkbox"
                                  checked={localSettings.revisionConfig?.trackWrongAnswers ?? true}
                                  onChange={e => setLocalSettings({...localSettings, revisionConfig: {...localSettings.revisionConfig, trackWrongAnswers: e.target.checked}})}
                                  className="w-5 h-5 accent-blue-600"
                              />
                          </div>
                          <p className="text-[10px] text-slate-600 leading-tight">
                              Enable/Disable Revision Hub tracking globally.
                          </p>
                      </div>

                      {/* Credit Free Event Toggle */}
                      <div className="flex flex-col gap-2 bg-white p-3 rounded-lg border border-slate-200">
                          <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-700">Credit Free Event</span>
                              <input
                                  type="checkbox"
                                  checked={localSettings.isCreditFreeEvent || false}
                                  onChange={e => setLocalSettings({...localSettings, isCreditFreeEvent: e.target.checked})}
                                  className="w-5 h-5 accent-blue-600"
                              />
                          </div>
                          {localSettings.isCreditFreeEvent && (
                              <p className="text-[10px] text-slate-600 leading-tight">
                                  All content normally requiring credits will be completely free.
                              </p>
                          )}
                      </div>

                      {/* Global Free Access Toggle */}
                      <div className="flex flex-col gap-2 bg-white p-3 rounded-lg border border-slate-200">
                          <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-700">Global Free Access</span>
                              <input
                                  type="checkbox"
                                  checked={localSettings.isGlobalFreeMode || false}
                                  onChange={e => setLocalSettings({...localSettings, isGlobalFreeMode: e.target.checked})}
                                  className="w-5 h-5 accent-blue-600"
                              />
                          </div>
                          {localSettings.isGlobalFreeMode && (
                              <p className="text-[10px] text-slate-600 leading-tight">
                                  Overrides all subscriptions. Every user gets Ultra Access.
                              </p>
                          )}
                      </div>

                      {/* Discount Event Toggle */}
                      <div className="flex flex-col gap-2 bg-white p-3 rounded-lg border border-slate-200">
                          <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-700">Discount Sale Event</span>
                              <input
                                  type="checkbox"
                                  checked={localSettings.specialDiscountEvent?.enabled || false}
                                  onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), enabled: e.target.checked}})}
                                  className="w-5 h-5 accent-blue-600"
                              />
                          </div>
                      </div>
                  </div>

                  {/* EVENT DETAILED SETTINGS */}
                  {localSettings.specialDiscountEvent?.enabled && (
                      <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-inner mb-4 animate-in fade-in slide-in-from-top-2">
                          <h5 className="font-bold text-blue-800 mb-3 flex items-center gap-2"><Ticket size={16}/> Discount Event Configuration</h5>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 block">Event Name</label>
                                  <input
                                      type="text"
                                      value={localSettings.specialDiscountEvent?.eventName || ''}
                                      onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), eventName: e.target.value}})}
                                      className="w-full p-2 border rounded text-sm"
                                      placeholder="e.g. Diwali Mega Sale"
                                  />
                              </div>
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 block">Discount %</label>
                                  <input
                                      type="number"
                                      value={localSettings.specialDiscountEvent?.discountPercent || 0}
                                      onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), discountPercent: Number(e.target.value)}})}
                                      className="w-full p-2 border rounded text-sm"
                                  />
                              </div>
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 block">Renewal Bonus % (Extra)</label>
                                  <input
                                      type="number"
                                      value={localSettings.specialDiscountEvent?.renewalDiscountPercent || 0}
                                      onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), renewalDiscountPercent: Number(e.target.value)}})}
                                      className="w-full p-2 border rounded text-sm"
                                  />
                              </div>
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 block">Start Date/Time</label>
                                  <input
                                      type="datetime-local"
                                      value={localSettings.specialDiscountEvent?.startsAt ? new Date(localSettings.specialDiscountEvent.startsAt).toISOString().slice(0, 16) : ''}
                                      onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), startsAt: e.target.value ? new Date(e.target.value).toISOString() : undefined}})}
                                      className="w-full p-2 border rounded text-sm"
                                  />
                              </div>
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 block">End Date/Time</label>
                                  <input
                                      type="datetime-local"
                                      value={localSettings.specialDiscountEvent?.endsAt ? new Date(localSettings.specialDiscountEvent.endsAt).toISOString().slice(0, 16) : ''}
                                      onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), endsAt: e.target.value ? new Date(e.target.value).toISOString() : undefined}})}
                                      className="w-full p-2 border rounded text-sm"
                                  />
                              </div>
                          </div>

                          <div className="flex items-center gap-4 mt-4">
                               <label className="flex items-center gap-2 text-xs font-bold text-slate-700">
                                  <input type="checkbox" checked={localSettings.specialDiscountEvent?.showToFreeUsers ?? true} onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), showToFreeUsers: e.target.checked}})} className="accent-blue-600" /> Show to Free Users
                               </label>
                               <label className="flex items-center gap-2 text-xs font-bold text-slate-700">
                                  <input type="checkbox" checked={localSettings.specialDiscountEvent?.showToPremiumUsers ?? true} onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: {...(localSettings.specialDiscountEvent || {} as any), showToPremiumUsers: e.target.checked}})} className="accent-blue-600" /> Show to Premium Users
                               </label>
                          </div>
                      </div>
                  )}

                  {/* POPUP CONFIGURATIONS */}
                  <h5 className="font-bold text-slate-800 mt-6 mb-3 border-t pt-4">Automatic Popup Triggers</h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Expiry Warning Popup */}
                      <div className="bg-white p-4 rounded-xl border border-slate-200">
                          <div className="flex items-center justify-between mb-3">
                              <span className="text-xs font-bold text-red-600 flex items-center gap-1"><AlertOctagon size={14}/> Expiry Warning</span>
                              <input
                                  type="checkbox"
                                  checked={localSettings.popupConfigs?.isExpiryWarningEnabled ?? true}
                                  onChange={e => setLocalSettings({...localSettings, popupConfigs: {...(localSettings.popupConfigs || {} as any), isExpiryWarningEnabled: e.target.checked}})}
                                  className="w-4 h-4 accent-red-600"
                              />
                          </div>
                          {localSettings.popupConfigs?.isExpiryWarningEnabled !== false && (
                              <div className="grid grid-cols-2 gap-2">
                                  <div>
                                      <label className="text-[10px] text-slate-600">Trigger (Hours before)</label>
                                      <input
                                          type="number"
                                          value={localSettings.popupConfigs?.expiryWarningHours ?? 24}
                                          onChange={e => setLocalSettings({...localSettings, popupConfigs: {...(localSettings.popupConfigs || {} as any), expiryWarningHours: Number(e.target.value)}})}
                                          className="w-full p-1.5 border rounded text-xs"
                                      />
                                  </div>
                                  <div>
                                      <label className="text-[10px] text-slate-600">Interval (Minutes)</label>
                                      <input
                                          type="number"
                                          value={localSettings.popupConfigs?.expiryWarningIntervalMinutes ?? 60}
                                          onChange={e => setLocalSettings({...localSettings, popupConfigs: {...(localSettings.popupConfigs || {} as any), expiryWarningIntervalMinutes: Number(e.target.value)}})}
                                          className="w-full p-1.5 border rounded text-xs"
                                      />
                                  </div>
                              </div>
                          )}
                      </div>

                      {/* Upsell Popup */}
                      <div className="bg-white p-4 rounded-xl border border-slate-200">
                          <div className="flex items-center justify-between mb-3">
                              <span className="text-xs font-bold text-green-600 flex items-center gap-1"><ArrowUpCircle size={14}/> Upsell Promotion</span>
                              <input
                                  type="checkbox"
                                  checked={localSettings.popupConfigs?.isUpsellEnabled ?? true}
                                  onChange={e => setLocalSettings({...localSettings, popupConfigs: {...(localSettings.popupConfigs || {} as any), isUpsellEnabled: e.target.checked}})}
                                  className="w-4 h-4 accent-green-600"
                              />
                          </div>
                          {localSettings.popupConfigs?.isUpsellEnabled !== false && (
                              <div>
                                  <label className="text-[10px] text-slate-600">Show Interval (Minutes)</label>
                                  <input
                                      type="number"
                                      value={localSettings.popupConfigs?.upsellPopupIntervalMinutes ?? 120}
                                      onChange={e => setLocalSettings({...localSettings, popupConfigs: {...(localSettings.popupConfigs || {} as any), upsellPopupIntervalMinutes: Number(e.target.value)}})}
                                      className="w-full p-1.5 border rounded text-xs"
                                  />
                              </div>
                          )}
                      </div>
                  </div>
              </div>

              {/* NEW SUBSCRIPTION PLAN EDITOR (Full Control) */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mt-4 overflow-hidden">
                  <div className="flex items-center justify-between mb-4">
                      <h4 className="font-bold text-slate-800 flex items-center gap-2"><Crown size={18} className="text-yellow-500" /> Subscription Plans (Store View)</h4>
                      <button
                          onClick={() => {
                              const newPlan = {
                                  id: `plan-${Date.now()}`,
                                  name: 'New Plan',
                                  duration: '30 days',
                                  basicPrice: 99,
                                  basicOriginalPrice: 199,
                                  ultraPrice: 149,
                                  ultraOriginalPrice: 299,
                                  features: ['New Feature'],
                                  popular: false
                              };
                              setLocalSettings({...localSettings, subscriptionPlans: [...(localSettings.subscriptionPlans || []), newPlan]});
                          }}
                          className="bg-slate-800 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-slate-700 transition-colors flex items-center gap-1"
                      >
                          <Plus size={14} /> Add Plan
                      </button>
                  </div>
                  <div className="space-y-4">
                      {(localSettings.subscriptionPlans || []).map((plan, idx) => {
                          const updatePlan = (field: string, value: any) => {
                              const newPlans = [...localSettings.subscriptionPlans!];
                              newPlans[idx] = { ...newPlans[idx], [field]: value };
                              setLocalSettings({...localSettings, subscriptionPlans: newPlans});
                          };

                          return (
                              <div key={plan.id} className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm relative group transition-all hover:border-blue-200">
                                  <button
                                      onClick={() => {
                                          if(confirm("Delete this plan?")) {
                                              const newPlans = localSettings.subscriptionPlans!.filter(p => p.id !== plan.id);
                                              setLocalSettings({...localSettings, subscriptionPlans: newPlans});
                                          }
                                      }}
                                      className="absolute top-4 right-4 text-red-400 hover:text-red-600 bg-red-50 p-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                      <Trash2 size={16} />
                                  </button>

                                  <div className="grid grid-cols-2 gap-4 mb-4 pr-10">
                                      <div>
                                          <label className="text-[10px] font-bold text-slate-600 uppercase">Plan Name</label>
                                          <input type="text" value={plan.name} onChange={e => updatePlan('name', e.target.value)} className="w-full p-2 border rounded font-bold" placeholder="e.g. Monthly" />
                                      </div>
                                      <div>
                                          <label className="text-[10px] font-bold text-slate-600 uppercase">Duration Label</label>
                                          <input type="text" value={plan.duration} onChange={e => updatePlan('duration', e.target.value)} className="w-full p-2 border rounded font-medium text-slate-600" placeholder="e.g. 30 days" />
                                      </div>
                                  </div>

                                  <div className="grid grid-cols-2 gap-4">
                                      {/* BASIC TIER CONFIG */}
                                      <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                                          <h5 className="text-xs font-black text-blue-800 mb-2 flex items-center justify-between">BASIC (PRO) TIER</h5>
                                          <div className="flex gap-2">
                                              <div className="flex-1">
                                                  <label className="text-[9px] font-bold text-slate-600 block">Dummy Price (₹)</label>
                                                  <input type="number" value={plan.basicOriginalPrice} onChange={e => updatePlan('basicOriginalPrice', Number(e.target.value))} className="w-full p-1.5 border rounded text-xs line-through text-slate-500" />
                                              </div>
                                              <div className="flex-1">
                                                  <label className="text-[9px] font-bold text-blue-600 block">Selling Price (₹)</label>
                                                  <input type="number" value={plan.basicPrice} onChange={e => updatePlan('basicPrice', Number(e.target.value))} className="w-full p-1.5 border border-blue-300 rounded text-xs font-bold text-blue-700 bg-blue-50" />
                                              </div>
                                          </div>
                                      </div>

                                      {/* ULTRA TIER CONFIG */}
                                      <div className="bg-purple-50/50 p-3 rounded-xl border border-purple-100">
                                          <h5 className="text-xs font-black text-purple-800 mb-2 flex items-center justify-between">ULTRA (MAX) TIER</h5>
                                          <div className="flex gap-2">
                                              <div className="flex-1">
                                                  <label className="text-[9px] font-bold text-slate-600 block">Dummy Price (₹)</label>
                                                  <input type="number" value={plan.ultraOriginalPrice} onChange={e => updatePlan('ultraOriginalPrice', Number(e.target.value))} className="w-full p-1.5 border rounded text-xs line-through text-slate-500" />
                                              </div>
                                              <div className="flex-1">
                                                  <label className="text-[9px] font-bold text-purple-600 block">Selling Price (₹)</label>
                                                  <input type="number" value={plan.ultraPrice} onChange={e => updatePlan('ultraPrice', Number(e.target.value))} className="w-full p-1.5 border border-purple-300 rounded text-xs font-bold text-purple-700 bg-purple-50" />
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          );
                      })}
                  </div>
              </div>

              {/* STORE FEATURE LIST (Moved from General Settings) */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mt-4">
                  <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><List size={18} /> Store Display Features</h4>
                  <div className="grid grid-cols-2 gap-4">
                      <div>
                          <label className="text-xs font-bold text-blue-600 uppercase mb-2 block">Basic Plan Features</label>
                          <textarea
                              value={(localSettings.storeFeatures?.basic || DEFAULT_BASIC_FEATURES).join('\n')}
                              onChange={e => setLocalSettings({...localSettings, storeFeatures: {...(localSettings.storeFeatures || {basic:[], ultra:[]}), basic: e.target.value.split('\n')}})}
                              className="w-full h-32 p-2 border border-blue-200 rounded-lg text-xs"
                              placeholder="One per line"
                          />
                      </div>
                      <div>
                          <label className="text-xs font-bold text-purple-600 uppercase mb-2 block">Ultra Plan Features</label>
                          <textarea
                              value={(localSettings.storeFeatures?.ultra || DEFAULT_ULTRA_FEATURES).join('\n')}
                              onChange={e => setLocalSettings({...localSettings, storeFeatures: {...(localSettings.storeFeatures || {basic:[], ultra:[]}), ultra: e.target.value.split('\n')}})}
                              className="w-full h-32 p-2 border border-purple-200 rounded-lg text-xs"
                              placeholder="One per line"
                          />
                      </div>
                  </div>
              </div>

              <div className="mt-8 flex justify-end">
                  <button onClick={() => handleSaveSettings()} className="bg-green-600 text-white font-bold py-3 px-6 rounded-xl shadow-lg hover:bg-green-700 flex items-center gap-2">
                      <Save size={18} /> Save Store Config
                  </button>
              </div>
          </div>
      )}

      {/* --- MAINTENANCE CODE GENERATOR (SECURITY TAB) --- */}
      {activeTab === 'EVENT_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Event Manager</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* DISCOUNT EVENT */}
                  <div className={`p-6 rounded-2xl border-2 transition-all ${localSettings.specialDiscountEvent?.enabled ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200'}`}>
                      <div className="flex justify-between items-center mb-4">
                          <h4 className="font-black text-lg text-slate-800 flex items-center gap-2">
                              <Ticket size={20} className="text-pink-600"/> Discount Sale
                          </h4>
                                                      {localSettings.specialDiscountEvent?.enabled && (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 bg-orange-50/50 p-4 rounded-xl border border-orange-100">
                                    <div>
                                        <label className="text-[10px] font-bold text-slate-600 uppercase">Starts At (Optional)</label>
                                        <input type="datetime-local" value={localSettings.specialDiscountEvent?.startsAt ? new Date(new Date(localSettings.specialDiscountEvent.startsAt).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 16) : ''} onChange={e => {
                                            setLocalSettings(prev => ({
                                                ...prev,
                                                specialDiscountEvent: { ...prev.specialDiscountEvent!, startsAt: e.target.value ? new Date(e.target.value).toISOString() : undefined }
                                            }));
                                        }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white" />
                                    </div>
                                    <div>
                                        <label className="text-[10px] font-bold text-slate-600 uppercase">Ends At (Optional)</label>
                                        <input type="datetime-local" value={localSettings.specialDiscountEvent?.endsAt ? new Date(new Date(localSettings.specialDiscountEvent.endsAt).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 16) : ''} onChange={e => {
                                            setLocalSettings(prev => ({
                                                ...prev,
                                                specialDiscountEvent: { ...prev.specialDiscountEvent!, endsAt: e.target.value ? new Date(e.target.value).toISOString() : undefined }
                                            }));
                                        }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white" />
                                    </div>
                                    <div>
                                        <label className="text-[10px] font-bold text-slate-600 uppercase">Discount Percent (%)</label>
                                        <input type="number" value={localSettings.specialDiscountEvent?.discountPercent || 0} onChange={e => {
                                            setLocalSettings(prev => ({
                                                ...prev,
                                                specialDiscountEvent: { ...prev.specialDiscountEvent!, discountPercent: Number(e.target.value) }
                                            }));
                                        }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white" />
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="bg-white p-4 sm:p-6 rounded-2xl shadow-sm border border-slate-200 mt-4">
                            <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2"><Zap size={18} className="text-blue-500" /> Daily Login Bonus Settings</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                                <div>
                                    <label className="text-[10px] font-bold text-slate-600 uppercase">Free User Bonus</label>
                                    <input type="number" value={localSettings.loginBonusConfig?.freeBonus ?? 2} onChange={e => {
                                        setLocalSettings(prev => ({
                                            ...prev,
                                            loginBonusConfig: { ...(prev.loginBonusConfig || { freeBonus: 2, basicBonus: 5, ultraBonus: 10, strictStreak: false }), freeBonus: Number(e.target.value) }
                                        }));
                                    }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white font-bold" />
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-slate-600 uppercase">Basic User Bonus</label>
                                    <input type="number" value={localSettings.loginBonusConfig?.basicBonus ?? 5} onChange={e => {
                                        setLocalSettings(prev => ({
                                            ...prev,
                                            loginBonusConfig: { ...(prev.loginBonusConfig || { freeBonus: 2, basicBonus: 5, ultraBonus: 10, strictStreak: false }), basicBonus: Number(e.target.value) }
                                        }));
                                    }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white font-bold text-blue-600" />
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-slate-600 uppercase">Ultra User Bonus</label>
                                    <input type="number" value={localSettings.loginBonusConfig?.ultraBonus ?? 10} onChange={e => {
                                        setLocalSettings(prev => ({
                                            ...prev,
                                            loginBonusConfig: { ...(prev.loginBonusConfig || { freeBonus: 2, basicBonus: 5, ultraBonus: 10, strictStreak: false }), ultraBonus: Number(e.target.value) }
                                        }));
                                    }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white font-bold text-purple-600" />
                                </div>
                            </div>
                        </div>

                  </div>
              </div>

              {/* CUSTOM ADMIN POPUPS (New Requirement) */}
              <div className="mt-8 border-t border-slate-200 pt-8">
                  <div className="flex justify-between items-center mb-6">
                      <h4 className="font-black text-slate-800 text-lg flex items-center gap-2">
                          <MessageSquare size={20} className="text-blue-600" /> Custom Admin Popups
                      </h4>
                      <button
                          onClick={() => {
                              const newPopup = {
                                  enabled: false,
                                  title: 'New Announcement',
                                  message: 'Type your message here...',
                                  type: 'INFO' as const,
                                  showTo: 'ALL' as const
                              };
                              setLocalSettings({
                                  ...localSettings,
                                  adminCustomPopups: [...(localSettings.adminCustomPopups || []), newPopup]
                              });
                          }}
                          className="bg-slate-900 text-white px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-2"
                      >
                          <Plus size={14} /> Create Popup
                      </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {(localSettings.adminCustomPopups || []).map((popup, idx) => (
                          <div key={idx} className={`p-4 rounded-xl border-2 transition-all ${popup.enabled ? 'border-blue-500 bg-blue-50' : 'border-slate-200 bg-slate-50'}`}>
                              <div className="flex justify-between items-start mb-4">
                                  <div className="flex items-center gap-3">
                                      <input
                                          type="checkbox"
                                          checked={popup.enabled}
                                          onChange={(e) => {
                                              const newPopups = [...localSettings.adminCustomPopups!];
                                              newPopups[idx].enabled = e.target.checked;
                                              setLocalSettings({...localSettings, adminCustomPopups: newPopups});
                                          }}
                                          className="w-5 h-5 accent-blue-600"
                                      />
                                      <select
                                          value={popup.type}
                                          onChange={(e) => {
                                              const newPopups = [...localSettings.adminCustomPopups!];
                                              newPopups[idx].type = e.target.value as any;
                                              setLocalSettings({...localSettings, adminCustomPopups: newPopups});
                                          }}
                                          className="bg-white border rounded p-1 text-xs font-bold"
                                      >
                                          <option value="INFO">Info</option>
                                          <option value="DISCOUNT">Discount Event</option>
                                          <option value="FREE_CREDIT">Free Credits</option>
                                          <option value="FREE_ACCESS">Free Access</option>
                                          <option value="SUBSCRIPTION">Subscription Promos</option>
                                      </select>
                                  </div>
                                  <button onClick={() => {
                                      const newPopups = localSettings.adminCustomPopups!.filter((_, i) => i !== idx);
                                      setLocalSettings({...localSettings, adminCustomPopups: newPopups});
                                  }} className="text-red-400 hover:text-red-600">
                                      <Trash2 size={16} />
                                  </button>
                              </div>

                              <div className="space-y-3">
                                  <input
                                      type="text"
                                      value={popup.title}
                                      onChange={(e) => {
                                          const newPopups = [...localSettings.adminCustomPopups!];
                                          newPopups[idx].title = e.target.value;
                                          setLocalSettings({...localSettings, adminCustomPopups: newPopups});
                                      }}
                                      className="w-full p-2 border rounded font-bold text-sm"
                                      placeholder="Popup Title"
                                  />
                                  <textarea
                                      value={popup.message}
                                      onChange={(e) => {
                                          const newPopups = [...localSettings.adminCustomPopups!];
                                          newPopups[idx].message = e.target.value;
                                          setLocalSettings({...localSettings, adminCustomPopups: newPopups});
                                      }}
                                      className="w-full p-2 border rounded text-xs min-h-[60px]"
                                      placeholder="Popup Message..."
                                  />

                                  <div className="grid grid-cols-2 gap-2">
                                      <input
                                          type="text"
                                          value={popup.copyableText || ''}
                                          onChange={(e) => {
                                              const newPopups = [...localSettings.adminCustomPopups!];
                                              newPopups[idx].copyableText = e.target.value;
                                              setLocalSettings({...localSettings, adminCustomPopups: newPopups});
                                          }}
                                          className="w-full p-2 border rounded text-xs bg-slate-100 font-mono"
                                          placeholder="Copyable Code (Optional)"
                                      />
                                      <select
                                          value={popup.showTo}
                                          onChange={(e) => {
                                              const newPopups = [...localSettings.adminCustomPopups!];
                                              newPopups[idx].showTo = e.target.value as any;
                                              setLocalSettings({...localSettings, adminCustomPopups: newPopups});
                                          }}
                                          className="w-full p-2 border rounded text-xs font-bold"
                                      >
                                          <option value="ALL">Show to All</option>
                                          <option value="FREE">Free Users Only</option>
                                          <option value="PREMIUM">Premium Users Only</option>
                                      </select>
                                  </div>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      )}

      {activeTab === 'CONFIG_POPUPS' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Popup Management</h3>
                  <div className="ml-auto">
                      <button
                          onClick={() => handleSaveSettings()}
                          disabled={isSettingsSaving}
                          className={`bg-orange-600 text-white px-6 py-2 rounded-xl font-bold shadow-lg hover:bg-orange-700 flex items-center gap-2 ${isSettingsSaving ? 'opacity-70 cursor-wait' : ''}`}
                      >
                          {isSettingsSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                          {isSettingsSaving ? 'Saving...' : 'Save Config'}
                      </button>
                  </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* EXPIRY WARNING CONFIG */}
                  <div className="bg-red-50 p-6 rounded-xl border border-red-200">
                      <div className="flex justify-between items-center mb-4">
                          <h4 className="font-bold text-red-900 flex items-center gap-2">
                              <AlertTriangle size={20} /> Expiry Warning
                          </h4>
                          <input
                              type="checkbox"
                              checked={localSettings.popupConfigs?.isExpiryWarningEnabled !== false}
                              onChange={(e) => setLocalSettings({
                                  ...localSettings,
                                  popupConfigs: {
                                      ...localSettings.popupConfigs,
                                      isExpiryWarningEnabled: e.target.checked
                                  } as any
                              })}
                              className="w-6 h-6 accent-red-600"
                          />
                      </div>
                      <p className="text-xs text-red-700 mb-4">Shows a warning popup when subscription is about to expire.</p>

                      <div className="space-y-4">
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase">Start Showing Before (Hours)</label>
                              <input
                                  type="number"
                                  value={localSettings.popupConfigs?.expiryWarningHours || 48}
                                  onChange={(e) => setLocalSettings({
                                      ...localSettings,
                                      popupConfigs: {
                                          ...localSettings.popupConfigs,
                                          expiryWarningHours: Number(e.target.value)
                                      } as any
                                  })}
                                  className="w-full p-2 border rounded-lg font-bold"
                              />
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase">Repeat Interval (Minutes)</label>
                              <input
                                  type="number"
                                  value={localSettings.popupConfigs?.expiryWarningIntervalMinutes || 60}
                                  onChange={(e) => setLocalSettings({
                                      ...localSettings,
                                      popupConfigs: {
                                          ...localSettings.popupConfigs,
                                          expiryWarningIntervalMinutes: Number(e.target.value)
                                      } as any
                                  })}
                                  className="w-full p-2 border rounded-lg font-bold"
                              />
                          </div>
                      </div>
                  </div>

                  {/* UPSELL POPUP CONFIG */}
                  <div className="bg-purple-50 p-6 rounded-xl border border-purple-200">
                      <div className="flex justify-between items-center mb-4">
                          <h4 className="font-bold text-purple-900 flex items-center gap-2">
                              <Crown size={20} /> Upsell / Upgrade Popup
                          </h4>
                          <input
                              type="checkbox"
                              checked={localSettings.popupConfigs?.isUpsellEnabled !== false}
                              onChange={(e) => setLocalSettings({
                                  ...localSettings,
                                  popupConfigs: {
                                      ...localSettings.popupConfigs,
                                      isUpsellEnabled: e.target.checked
                                  } as any
                              })}
                              className="w-6 h-6 accent-purple-600"
                          />
                      </div>
                      <p className="text-xs text-purple-700 mb-4">Prompts Free/Basic users to upgrade to Ultra for more features.</p>

                      <div className="space-y-4">
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase">Show Every (Minutes)</label>
                              <input
                                  type="number"
                                  value={localSettings.popupConfigs?.upsellPopupIntervalMinutes || 120}
                                  onChange={(e) => setLocalSettings({
                                      ...localSettings,
                                      popupConfigs: {
                                          ...localSettings.popupConfigs,
                                          upsellPopupIntervalMinutes: Number(e.target.value)
                                      } as any
                                  })}
                                  className="w-full p-2 border rounded-lg font-bold"
                              />
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* --- PREMIUM VIDEO MANAGEMENT TAB (NEW) --- */}
      {activeTab === 'PREMIUM_VIDEO_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800 flex items-center gap-2">
                      <Crown size={24} className="text-yellow-600" /> Premium Video Manager
                  </h3>
              </div>

              <div className="bg-yellow-50 p-6 rounded-xl border border-yellow-200">
                  <p className="text-sm text-yellow-800 mb-4 font-bold bg-white p-3 rounded-lg border border-yellow-100">
                      Manage premium videos using Google Drive links. These videos will be organized by subject and chapter in the student dashboard.
                  </p>

                  <SubjectSelector />

                  <div className="space-y-4 mb-6">
                      {!editingChapterId ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[60vh] overflow-y-auto pr-2">
                              {selChapters.length === 0 && <p className="col-span-full text-center text-slate-500 text-sm py-8">Select a subject to view chapters.</p>}
                              {selChapters.map((ch) => (
                                  <div key={ch.id} className="bg-white p-3 rounded-xl border border-yellow-100 shadow-sm flex flex-col gap-2">
                                      <div className="flex justify-between items-center">
                                          <h5 className="font-bold text-slate-800 text-xs truncate w-3/4" title={ch.title}>{ch.title}</h5>
                                      </div>
                                      <button
                                          onClick={() => loadChapterContent(ch.id)}
                                          className="mt-2 w-full py-2 bg-yellow-600 text-white rounded-lg text-xs font-bold shadow-md hover:bg-yellow-700 flex items-center justify-center gap-2"
                                      >
                                          <Edit3 size={14} /> Manage Videos
                                      </button>
                                  </div>
                              ))}
                          </div>
                      ) : (
                          <div className="bg-white p-4 rounded-xl border border-yellow-200">
                              <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-3">
                                  <div>
                                      <h4 className="font-black text-slate-800 text-lg">{selChapters.find(c => c.id === editingChapterId)?.title}</h4>
                                      <p className="text-xs text-slate-600">Premium Video Playlist</p>
                                  </div>
                                  <button onClick={() => setEditingChapterId(null)} className="text-xs font-bold text-slate-500 hover:text-slate-600">Close Editor</button>
                              </div>

                              <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-2 mb-4">
                                  {premiumVideoPlaylist.map((vid, idx) => (
                                      <div key={idx} className="flex flex-col gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
                                          <div className="flex gap-2 items-center">
                                              <span className="w-6 text-center text-xs font-bold text-slate-500">{idx + 1}</span>
                                              <input
                                                  type="text"
                                                  value={vid.title}
                                                  onChange={(e) => {
                                                      const updated = [...premiumVideoPlaylist];
                                                      updated[idx].title = e.target.value;
                                                      setPremiumVideoPlaylist(updated);
                                                  }}
                                                  placeholder="Video Title"
                                                  className="flex-1 p-2 border border-slate-200 rounded text-xs font-bold"
                                              />
                                              <button
                                                  onClick={() => {
                                                      const updated = premiumVideoPlaylist.filter((_, i) => i !== idx);
                                                      setPremiumVideoPlaylist(updated);
                                                  }}
                                                  className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                                              >
                                                  <Trash2 size={16} />
                                              </button>
                                          </div>
                                          <input
                                              type="text"
                                              value={vid.url}
                                              onChange={(e) => {
                                                  const updated = [...premiumVideoPlaylist];
                                                  updated[idx].url = e.target.value;
                                                  setPremiumVideoPlaylist(updated);
                                              }}
                                              placeholder="Google Drive Link / YouTube URL"
                                              className="w-full p-2 border border-slate-200 rounded text-xs font-mono text-blue-600 bg-white ml-8"
                                          />
                                      </div>
                                  ))}
                              </div>

                              <div className="flex gap-2">
                                  <button
                                      onClick={() => setPremiumVideoPlaylist([...premiumVideoPlaylist, { title: '', url: '', price: 10, access: 'ULTRA' }])}
                                      className="flex-1 py-3 bg-yellow-50 text-yellow-700 rounded-xl text-xs font-bold border border-yellow-200 hover:bg-yellow-100 flex items-center justify-center gap-2 border-dashed"
                                  >
                                      <Plus size={16} /> Add Video
                                  </button>
                                  <button onClick={saveChapterContent} className="flex-1 bg-yellow-600 text-white font-bold py-3 rounded-xl shadow hover:bg-yellow-700 transition flex items-center justify-center gap-2">
                                      <Save size={16} /> Save Changes
                                  </button>
                              </div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {activeTab === 'UNIVERSAL_NOTES' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-blue-800">Universal Recommended Notes</h3>
              </div>

              <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">
                  <div className="flex items-center gap-2 mb-4">
                      <FileText size={24} className="text-blue-600" />
                      <h4 className="font-bold text-blue-900">Manage Recommended Notes</h4>
                  </div>
                  <p className="text-xs text-blue-700 mb-6 bg-white p-3 rounded-lg border border-blue-100">
                      Add structured recommendations linked to specific lessons. These appear in the "Smart Recommendations" modal based on topic matching.
                  </p>

                  <SubjectSelector />

                  {/* IMPORT TOOL (New Requirement) */}
                  <div className="mb-6 p-4 bg-white rounded-xl border-2 border-dashed border-cyan-300">
                      <h4 className="font-bold text-cyan-800 mb-2 flex items-center gap-2">
                          <Upload size={18} /> Smart Import (Notes + MCQs)
                      </h4>
                      <p className="text-[10px] text-slate-600 mb-3">
                          Paste text with <code>&lt;TOPIC: Name&gt;</code>, <code>&lt;NOTE: Name&gt; Content &lt;/NOTE&gt;</code>, and Questions. The system will auto-generate both Topic Notes and linked MCQs.
                      </p>
                      <textarea
                          value={importText}
                          onChange={(e) => setImportText(e.target.value)}
                          placeholder="Paste your content here..."
                          className="w-full h-24 p-2 border border-slate-300 rounded-lg text-xs font-mono mb-2"
                      />
                      <button
                          onClick={() => handleUnifiedImport(false)} // Pass false as we are not in Test mode
                          className="w-full py-2 bg-cyan-600 text-white font-bold rounded-lg hover:bg-cyan-700 shadow flex items-center justify-center gap-2"
                      >
                          <Sparkles size={16} /> Process & Create Revision Content
                      </button>
                  </div>

                  <div className="space-y-4 mb-6">
                      {!editingChapterId ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[60vh] overflow-y-auto pr-2">
                              {selChapters.length === 0 && <p className="col-span-full text-center text-slate-500 text-sm py-8">Select a subject to view lessons.</p>}
                              {selChapters.map((ch) => {
                                  const chapterNotes = universalNotes.filter(n => n.chapterId === ch.id);

                                  return (
                                      <div key={ch.id} className="bg-white p-3 rounded-xl border border-blue-100 shadow-sm flex flex-col gap-2">
                                          <div className="flex justify-between items-center">
                                              <h5 className="font-bold text-slate-800 text-xs truncate w-3/4" title={ch.title}>{ch.title}</h5>
                                              <span className="text-[9px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full border border-blue-100 font-bold">{chapterNotes.length}</span>
                                          </div>
                                          <button
                                              onClick={() => setEditingChapterId(ch.id)}
                                              className="mt-2 w-full py-2 bg-blue-600 text-white rounded-lg text-xs font-bold shadow-md hover:bg-blue-700 flex items-center justify-center gap-2"
                                          >
                                              <Edit3 size={14} /> Manage Notes
                                          </button>
                                      </div>
                                  );
                              })}
                          </div>
                      ) : (
                          <div className="bg-white p-4 rounded-xl border border-blue-200">
                              <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-3">
                                  <div>
                                      <h4 className="font-black text-slate-800 text-lg">{selChapters.find(c => c.id === editingChapterId)?.title}</h4>
                                      <p className="text-xs text-slate-600">Managing Recommended Notes</p>
                                  </div>
                                  <button onClick={() => setEditingChapterId(null)} className="text-xs font-bold text-slate-500 hover:text-slate-600">Close Editor</button>
                              </div>

                              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2 pb-24">
                                  {universalNotes.filter(n => n.chapterId === editingChapterId).map((note, idx) => (
                                      <div key={note.id || idx} className="flex flex-col gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
                                          <div className="flex gap-2 items-center">
                                              <span className="w-6 text-center text-xs font-bold text-slate-500">{idx + 1}</span>

                                              {/* TYPE BADGE */}
                                              <span className={`px-2 py-1 rounded text-[9px] font-bold uppercase ${note.type === 'HTML' ? 'bg-orange-100 text-orange-600' : 'bg-red-100 text-red-600'}`}>
                                                  {note.type || 'PDF'}
                                              </span>

                                              <input
                                                  type="text"
                                                  value={note.title}
                                                  onChange={(e) => {
                                                      const updated = universalNotes.map(n => n === note ? { ...n, title: e.target.value, topic: e.target.value } : n);
                                                      setUniversalNotes(updated);
                                                  }}
                                                  placeholder="Topic Name (e.g. Ohm's Law)"
                                                  className="flex-1 p-2 border border-slate-200 rounded text-xs font-bold"
                                              />
                                              {/* Access is implied by Type now, but we keep it for backward compat/flexibility */}
                                              <span className={`px-2 py-1 text-[9px] font-bold border rounded ${note.access === 'FREE' ? 'border-green-200 text-green-600 bg-green-50' : 'border-purple-200 text-purple-600 bg-purple-50'}`}>
                                                  {note.access}
                                              </span>
                                              <button
                                                  onClick={() => {
                                                      const updated = universalNotes.filter(n => n !== note);
                                                      setUniversalNotes(updated);
                                                  }}
                                                  className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                                              >
                                                  <Trash2 size={16} />
                                              </button>
                                          </div>

                                          {note.type === 'HTML' ? (
                                              <textarea
                                                  value={note.content || ''}
                                                  onChange={(e) => {
                                                      const updated = universalNotes.map(n => n === note ? { ...n, content: e.target.value } : n);
                                                      setUniversalNotes(updated);
                                                  }}
                                                  placeholder="Enter HTML Notes Content..."
                                                  className="w-full p-2 border border-slate-200 rounded text-xs font-mono text-slate-600 bg-white ml-8 h-20"
                                              />
                                          ) : (
                                              <input
                                                  type="text"
                                                  value={note.url}
                                                  onChange={(e) => {
                                                      const updated = universalNotes.map(n => n === note ? { ...n, url: e.target.value } : n);
                                                      setUniversalNotes(updated);
                                                  }}
                                                  placeholder="PDF URL"
                                                  className="w-full p-2 border border-slate-200 rounded text-xs font-mono text-blue-600 bg-white ml-8"
                                              />
                                          )}
                                      </div>
                                  ))}
                              </div>

                              <div className="mt-4 grid grid-cols-2 gap-3">
                                  <button
                                      onClick={() => {
                                          const ch = selChapters.find(c => c.id === editingChapterId);
                                      if (ch) {
                                          const newNote = {
                                              id: `rec-${Date.now()}`,
                                              title: '',
                                              type: 'HTML',
                                              content: '',
                                              access: 'FREE',
                                              price: 0,
                                              chapterId: ch.id,
                                              subjectName: selSubject?.name,
                                              topic: '',
                                              board: selBoard,
                                              classLevel: selClass
                                          };
                                          setUniversalNotes([...universalNotes, newNote]);
                                      }
                                  }}
                                  className="py-3 bg-orange-50 text-orange-600 rounded-xl text-xs font-bold border border-orange-100 hover:bg-orange-100 flex items-center justify-center gap-2 border-dashed"
                              >
                                  <FileText size={16} /> Add Free Note (HTML)
                              </button>

                              <button
                                  onClick={() => {
                                      const ch = selChapters.find(c => c.id === editingChapterId);
                                      if (ch) {
                                          const newNote = {
                                              id: `rec-${Date.now()}`,
                                              title: '',
                                              type: 'PDF',
                                              url: '',
                                              access: 'ULTRA', // Premium Default
                                              price: 0,
                                              chapterId: ch.id,
                                              subjectName: selSubject?.name,
                                              topic: '',
                                              board: selBoard,
                                              classLevel: selClass
                                          };
                                          setUniversalNotes([...universalNotes, newNote]);
                                      }
                                  }}
                                  className="py-3 bg-red-50 text-red-600 rounded-xl text-xs font-bold border border-red-100 hover:bg-red-100 flex items-center justify-center gap-2 border-dashed"
                              >
                                  <FileText size={16} /> Add Premium Note (PDF)
                              </button>
                              </div>
                          </div>
                      )}
                  </div>

                  <div className="flex gap-2 border-t border-blue-200 pt-4">
                      <button
                          onClick={() => {
                              // Manual Add (Legacy / Global)
                              const title = prompt("Note Title");
                              if(!title) return;
                              const url = prompt("PDF URL");
                              if(!url) return;
                              setUniversalNotes([...universalNotes, { title, url, access: 'FREE' }]);
                          }}
                          className="flex-1 py-3 bg-white border border-blue-200 text-blue-600 font-bold rounded-xl hover:bg-blue-50 transition dashed"
                      >
                          + Add Unlinked Note
                      </button>
                      <button onClick={saveUniversalNotes} className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl shadow hover:bg-blue-700 transition">
                          💾 Save All Changes
                      </button>
                  </div>
              </div>
          </div>
      )}


      {/* --- FEATURED CONTENT SHORTCUTS --- */}
      {activeTab === 'FEATURED_CONTENT' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Home Screen Shortcuts</h3>
              </div>
              
              <div className="mb-6">
                  <label className="text-xs font-bold uppercase text-slate-600 block mb-1">Section Title (Question)</label>
                  <input 
                      type="text" 
                      value={localSettings.featuredSectionTitle || ''} 
                      onChange={e => setLocalSettings({...localSettings, featuredSectionTitle: e.target.value})} 
                      placeholder="e.g., What do you want to learn today?" 
                      className="w-full p-3 border rounded-xl font-bold text-slate-800"
                  />
                  <div className="mt-2 text-right">
                      <button onClick={() => handleSaveSettings()} className="bg-slate-800 text-white px-4 py-2 rounded-lg text-xs font-bold">Update Title</button>
                  </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 mb-8">
                  <h4 className="font-bold text-blue-900 mb-4">Add New Shortcut (Max 4)</h4>
                  
                  {/* Selector Reuse */}
                  <SubjectSelector />

                  {selSubject && (
                      <div className="space-y-4">
                          <div className="bg-white p-3 rounded-xl border border-blue-200">
                              <p className="text-xs font-bold text-slate-600 uppercase mb-2">Select Chapter</p>
                              <select 
                                  onChange={e => {
                                      const ch = selChapters.find(c => c.id === e.target.value);
                                      if (ch) {
                                          // Add logic
                                          if ((localSettings.featuredItems?.length || 0) >= 4) {
                                              alert("Max 4 items allowed. Please delete one first.");
                                              return;
                                          }
                                          const type = prompt("Content Type? (MCQ / PDF / VIDEO)", "MCQ");
                                          if (!type) return;
                                          const cleanType = type.toUpperCase().trim();
                                          if (!['MCQ', 'PDF', 'VIDEO'].includes(cleanType)) {
                                              alert("Invalid Type. Use MCQ, PDF, or VIDEO");
                                              return;
                                          }

                                          const newItem = {
                                              id: `feat-${Date.now()}`,
                                              title: ch.title,
                                              subtitle: `${selClass} • ${selSubject.name}`,
                                              board: selBoard,
                                              classLevel: selClass,
                                              stream: selStream,
                                              subject: selSubject,
                                              chapter: ch,
                                              type: cleanType as any
                                          };

                                          const updated = [...(localSettings.featuredItems || []), newItem];
                                          setLocalSettings({...localSettings, featuredItems: updated});
                                          // Save immediately to preview
                                          localStorage.setItem('nst_system_settings', JSON.stringify({...localSettings, featuredItems: updated}));
                                      }
                                  }}
                                  className="w-full p-2 border rounded-lg"
                              >
                                  <option value="">-- Choose Chapter --</option>
                                  {selChapters.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                              </select>
                          </div>

                      </div>
                  )}
              </div>

              <div className="space-y-3">
                  <h4 className="font-bold text-slate-800">Active Shortcuts</h4>
                  {(!localSettings.featuredItems || localSettings.featuredItems.length === 0) && <p className="text-slate-500 text-sm">No shortcuts added.</p>}
                  {localSettings.featuredItems?.map((item, idx) => (
                      <div key={item.id} className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                          <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs ${item.type === 'MCQ' ? 'bg-purple-100 text-purple-600' : item.type === 'PDF' ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'}`}>
                                  {item.type}
                              </div>
                              <div>
                                  <p className="font-bold text-slate-800">{item.title}</p>
                                  <p className="text-xs text-slate-600">{item.subtitle} ({item.board})</p>
                              </div>
                          </div>
                          <button onClick={() => {
                              const updated = localSettings.featuredItems!.filter((_, i) => i !== idx);
                              setLocalSettings({...localSettings, featuredItems: updated});
                          }} className="text-red-400 hover:text-red-600 p-2"><Trash2 size={18} /></button>
                      </div>
                  ))}
              </div>
              
              <button onClick={() => handleSaveSettings()} className="w-full mt-6 bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-green-700">Save Changes & Publish</button>
          </div>
      )}

      {/* --- VISIBILITY CONFIG TAB --- */}
      {activeTab === 'CONFIG_AI' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">AI Configuration</h3>
              </div>

              <div className="space-y-6">
                  {/* ENABLE AI TOGGLE */}
                  <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-indigo-600 text-white rounded-xl flex items-center justify-center shadow-lg">
                              <BrainCircuit size={24} />
                          </div>
                          <div>
                              <h4 className="font-bold text-indigo-900 text-lg">Enable AI Assistant</h4>
                              <p className="text-xs text-indigo-700">Allow students to use AI features.</p>
                          </div>
                      </div>
                      <button 
                          onClick={() => setLocalSettings({...localSettings, isAiEnabled: !localSettings.isAiEnabled})}
                          className={`w-16 h-8 rounded-full transition-all relative ${localSettings.isAiEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}
                      >
                          <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-sm ${localSettings.isAiEnabled ? 'left-9' : 'left-1'}`} />
                      </button>
                  </div>

                  {/* GROQ KEY MANAGEMENT (RECYCLE BIN SUPPORT) */}
                  <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-200">
                      <div className="flex justify-between items-center mb-4">
                          <h4 className="font-bold text-indigo-900 flex items-center gap-2">
                              <Key size={18} /> Groq API Keys (Safe Mode)
                          </h4>
                          <span className="text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded border border-green-200 font-bold">
                              {localSettings.groqApiKeys?.length || 0} Active
                          </span>
                      </div>
                      
                      {/* Add Keys Area */}
                      <div className="mb-4">
                          <textarea 
                              placeholder="Paste Groq API Keys (One per line)" 
                              value={newSecureKey}
                              onChange={(e) => setNewSecureKey(e.target.value)}
                              className="w-full p-3 border rounded-xl h-24 text-xs font-mono"
                          />
                          <div className="flex justify-end gap-2 mt-2">
                              <button 
                                  onClick={() => {
                                      if (newSecureKey.trim()) {
                                          const newKeys = newSecureKey.split('\n').map(k => k.trim()).filter(k => k.length > 10);
                                          const current = localSettings.groqApiKeys || [];
                                          // Merge unique
                                          const merged = Array.from(new Set([...current, ...newKeys]));
                                          setLocalSettings({...localSettings, groqApiKeys: merged});
                                          setNewSecureKey('');
                                          alert(`Added ${newKeys.length} keys!`);
                                      }
                                  }}
                                  className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold text-xs"
                              >
                                  + Add Keys
                              </button>
                          </div>
                      </div>

                      {/* Active Keys List */}
                      <div className="space-y-2 mb-6 max-h-40 overflow-y-auto">
                          {(localSettings.groqApiKeys || []).map((k, i) => (
                              <div key={i} className="flex gap-2 items-center bg-white p-2 rounded-lg border border-indigo-100">
                                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                                  <input 
                                      type="password" 
                                      value={k} 
                                      disabled 
                                      className="flex-1 bg-transparent border-none text-xs text-slate-600 font-mono"
                                  />
                                  <span className={`text-[10px] font-bold ${keyStatus[i]?.includes('Valid') ? 'text-green-600' : 'text-slate-500'}`}>
                                      {keyStatus[i] || 'Ready'}
                                  </span>
                                  <button 
                                      onClick={() => {
                                          if (!confirm("Move key to Recycle Bin?")) return;
                                          const keyToDelete = k;
                                          const updatedActive = (localSettings.groqApiKeys || []).filter(key => key !== keyToDelete);
                                          
                                          // Add to Recycle Bin
                                          const recycleEntry = { key: keyToDelete, deletedAt: Date.now() };
                                          const updatedRecycle = [...(localSettings.deletedGroqKeys || []), recycleEntry];
                                          
                                          setLocalSettings({
                                              ...localSettings, 
                                              groqApiKeys: updatedActive,
                                              deletedGroqKeys: updatedRecycle
                                          });
                                      }}
                                      className="text-slate-500 hover:text-red-500 p-1"
                                      title="Move to Recycle Bin"
                                  >
                                      <Trash2 size={14} />
                                  </button>
                              </div>
                          ))}
                          {(localSettings.groqApiKeys || []).length === 0 && (
                              <p className="text-center text-xs text-slate-500 italic">No active keys.</p>
                          )}
                      </div>

                      {/* Recycle Bin Section */}
                      <div className="border-t border-indigo-200 pt-4">
                          <h5 className="text-xs font-bold text-slate-600 uppercase mb-2 flex items-center gap-2">
                              <Trash2 size={12} /> Recycle Bin ({localSettings.deletedGroqKeys?.length || 0})
                          </h5>
                          <div className="space-y-2 max-h-32 overflow-y-auto">
                              {(localSettings.deletedGroqKeys || []).map((item, i) => (
                                  <div key={i} className="flex gap-2 items-center bg-slate-100 p-2 rounded-lg opacity-70 hover:opacity-100 transition-opacity">
                                      <span className="text-[10px] font-mono text-slate-600 flex-1 truncate">
                                          ...{item.key.slice(-6)} (Del: {new Date(item.deletedAt).toLocaleDateString()})
                                      </span>
                                      <button 
                                          onClick={() => {
                                              // Restore
                                              const updatedRecycle = (localSettings.deletedGroqKeys || []).filter((_, idx) => idx !== i);
                                              const updatedActive = [...(localSettings.groqApiKeys || []), item.key];
                                              setLocalSettings({
                                                  ...localSettings,
                                                  groqApiKeys: updatedActive,
                                                  deletedGroqKeys: updatedRecycle
                                              });
                                          }}
                                          className="text-green-600 hover:text-green-800 text-[10px] font-bold px-2"
                                      >
                                          RESTORE
                                      </button>
                                      <button 
                                          onClick={() => {
                                              if(!confirm("Permanently delete? This cannot be undone.")) return;
                                              const updatedRecycle = (localSettings.deletedGroqKeys || []).filter((_, idx) => idx !== i);
                                              setLocalSettings({...localSettings, deletedGroqKeys: updatedRecycle});
                                          }}
                                          className="text-red-500 hover:text-red-700 text-[10px] font-bold px-2"
                                      >
                                          PERMANENT
                                      </button>
                                  </div>
                              ))}
                          </div>
                      </div>
                      
                      <div className="flex gap-2 mt-4 pt-2 border-t border-indigo-100">
                          <button onClick={testKeys} className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg font-bold text-xs hover:bg-slate-900">
                              {isTestingKeys ? 'Testing Connectivity...' : 'Test All Active Keys'}
                          </button>
                      </div>
                  </div>

                  {/* AI USAGE SPLIT (80/20) */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-200">
                      <div className="flex justify-between items-center mb-4">
                          <h4 className="font-bold text-slate-800 flex items-center gap-2">
                              <Activity size={18} className="text-blue-500" /> AI Usage Split
                          </h4>
                          <span className="text-xs font-black bg-slate-100 px-2 py-1 rounded">
                              {localSettings.aiUsageSplit ?? 80}% Pilot / {100 - (localSettings.aiUsageSplit ?? 80)}% Students
                          </span>
                      </div>
                      <input 
                          type="range" 
                          min="0" max="100" 
                          step="5"
                          value={localSettings.aiUsageSplit ?? 80}
                          onChange={(e) => setLocalSettings({...localSettings, aiUsageSplit: Number(e.target.value)})}
                          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 mt-2 font-bold uppercase">
                          <span>0% Pilot</span>
                          <span>50/50</span>
                          <span>100% Pilot</span>
                      </div>
                      <p className="text-[10px] text-slate-600 mt-2">
                          Controls resource allocation. Higher Pilot % ensures more auto-generated content availability.
                      </p>
                  </div>

                  {/* AI NAME */}
                  <div className="bg-white p-4 rounded-xl border border-slate-200">
                      <label className="text-xs font-bold text-slate-600 uppercase block mb-2">AI Assistant Name</label>
                      <input 
                          type="text" 
                          value={localSettings.aiName || 'IIC AI'}
                          onChange={(e) => setLocalSettings({...localSettings, aiName: e.target.value})}
                          className="w-full p-3 border rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-indigo-100 outline-none"
                          placeholder="e.g. Jarvis"
                      />
                  </div>

                  {/* AI LIMITS */}
                  <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                      <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                          <Zap size={18} className="text-yellow-500" /> Daily Generation Limits
                      </h4>
                      <div className="grid grid-cols-3 gap-4">
                          <div>
                              <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">Free User</label>
                              <input 
                                  type="number" 
                                  value={localSettings.aiLimits?.free ?? 5} 
                                  onChange={(e) => setLocalSettings({
                                      ...localSettings, 
                                      aiLimits: { ...(localSettings.aiLimits || {free:5, basic:20, ultra:100}), free: Number(e.target.value) }
                                  })}
                                  className="w-full p-2 border rounded-lg font-bold text-center"
                              />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">Basic User</label>
                              <input 
                                  type="number" 
                                  value={localSettings.aiLimits?.basic ?? 20} 
                                  onChange={(e) => setLocalSettings({
                                      ...localSettings, 
                                      aiLimits: { ...(localSettings.aiLimits || {free:5, basic:20, ultra:100}), basic: Number(e.target.value) }
                                  })}
                                  className="w-full p-2 border rounded-lg font-bold text-center text-blue-600"
                              />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">Ultra User</label>
                              <input 
                                  type="number" 
                                  value={localSettings.aiLimits?.ultra ?? 100} 
                                  onChange={(e) => setLocalSettings({
                                      ...localSettings, 
                                      aiLimits: { ...(localSettings.aiLimits || {free:5, basic:20, ultra:100}), ultra: Number(e.target.value) }
                                  })}
                                  className="w-full p-2 border rounded-lg font-bold text-center text-purple-600"
                              />
                          </div>
                      </div>
                  </div>

                  {/* AI PROMPTS */}
                  <div className="space-y-4">
                      <div className="bg-white p-4 rounded-xl border border-slate-200">
                          <label className="text-xs font-bold text-slate-600 uppercase block mb-2">Notes Prompt (Standard)</label>
                          <textarea 
                              value={localSettings.aiNotesPrompt || ''}
                              onChange={(e) => setLocalSettings({...localSettings, aiNotesPrompt: e.target.value})}
                              className="w-full h-32 p-3 border rounded-xl text-xs font-mono bg-slate-50 focus:bg-white transition-colors resize-none"
                              placeholder="System instruction for generating notes..."
                          />
                      </div>
                  </div>

                  {/* --- LOGIN REWARD SETTINGS --- */}
                  <div className="bg-white p-4 sm:p-6 rounded-2xl shadow-sm border border-slate-200 mt-4">
                      <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2"><Zap size={18} className="text-blue-500" /> Daily Login Bonus Settings</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                          <div>
                              <label className="text-[10px] font-bold text-slate-600 uppercase">Free User Bonus</label>
                              <input type="number" value={localSettings.loginBonusConfig?.freeBonus ?? 2} onChange={e => {
                                  setLocalSettings(prev => ({
                                      ...prev,
                                      loginBonusConfig: { ...(prev.loginBonusConfig || { freeBonus: 2, basicBonus: 5, ultraBonus: 10, strictStreak: false }), freeBonus: Number(e.target.value) }
                                  }));
                              }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white font-bold" />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-slate-600 uppercase">Basic User Bonus</label>
                              <input type="number" value={localSettings.loginBonusConfig?.basicBonus ?? 5} onChange={e => {
                                  setLocalSettings(prev => ({
                                      ...prev,
                                      loginBonusConfig: { ...(prev.loginBonusConfig || { freeBonus: 2, basicBonus: 5, ultraBonus: 10, strictStreak: false }), basicBonus: Number(e.target.value) }
                                  }));
                              }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white font-bold text-blue-600" />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-slate-600 uppercase">Ultra User Bonus</label>
                              <input type="number" value={localSettings.loginBonusConfig?.ultraBonus ?? 10} onChange={e => {
                                  setLocalSettings(prev => ({
                                      ...prev,
                                      loginBonusConfig: { ...(prev.loginBonusConfig || { freeBonus: 2, basicBonus: 5, ultraBonus: 10, strictStreak: false }), ultraBonus: Number(e.target.value) }
                                  }));
                              }} className="w-full p-2 border rounded-lg mt-1 text-sm bg-white font-bold text-purple-600" />
                          </div>
                      </div>
                  </div>

              </div>

              <button onClick={() => handleSaveSettings()} className="w-full mt-6 bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-green-700 flex items-center justify-center gap-2">
                  <Save size={18} /> Save AI Settings
              </button>
          </div>
      )}

      {/* --- GENERAL CONFIG TAB (With Version Control) --- */}
      {activeTab === 'CONFIG_GENERAL' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">General Settings</h3>
              </div>

              <div className="space-y-6">
                  {/* APP IDENTITY & AI CHAT */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <div className="flex justify-between items-center mb-3">
                          <h4 className="font-bold text-slate-700">App Identity & Features</h4>
                          {/* AI CHAT TOGGLE */}
                          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-indigo-100 shadow-sm">
                              <Bot size={16} className="text-indigo-600"/>
                              <span className="text-xs font-bold text-slate-600">Student AI Chat</span>
                              <div
                                  onClick={() => toggleSetting('isChatEnabled')}
                                  className={`w-8 h-4 rounded-full relative cursor-pointer transition-colors ${localSettings.isChatEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}
                              >
                                  <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all shadow-sm ${localSettings.isChatEnabled ? 'left-4.5' : 'left-0.5'}`} style={{left: localSettings.isChatEnabled ? '18px' : '2px'}}></div>
                              </div>
                          </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase block mb-1">App Name</label>
                              <input 
                                  type="text" 
                                  value={localSettings.appName || ''} 
                                  onChange={(e) => setLocalSettings({...localSettings, appName: e.target.value})}
                                  className="w-full p-2 border rounded-lg"
                              />
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Watermark Opacity ({localSettings.watermarkOpacity || 0.9})</label>
                              <input
                                  type="range"
                                  min="0.1" max="1.0" step="0.1"
                                  value={localSettings.watermarkOpacity || 0.9}
                                  onChange={(e) => setLocalSettings({...localSettings, watermarkOpacity: Number(e.target.value)})}
                                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                              />
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Theme Color</label>
                              <div className="flex gap-2">
                                  <input 
                                      type="color" 
                                      value={localSettings.themeColor || '#3b82f6'} 
                                      onChange={(e) => setLocalSettings({...localSettings, themeColor: e.target.value})}
                                      className="w-10 h-10 rounded-lg cursor-pointer border-none"
                                  />
                                  <input 
                                      type="text" 
                                      value={localSettings.themeColor || '#3b82f6'} 
                                      onChange={(e) => setLocalSettings({...localSettings, themeColor: e.target.value})}
                                      className="flex-1 p-2 border rounded-lg uppercase"
                                  />
                              </div>
                          </div>
                          <div className="md:col-span-2">
                              <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Custom Page Video URL</label>
                              <input
                                  type="text"
                                  placeholder="Paste Google Drive video URL here"
                                  value={localSettings.customBloggerVideoUrl || ''}
                                  onChange={(e) => setLocalSettings({...localSettings, customBloggerVideoUrl: e.target.value})}
                                  className="w-full p-2 bg-slate-50 border rounded-lg text-sm"
                              />
                              <p className="text-[10px] text-slate-500 mt-1">This video will play in the Custom Page. (Google Drive link)</p>
                          </div>
                          <div className="md:col-span-2">
                              <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Loading Screen Intro Video URL</label>
                              <input
                                  type="text"
                                  placeholder="Paste Google Drive video URL here"
                                  value={localSettings.loadingScreenVideoUrl || ''}
                                  onChange={(e) => setLocalSettings({...localSettings, loadingScreenVideoUrl: e.target.value})}
                                  className="w-full p-2 bg-slate-50 border rounded-lg text-sm"
                              />
                              <p className="text-[10px] text-slate-500 mt-1">This video will play BEFORE the app loading screen. (Google Drive link)</p>
                          </div>
                      </div>
                  </div>

              </div>

              {/* NEW BANNER CONFIG SECTION */}
              <div className="mt-8 pt-8 border-t border-slate-100">
                  <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                      <Megaphone size={20} className="text-red-500"/> App Banners
                  </h4>
                  <p className="text-xs text-slate-600 mb-4">Manage the top and bottom scrolling messages.</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* TOP BANNER */}
                      <div className="bg-red-50 p-4 rounded-xl border border-red-100">
                          <div className="flex justify-between items-center mb-4">
                              <label className="font-bold text-red-800 text-sm uppercase">Top Banner</label>
                              <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-bold text-red-600">{localSettings.bannerConfig?.top?.enabled ? 'VISIBLE' : 'HIDDEN'}</span>
                                  <input
                                      type="checkbox"
                                      checked={localSettings.bannerConfig?.top?.enabled ?? true}
                                      onChange={(e) => setLocalSettings({
                                          ...localSettings,
                                          bannerConfig: {
                                              ...(localSettings.bannerConfig || {
                                                  top: { text: '', enabled: true, autoHideSeconds: 0, bgColor: '#dc2626', textColor: '#ffffff' },
                                                  bottom: { text: '', enabled: true, autoHideSeconds: 0, bgColor: '#2563eb', textColor: '#ffffff' }
                                              }),
                                              top: { ...(localSettings.bannerConfig?.top || { text: '', enabled: true, autoHideSeconds: 0, bgColor: '#dc2626', textColor: '#ffffff' }), enabled: e.target.checked }
                                          }
                                      })}
                                      className="w-5 h-5 accent-red-600"
                                  />
                              </div>
                          </div>

                          <div className="space-y-3">
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 uppercase">Message Text</label>
                                  <input
                                      type="text"
                                      value={localSettings.bannerConfig?.top?.text || ''}
                                      onChange={(e) => setLocalSettings({
                                          ...localSettings,
                                          bannerConfig: {
                                              ...(localSettings.bannerConfig || { top: { text: '', enabled: true, autoHideSeconds: 0 }, bottom: { text: '', enabled: true, autoHideSeconds: 0 } } as any),
                                              top: { ...(localSettings.bannerConfig?.top || {} as any), text: e.target.value }
                                          }
                                      })}
                                      className="w-full p-2 rounded-lg border border-red-200 text-sm font-bold text-slate-700"
                                  />
                              </div>

                              <div className="grid grid-cols-2 gap-2">
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-600 uppercase">Auto-Hide (Secs)</label>
                                      <input
                                          type="number"
                                          value={localSettings.bannerConfig?.top?.autoHideSeconds || 0}
                                          onChange={(e) => setLocalSettings({
                                              ...localSettings,
                                              bannerConfig: {
                                                  ...(localSettings.bannerConfig || {} as any),
                                                  top: { ...(localSettings.bannerConfig?.top || {} as any), autoHideSeconds: Number(e.target.value) }
                                              }
                                          })}
                                          className="w-full p-2 rounded-lg border border-red-200 text-sm"
                                          placeholder="0 = Always"
                                      />
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-600 uppercase">Background</label>
                                      <div className="flex gap-1">
                                          <input
                                              type="color"
                                              value={localSettings.bannerConfig?.top?.bgColor || '#dc2626'}
                                              onChange={(e) => setLocalSettings({
                                                  ...localSettings,
                                                  bannerConfig: {
                                                      ...(localSettings.bannerConfig || {} as any),
                                                      top: { ...(localSettings.bannerConfig?.top || {} as any), bgColor: e.target.value }
                                                  }
                                              })}
                                              className="h-9 w-full rounded cursor-pointer"
                                          />
                                      </div>
                                  </div>
                              </div>
                              <p className="text-[10px] text-red-400">* Set Auto-Hide to 0 to keep visible always.</p>
                          </div>
                      </div>

                      {/* BOTTOM BANNER */}
                      <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                          <div className="flex justify-between items-center mb-4">
                              <label className="font-bold text-blue-800 text-sm uppercase">Bottom Banner</label>
                              <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-bold text-blue-600">{localSettings.bannerConfig?.bottom?.enabled ? 'VISIBLE' : 'HIDDEN'}</span>
                                  <input
                                      type="checkbox"
                                      checked={localSettings.bannerConfig?.bottom?.enabled ?? true}
                                      onChange={(e) => setLocalSettings({
                                          ...localSettings,
                                          bannerConfig: {
                                              ...(localSettings.bannerConfig || {
                                                  top: { text: '', enabled: true, autoHideSeconds: 0 },
                                                  bottom: { text: '', enabled: true, autoHideSeconds: 0 }
                                              } as any),
                                              bottom: { ...(localSettings.bannerConfig?.bottom || {} as any), enabled: e.target.checked }
                                          }
                                      })}
                                      className="w-5 h-5 accent-blue-600"
                                  />
                              </div>
                          </div>

                          <div className="space-y-3">
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 uppercase">Message Text</label>
                                  <input
                                      type="text"
                                      value={localSettings.bannerConfig?.bottom?.text || ''}
                                      onChange={(e) => setLocalSettings({
                                          ...localSettings,
                                          bannerConfig: {
                                              ...(localSettings.bannerConfig || {} as any),
                                              bottom: { ...(localSettings.bannerConfig?.bottom || {} as any), text: e.target.value }
                                          }
                                      })}
                                      className="w-full p-2 rounded-lg border border-blue-200 text-sm font-bold text-slate-700"
                                  />
                              </div>

                              <div className="grid grid-cols-2 gap-2">
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-600 uppercase">Auto-Hide (Secs)</label>
                                      <input
                                          type="number"
                                          value={localSettings.bannerConfig?.bottom?.autoHideSeconds || 0}
                                          onChange={(e) => setLocalSettings({
                                              ...localSettings,
                                              bannerConfig: {
                                                  ...(localSettings.bannerConfig || {} as any),
                                                  bottom: { ...(localSettings.bannerConfig?.bottom || {} as any), autoHideSeconds: Number(e.target.value) }
                                              }
                                          })}
                                          className="w-full p-2 rounded-lg border border-blue-200 text-sm"
                                          placeholder="0 = Always"
                                      />
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-600 uppercase">Background</label>
                                      <div className="flex gap-1">
                                          <input
                                              type="color"
                                              value={localSettings.bannerConfig?.bottom?.bgColor || '#2563eb'}
                                              onChange={(e) => setLocalSettings({
                                                  ...localSettings,
                                                  bannerConfig: {
                                                      ...(localSettings.bannerConfig || {} as any),
                                                      bottom: { ...(localSettings.bannerConfig?.bottom || {} as any), bgColor: e.target.value }
                                                  }
                                              })}
                                              className="h-9 w-full rounded cursor-pointer"
                                          />
                                      </div>
                                  </div>
                              </div>
                              <p className="text-[10px] text-blue-400">* Set Auto-Hide to 0 to keep visible always.</p>
                          </div>
                      </div>
                  </div>
              </div>

              <button onClick={() => handleSaveSettings()} className="w-full mt-6 bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-green-700 flex items-center justify-center gap-2">
                  <Save size={18} /> Save General Settings
              </button>
          </div>
      )}

      {/* --- PRIZE SETTINGS TAB --- */}
      {activeTab === 'CONFIG_PRIZES' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Prize Rules</h3>
              </div>

              {/* CREDIT FREE EVENT TOGGLE */}
              <div className="bg-gradient-to-r from-yellow-100 to-amber-100 p-6 rounded-2xl border border-amber-200 mb-6">
                  <div className="flex justify-between items-center">
                      <div>
                          <h4 className="font-black text-amber-900 text-lg flex items-center gap-2"><Zap size={20}/> Credit Free Event</h4>
                          <p className="text-sm text-amber-800">Make all content FREE (0 Credits) for everyone temporarily.</p>
                      </div>
                      <button
                          onClick={() => toggleSetting('isCreditFreeEvent')}
                          className={`px-6 py-3 rounded-xl font-bold shadow-lg transition-transform active:scale-95 ${localSettings.isCreditFreeEvent ? 'bg-green-600 text-white animate-pulse' : 'bg-slate-800 text-white'}`}
                      >
                          {localSettings.isCreditFreeEvent ? 'EVENT ACTIVE (FREE)' : 'START EVENT'}
                      </button>
                  </div>
              </div>

              <div className="bg-yellow-50 p-6 rounded-2xl border border-yellow-100 mb-8">
                  <h4 className="font-bold text-yellow-900 mb-4">Add New Prize Rule</h4>
                  <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="text-xs font-bold text-yellow-700 uppercase block mb-1">Category</label>
                              <select id="prize-category" className="w-full p-3 rounded-xl border border-yellow-200 font-bold bg-white">
                                  <option value="SYLLABUS_MCQ">Syllabus MCQ (Practice)</option>
                                  <option value="WEEKLY_TEST">Weekly Test</option>
                                  <option value="DAILY_CHALLENGE">Daily Challenge</option>
                              </select>
                          </div>
                          <div>
                              <label className="text-xs font-bold text-yellow-700 uppercase block mb-1">Reward Type</label>
                              <select id="prize-type" className="w-full p-3 rounded-xl border border-yellow-200 font-bold bg-white">
                                  <option value="COINS">Coins</option>
                                  <option value="SUBSCRIPTION">Subscription</option>
                              </select>
                          </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="text-xs font-bold text-yellow-700 uppercase block mb-1">Min Questions</label>
                              <input id="prize-min-q" type="number" placeholder="e.g. 50" className="w-full p-3 rounded-xl border border-yellow-200 font-bold" />
                          </div>
                          <div>
                              <label className="text-xs font-bold text-yellow-700 uppercase block mb-1">Min Percentage (%)</label>
                              <input id="prize-min-p" type="number" placeholder="e.g. 90" className="w-full p-3 rounded-xl border border-yellow-200 font-bold" />
                          </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                          <div className="col-span-1">
                              <label className="text-xs font-bold text-yellow-700 uppercase block mb-1">Amount (Coins)</label>
                              <input id="prize-amount" type="number" placeholder="10" className="w-full p-3 rounded-xl border border-yellow-200 font-bold" />
                          </div>
                          <div className="col-span-2">
                              <label className="text-xs font-bold text-yellow-700 uppercase block mb-1">Subscription (Tier/Level/Hours)</label>
                              <div className="flex gap-2">
                                  <select id="prize-sub-tier" className="p-3 rounded-xl border border-yellow-200 font-bold bg-white flex-1">
                                      <option value="WEEKLY">Weekly</option>
                                      <option value="MONTHLY">Monthly</option>
                                      <option value="LIFETIME">Lifetime</option>
                                  </select>
                                  <select id="prize-sub-level" className="p-3 rounded-xl border border-yellow-200 font-bold bg-white w-24">
                                      <option value="BASIC">Basic</option>
                                      <option value="ULTRA">Ultra</option>
                                  </select>
                                  <input id="prize-sub-hours" type="number" placeholder="Hrs" className="w-20 p-3 rounded-xl border border-yellow-200 font-bold" />
                              </div>
                          </div>
                      </div>

                      <div>
                          <label className="text-xs font-bold text-yellow-700 uppercase block mb-1">Label / Message</label>
                          <input id="prize-label" type="text" placeholder="e.g. 90% Scorer Reward" className="w-full p-3 rounded-xl border border-yellow-200 font-bold" />
                      </div>

                      <button 
                          onClick={() => {
                              const category = (document.getElementById('prize-category') as HTMLSelectElement).value;
                              const type = (document.getElementById('prize-type') as HTMLSelectElement).value;
                              const minQ = parseInt((document.getElementById('prize-min-q') as HTMLInputElement).value) || 0;
                              const minP = parseInt((document.getElementById('prize-min-p') as HTMLInputElement).value) || 0;
                              const amount = parseInt((document.getElementById('prize-amount') as HTMLInputElement).value) || 0;
                              const subTier = (document.getElementById('prize-sub-tier') as HTMLSelectElement).value;
                              const subLevel = (document.getElementById('prize-sub-level') as HTMLSelectElement).value;
                              const subHours = parseInt((document.getElementById('prize-sub-hours') as HTMLInputElement).value) || 24;
                              const label = (document.getElementById('prize-label') as HTMLInputElement).value;

                              if (!label) { alert("Label is required"); return; }

                              const newRule: any = {
                                  id: `prize-${Date.now()}`,
                                  category,
                                  minQuestions: minQ,
                                  minPercentage: minP,
                                  rewardType: type,
                                  label,
                                  enabled: true
                              };

                              if (type === 'COINS') {
                                  newRule.rewardAmount = amount;
                              } else {
                                  newRule.rewardSubTier = subTier;
                                  newRule.rewardSubLevel = subLevel;
                                  newRule.rewardDurationHours = subHours;
                              }

                              const updatedRules = [...(localSettings.prizeRules || []), newRule];
                              setLocalSettings({...localSettings, prizeRules: updatedRules});
                              // Clear inputs? Maybe later.
                              alert("Rule Added! Click Save Settings to persist.");
                          }}
                          className="w-full bg-yellow-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-yellow-700"
                      >
                          Add Rule
                      </button>
                  </div>
              </div>

              <div className="space-y-3">
                  {localSettings.prizeRules?.map((rule, idx) => (
                      <div key={rule.id} className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                          <div>
                              <div className="flex items-center gap-2 mb-1">
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${rule.category === 'SYLLABUS_MCQ' ? 'bg-blue-100 text-blue-700' : rule.category === 'WEEKLY_TEST' ? 'bg-purple-100 text-purple-700' : 'bg-orange-100 text-orange-700'}`}>{rule.category}</span>
                                  <span className="text-xs font-bold text-slate-500">Min {rule.minQuestions} Qs • Min {rule.minPercentage}%</span>
                              </div>
                              <p className="font-bold text-slate-800">{rule.label}</p>
                              <p className="text-xs text-slate-600">
                                  Reward: {rule.rewardType === 'COINS' ? `${rule.rewardAmount} Coins` : `${rule.rewardSubTier} ${rule.rewardSubLevel} (${rule.rewardDurationHours}h)`}
                              </p>
                          </div>
                          <button onClick={() => {
                              const updated = localSettings.prizeRules!.filter((_, i) => i !== idx);
                              setLocalSettings({...localSettings, prizeRules: updated});
                          }} className="text-red-400 hover:text-red-600 p-2"><Trash2 size={18} /></button>
                      </div>
                  ))}
                  {(!localSettings.prizeRules || localSettings.prizeRules.length === 0) && <p className="text-slate-500 text-center py-4">No prize rules configured.</p>}
              </div>
              
              <button onClick={() => handleSaveSettings()} className="w-full mt-6 bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-green-700">Save Changes</button>
          </div>
      )}

      {/* 3-TIER POPUP CONFIG TAB */}

      {activeTab === 'BULK_UPLOAD' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Daily Bulk Upload</h3>
              </div>
              <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100 mb-6 text-sm text-yellow-800">
                  <strong>Instructions:</strong> Paste your links here. If Firebase is configured, clicking Save will sync for ALL students instantly. No need to redeploy.
              </div>
              
              <SubjectSelector />

              {selSubject && selChapters.length > 0 && (
                  <div className="space-y-4">
                      <div className="flex justify-between items-center bg-slate-100 p-3 rounded-lg font-bold text-slate-600 text-xs uppercase">
                          <div className="w-8">#</div>
                          <div className="flex-1">Chapter</div>
                          <div className="w-1/3">Premium Link (Paid)</div>
                          <div className="w-16">Price</div>
                      </div>
                      
                      {selChapters.map((ch, idx) => {
                          const data = bulkData[ch.id] || { free: '', premium: '', price: 5 };
                          return (
                              <div key={ch.id} className="flex gap-2 items-center">
                                  <div className="w-8 text-center text-xs font-bold text-slate-500">{idx + 1}</div>
                                  <div className="flex-1 text-sm font-bold text-slate-700 truncate">{ch.title}</div>
                                  <div className="w-1/3">
                                      <input 
                                          type="text" 
                                          placeholder="Paste Premium PDF Link..." 
                                          value={data.premium}
                                          onChange={e => setBulkData({...bulkData, [ch.id]: { ...data, premium: e.target.value }})}
                                          className="w-full p-2 border border-purple-200 bg-purple-50 rounded text-xs focus:ring-1 focus:ring-purple-500 outline-none"
                                      />
                                  </div>
                                  <div className="w-16">
                                      <input 
                                          type="number" 
                                          value={data.price}
                                          onChange={e => setBulkData({...bulkData, [ch.id]: { ...data, price: Number(e.target.value) }})}
                                          className="w-full p-2 border border-slate-200 rounded text-xs text-center font-bold"
                                      />
                                  </div>
                              </div>
                          );
                      })}

                      <div className="pt-6 border-t mt-4">
                          <button onClick={() => saveBulkData()} className="w-full py-4 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2">
                              <Save size={20} /> Save All & Sync
                          </button>
                      </div>
                  </div>
              )}
          </div>
      )}


      {/* 2. SYLLABUS MANAGER */}
      {activeTab === 'SYLLABUS_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-indigo-800">Syllabus Manager</h3>
                  <div className="ml-auto flex gap-2">
                      <button onClick={handleCopyFullSyllabus} className="bg-white border border-indigo-200 text-indigo-600 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-50 flex items-center gap-2">
                          <Copy size={14} /> Copy Full Syllabus
                      </button>
                      <button onClick={handleDownloadFullSyllabus} className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-2">
                          <Download size={14} /> Download JSON
                      </button>
                  </div>
              </div>
              <SubjectSelector />
              {selSubject && (
                  <div className="space-y-6">
                      {/* BULK UPLOAD SECTION */}
                      <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 animate-in fade-in">
                          <h4 className="font-bold text-indigo-900 mb-2 flex items-center gap-2">
                               <LayersIcon size={18} /> Bulk Syllabus Upload
                          </h4>
                          <p className="text-xs text-indigo-700 mb-3 leading-relaxed">
                               Paste chapter list (one per line) to <strong className="bg-indigo-100 px-1 rounded">REPLACE</strong> the entire syllabus.
                               <br/>This updates PDF, Video, and MCQ sections automatically.
                          </p>
                          <textarea
                              value={syllabusImportText}
                              onChange={(e) => setSyllabusImportText(e.target.value)}
                              className="w-full h-32 p-3 text-sm border border-indigo-200 rounded-xl focus:ring-2 focus:ring-indigo-500 mb-3 shadow-inner"
                              placeholder={"Chapter 1: Real Numbers\nChapter 2: Polynomials\nChapter 3: Linear Equations..."}
                          />
                          <div className="flex gap-2">
                               <button 
                                   onClick={async () => {
                                        if (!syllabusImportText.trim()) { alert("Paste content first."); return; }
                                        const lines = syllabusImportText.split('\n').map(l => l.trim()).filter(l => l);
                                        const newChapters = lines.map((title, idx) => ({
                                            id: `ch-${Date.now()}-${idx}`,
                                            title: title,
                                            description: `Chapter ${idx + 1}`
                                        }));
                                        setSelChapters(newChapters);
                                        
                                        // Trigger Save
                                        if(confirm(`⚠️ Overwrite Syllabus with ${newChapters.length} chapters?\n\nThis will update the syllabus for ALL students immediately.`)) {
                                            const streamKey = (selClass === '11' || selClass === '12') && selStream ? `-${selStream}` : '';
                                            const baseKey = `${selBoard}-${selClass}${streamKey}-${selSubject.name}`;
                                            
                                            // Save to Cloud
                                            if(isFirebaseConnected) {
                                                await saveCustomSyllabus(`${baseKey}-English`, newChapters);
                                                await saveCustomSyllabus(`${baseKey}-Hindi`, newChapters);
                                            }
                                            
                                            // Save Local
                                            localStorage.setItem(`nst_custom_chapters_${baseKey}-English`, JSON.stringify(newChapters));
                                            localStorage.setItem(`nst_custom_chapters_${baseKey}-Hindi`, JSON.stringify(newChapters));
                                            
                                            alert("✅ Syllabus Overwritten & Saved to Cloud!");
                                            setSyllabusImportText('');
                                        }
                                   }} 
                                   className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold text-xs shadow-lg hover:bg-indigo-700 flex items-center gap-2 transition-transform active:scale-95"
                               >
                                   <Save size={16} /> Replace & Save Syllabus
                               </button>
                               
                               <button 
                                   onClick={async () => {
                                       if(confirm("Reset to Default Static/AI Syllabus? This cannot be undone.")) {
                                            const streamKey = (selClass === '11' || selClass === '12') && selStream ? `-${selStream}` : '';
                                            const baseKey = `${selBoard}-${selClass}${streamKey}-${selSubject.name}`;
                                            
                                            if(isFirebaseConnected) {
                                                await deleteCustomSyllabus(`${baseKey}-English`);
                                                await deleteCustomSyllabus(`${baseKey}-Hindi`);
                                            }
                                            localStorage.removeItem(`nst_custom_chapters_${baseKey}-English`);
                                            localStorage.removeItem(`nst_custom_chapters_${baseKey}-Hindi`);
                                            
                                            const fresh = await fetchChapters(selBoard, selClass, selStream, selSubject, 'English');
                                            setSelChapters(fresh);
                                            alert("✅ Reset Complete!");
                                       }
                                   }}
                                   className="bg-white border border-red-200 text-red-600 px-4 py-2 rounded-lg font-bold text-xs hover:bg-red-50 flex items-center gap-2"
                               >
                                   <RotateCcw size={16} /> Reset to Default
                               </button>
                          </div>
                      </div>

                      <div className="flex justify-between items-center bg-indigo-50 p-3 rounded-lg border border-indigo-100">
                          <h4 className="font-bold text-indigo-900">Manual Edit: {selSubject.name}</h4>
                          <div className="flex gap-2">
                              <button onClick={() => setSelChapters([...selChapters, { id: `manual-${Date.now()}`, title: 'New Chapter' }])} className="px-3 py-1.5 bg-white border border-indigo-200 text-indigo-700 font-bold rounded-lg text-xs">+ Add Chapter</button>
                              <button onClick={() => saveSyllabusList()} className="px-3 py-1.5 bg-indigo-600 text-white font-bold rounded-lg text-xs shadow">Save List</button>
                          </div>
                      </div>
                      <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-2">
                          {selChapters.map((ch, idx) => {
                              const isHidden = (localSettings.hiddenChapters || []).includes(ch.id);
                              return (
                              <div key={ch.id} className={`flex gap-2 items-center bg-slate-50 p-2 rounded-lg border ${isHidden ? 'border-red-200 bg-red-50' : 'border-slate-200'}`}>
                                  <span className="w-6 text-center text-xs font-bold text-slate-500">{idx + 1}</span>
                                  <input
                                      type="text"
                                      value={ch.serialNumber || ''}
                                      placeholder={`L${idx + 1}`}
                                      onChange={(e) => { const up = [...selChapters]; up[idx].serialNumber = e.target.value; setSelChapters(up); }}
                                      className="w-16 p-2 border border-slate-200 rounded text-sm font-medium focus:border-indigo-500 outline-none text-center bg-white"
                                      title="Custom Serial Number"
                                  />
                                  <input 
                                      type="text" 
                                      value={ch.title} 
                                      onChange={(e) => { const up = [...selChapters]; up[idx].title = e.target.value; setSelChapters(up); }}
                                      className={`flex-1 p-2 border border-slate-200 rounded text-sm font-medium focus:border-indigo-500 outline-none ${isHidden ? 'text-red-400 decoration-slate-400' : ''}`}
                                  />
                                  
                                  {/* HIDE TOGGLE */}
                                  <button 
                                      onClick={() => {
                                          const updated = toggleItemInList(localSettings.hiddenChapters, ch.id);
                                          setLocalSettings({...localSettings, hiddenChapters: updated});
                                      }}
                                      className={`p-2 rounded-lg ${isHidden ? 'bg-red-100 text-red-600' : 'text-slate-300 hover:text-slate-600'}`}
                                      title={isHidden ? "Unhide Chapter" : "Hide Chapter"}
                                  >
                                      {isHidden ? <EyeOff size={16} /> : <Eye size={16} />}
                                  </button>

                                  {/* MOVE CHAPTER BUTTON (NEW) */}
                                  <button
                                      onClick={() => {
                                          setMovingChapter({ chapter: ch, index: idx });
                                          setMoveTargetBoard(selBoard);
                                          setMoveTargetClass(selClass);
                                          setMoveTargetStream(selStream || 'Science');
                                          setMoveTargetSubject(selSubject);
                                      }}
                                      className="p-2 text-slate-300 hover:text-indigo-500 rounded-lg transition-colors"
                                      title="Move Chapter"
                                  >
                                      <ArrowRight size={16} />
                                  </button>

                                  {/* MANAGE CONTENT BUTTON (New Feature) */}
                                  <button 
                                      onClick={() => {
                                          loadChapterContent(ch.id);
                                          setActiveTab('CONTENT_PDF'); // Switch to editor view directly
                                      }}
                                      className="px-3 py-1.5 bg-blue-100 text-blue-700 text-[10px] font-bold rounded hover:bg-blue-200 whitespace-nowrap"
                                      title="Edit PDF, Video, MCQ for this Chapter"
                                  >
                                      Edit Content
                                  </button>

                                  {/* VISIBILITY TOGGLE (NEW) */}
                                  <button 
                                      onClick={(e) => {
                                          e.stopPropagation();
                                          const isHidden = (localSettings.hiddenChapters || []).includes(ch.id);
                                          const currentHidden = localSettings.hiddenChapters || [];
                                          const newHidden = isHidden 
                                              ? currentHidden.filter(id => id !== ch.id) 
                                              : [...currentHidden, ch.id];
                                          setLocalSettings({...localSettings, hiddenChapters: newHidden});
                                      }}
                                      className={`p-2 rounded-lg transition-colors ${localSettings.hiddenChapters?.includes(ch.id) ? 'bg-slate-200 text-slate-500' : 'bg-green-100 text-green-600 hover:bg-green-200'}`}
                                      title={localSettings.hiddenChapters?.includes(ch.id) ? "Show Chapter" : "Hide Chapter"}
                                  >
                                      {localSettings.hiddenChapters?.includes(ch.id) ? <EyeOff size={16} /> : <Eye size={16} />}
                                  </button>

                                  {/* LOCK TOGGLE */}
                                  <button 
                                      onClick={() => {
                                          const up = [...selChapters];
                                          // Toggle 'isLocked' property
                                          // @ts-ignore
                                          up[idx].isLocked = !up[idx].isLocked;
                                          setSelChapters(up);
                                      }}
                                      className={`p-2 rounded-lg transition-colors ${
                                          // @ts-ignore
                                          ch.isLocked ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-500 hover:text-slate-600'
                                      }`}
                                      title={
                                          // @ts-ignore
                                          ch.isLocked ? "Unlock Chapter" : "Lock Chapter"
                                      }
                                  >
                                      {/* @ts-ignore */}
                                      {ch.isLocked ? <Lock size={16} /> : <Eye size={16} />}
                                  </button>

                                  <button onClick={() => deleteChapter(idx)} className="p-2 text-slate-300 hover:text-red-500"><Trash2 size={16} /></button>
                              </div>
                          )})}
                      </div>
                  </div>
              )}
          </div>
      )}

      {/* 3. CONTENT MANAGERS (PDF, VIDEO, MCQ, TEST, IMAGE) */}
      {['CONTENT_PDF', 'CONTENT_VIDEO', 'CONTENT_AUDIO', 'CONTENT_MCQ', 'CONTENT_TEST'].includes(activeTab) && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">
                      {activeTab === 'CONTENT_PDF' ? 'PDF Study Material' : activeTab === 'CONTENT_VIDEO' ? 'Video Lectures' : activeTab === 'CONTENT_AUDIO' ? 'Audio Library' : activeTab === 'CONTENT_MCQ' ? 'Practice MCQs' : 'Weekly Tests - Multi-Subject'}
                  </h3>
              </div>
              
              {/* EDITOR TAB NAVIGATION */}
              {activeTab !== 'CONTENT_TEST' && (
                  <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
                      {[
                          {id: 'CONTENT_PDF', label: 'PDF / Notes', icon: FileText},
                          {id: 'CONTENT_VIDEO', label: 'Videos', icon: Video},
                          {id: 'CONTENT_MCQ', label: 'MCQs', icon: CheckCircle},
                          {id: 'CONTENT_AUDIO', label: 'Audio', icon: Headphones},
                      ].map(tab => (
                          <button 
                              key={tab.id}
                              onClick={() => setActiveTab(tab.id as any)}
                              className={`px-4 py-2 rounded-xl flex items-center gap-2 font-bold text-xs whitespace-nowrap transition-all ${
                                  activeTab === tab.id 
                                  ? 'bg-slate-800 text-white shadow-lg scale-105' 
                                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                              }`}
                          >
                              <tab.icon size={16} /> {tab.label}
                          </button>
                      ))}
                  </div>
              )}

              {activeTab !== 'CONTENT_TEST' && <SubjectSelector />}
              
              {/* WEEKLY TEST CREATION UI */}
              {activeTab === 'CONTENT_TEST' && (
                  <div className="space-y-6 bg-gradient-to-br from-orange-50 to-red-50 p-6 rounded-2xl border border-orange-200">
                      {/* Test Metadata */}
                      <div className="space-y-3">
                          <input type="text" placeholder="Test Name" value={testName} onChange={e => setTestName(e.target.value)} className="w-full p-3 border border-orange-200 rounded-xl font-bold text-lg" />
                          <textarea placeholder="Test Description" value={testDesc} onChange={e => setTestDesc(e.target.value)} className="w-full p-3 border border-orange-200 rounded-xl h-20" />
                          <div className="grid grid-cols-3 gap-3">
                              <div>
                                  <label className="text-xs font-bold text-orange-600 uppercase block mb-1">Class</label>
                                  <select value={testClassLevel} onChange={e => setTestClassLevel(e.target.value as ClassLevel)} className="w-full p-2 border border-orange-200 rounded-lg font-bold">
                                      {['6','7','8','9','10','11','12'].map(c => <option key={c} value={c}>Class {c}</option>)}
                                  </select>
                              </div>
                              <div>
                                  <label className="text-xs font-bold text-orange-600 uppercase block mb-1">Duration (mins)</label>
                                  <input type="number" value={testDuration} onChange={e => setTestDuration(Number(e.target.value))} className="w-full p-2 border border-orange-200 rounded-lg font-bold" min="30" max="300" />
                              </div>
                              <div>
                                  <label className="text-xs font-bold text-orange-600 uppercase block mb-1">Pass Score %</label>
                                  <input type="number" value={testPassScore} onChange={e => setTestPassScore(Number(e.target.value))} className="w-full p-2 border border-orange-200 rounded-lg font-bold" min="0" max="100" />
                              </div>
                          </div>
                      </div>

                      {/* Subject & Chapter Selection (Enhanced) */}
                      <div className="border-t border-orange-200 pt-4">
                          <p className="font-bold text-orange-700 mb-3">📚 Select Content (Multi-Subject)</p>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
                              {getSubjectsList(testClassLevel, null, selBoard).map(s => {
                                  const isSel = testSelectedSubjects.includes(s.id);
                                  return (
                                      <div key={s.id} className={`p-2 rounded-lg border flex flex-col ${isSel ? 'bg-orange-50 border-orange-300' : 'bg-white border-slate-200'}`}>
                                          <button onClick={() => setTestSelectedSubjects(isSel ? testSelectedSubjects.filter(x => x !== s.id) : [...testSelectedSubjects, s.id])} className="flex items-center gap-2 font-bold text-xs text-slate-800 w-full mb-1">
                                              <div className={`w-4 h-4 rounded border flex items-center justify-center ${isSel ? 'bg-orange-600 border-orange-600 text-white' : 'bg-white border-slate-300'}`}>
                                                  {isSel && <CheckCircle size={10} />}
                                              </div>
                                              {s.name}
                                          </button>
                                          
                                          {/* Load Chapters Button */}
                                          {isSel && (
                                              <button 
                                                  onClick={async () => {
                                                      const ch = await fetchChapters(localSettings.allowedBoards?.[0] || 'CBSE', testClassLevel, 'Science', s, 'English');
                                                      // This is a simplified way to just "show" chapters for selection. 
                                                      // In a real app, we'd store these chapters in a map keyed by subjectId.
                                                      // For this prototype, we'll prompt the user or use a simple modal (simulated).
                                                      const selectedChs = window.prompt(`Enter Chapter IDs for ${s.name} (comma separated) or leave blank for ALL:\n\nAvailable:\n${ch.map((c,i) => `${i+1}. ${c.title}`).join('\n')}`);
                                                      if (selectedChs) {
                                                          const indexes = selectedChs.split(',').map(x => parseInt(x.trim()) - 1);
                                                          const ids = indexes.map(i => ch[i]?.id).filter(Boolean);
                                                          setTestSelectedChapters(prev => [...prev, ...ids]);
                                                          alert(`Added ${ids.length} chapters from ${s.name}`);
                                                      }
                                                  }}
                                                  className="text-[9px] text-blue-600 underline text-left pl-6"
                                              >
                                                  Select Specific Chapters
                                              </button>
                                          )}
                                      </div>
                                  );
                              })}
                          </div>
                          {testSelectedChapters.length > 0 && <p className="text-xs text-green-600 font-bold mb-2">✅ {testSelectedChapters.length} specific chapters selected across subjects.</p>}
                      </div>

                      {/* Questions Section */}
                      <div className="border-t border-orange-200 pt-4">
                          {/* GOOGLE SHEETS IMPORT FOR WEEKLY TEST */}
                          <div className="bg-gradient-to-r from-orange-50 to-red-50 p-4 rounded-xl border border-orange-200 shadow-sm mb-4">
                              <div className="flex items-center gap-2 mb-3">
                                  <div className="bg-orange-100 p-2 rounded text-orange-700">
                                      <Database size={18} />
                                  </div>
                                  <div>
                                      <h4 className="font-bold text-slate-800 text-sm">Bulk Import Questions (Google Sheets)</h4>
                                      <p className="text-[10px] text-slate-600">Copy cells from Excel/Sheets and paste below</p>
                                  </div>
                              </div>

                              <div className="bg-white/50 p-2 rounded-lg text-[10px] text-slate-600 mb-2 border border-orange-100 font-mono">
                                  <strong>Supported Formats:</strong><br/>
                                  1. Copy from Excel (7 Columns): Q | Opt A | Opt B | Opt C | Opt D | Ans(1-4) | Exp<br/>
                                  2. Vertical List: Q \n 4 Options \n Answer \n Explanation (Multi-line). <br/>
                                  *Note: Numbered (Q1.) or Unnumbered questions supported (if 4 options + Answer line provided).
                              </div>

                              <textarea 
                                  value={importText} 
                                  onChange={e => setImportText(e.target.value)}
                                  placeholder={`Example:
What is 2+2?    3       4       5       6       2       The answer is 4
Capital of India?       Mumbai  Delhi   Kolkata Chennai 2       Delhi is the capital`}
                                  className="w-full h-24 p-2 border border-orange-200 rounded-lg text-xs font-mono focus:ring-2 focus:ring-orange-500 outline-none mb-2"
                              />
                              
                              <div className="flex gap-2">
                                  <button 
                                      onClick={() => setImportText('')} 
                                      className="flex-1 bg-white border border-orange-200 text-slate-600 py-2 rounded-lg font-bold text-xs hover:bg-orange-50"
                                  >
                                      Clear
                                  </button>
                                  <button 
                                      onClick={() => handleGoogleSheetImport(true)} 
                                      className="flex-[2] bg-orange-600 hover:bg-orange-700 text-white py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-2 shadow"
                                  >
                                      <Upload size={14} /> Import to Test
                                  </button>
                              </div>
                          </div>

                          <div className="flex justify-between items-center mb-3">
                              <p className="font-bold text-orange-700">📝 Questions ({editingTestMcqs.length})</p>
                              <button onClick={() => addMcq(true)} className="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-700">+ Add Question</button>
                          </div>
                          <div className="space-y-3 max-h-[40vh] overflow-y-auto bg-white p-3 rounded-lg border border-orange-200">
                              {editingTestMcqs.map((q, idx) => (
                                  <div key={idx} className="p-3 bg-orange-50 border border-orange-100 rounded-lg">
                                      <div className="flex justify-between items-start mb-2">
                                          <span className="font-bold text-orange-700">Q{idx+1}</span>
                                          <button onClick={() => removeMcq(true, idx)} className="text-red-500 hover:text-red-700"><Trash2 size={14} /></button>
                                      </div>
                                      <p className="text-sm font-medium text-slate-700 truncate">{q.question}</p>
                                      <p className="text-xs text-slate-600 mt-1">A) {q.options[q.correctAnswer]}</p>
                                  </div>
                              ))}
                          </div>
                      </div>

                      {/* Save Button */}
                      <button onClick={() => handleSaveWeeklyTest()} className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white font-black py-4 rounded-xl shadow-lg hover:shadow-xl text-lg">
                          ✅ Create Weekly Test ({editingTestMcqs.length} Questions)
                      </button>

                      {/* Existing Tests */}
                      {localSettings.weeklyTests && localSettings.weeklyTests.length > 0 && (
                          <div className="border-t border-orange-200 pt-4">
                              <p className="font-bold text-orange-700 mb-3">✅ Active Tests</p>
                              <div className="space-y-2 max-h-[30vh] overflow-y-auto">
                                  {localSettings.weeklyTests.map(t => (
                                      <div key={t.id} className="bg-white p-3 rounded-lg border border-green-200 flex justify-between items-center">
                                          <div>
                                              <p className="font-bold text-slate-800">{t.name}</p>
                                              <p className="text-xs text-slate-600">Class {t.classLevel} • {t.totalQuestions} Qs • {t.durationMinutes}min</p>
                                          </div>
                                          <button onClick={() => {const updated = localSettings.weeklyTests!.filter(x => x.id !== t.id); setLocalSettings({...localSettings, weeklyTests: updated});}} className="text-red-500 hover:text-red-700"><Trash2 size={16} /></button>
                                      </div>
                                  ))}
                              </div>
                              <div className="sticky bottom-0 left-0 w-full p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-50 mt-4 md:static md:bg-transparent md:border-t-0 md:p-0 rounded-b-2xl md:rounded-none shadow-[0_-8px_15px_-3px_rgba(0,0,0,0.1)] md:shadow-none">
                                  <button onClick={() => saveChapterContent()} className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow hover:bg-blue-700 border-2 border-white">Save All MCQs</button>
                              </div>
                          </div>
                      )}
                  </div>
              )}

              {/* LIST VIEW (for PDF/VIDEO/MCQ/IMAGE) */}
              {selSubject && !editingChapterId && activeTab !== 'CONTENT_TEST' && (
                  <div className="grid gap-2 max-h-[60vh] overflow-y-auto">
                      {selChapters.map((ch) => (
                          <div key={ch.id} className="flex justify-between items-center bg-slate-50 p-3 rounded-xl border border-slate-200">
                              <span className="font-bold text-slate-700 text-sm">{ch.title}</span>
                              <button onClick={() => loadChapterContent(ch.id)} className="px-4 py-2 bg-blue-100 text-blue-700 font-bold rounded-lg text-xs hover:bg-blue-200">
                                      Manage All Content
                              </button>
                          </div>
                      ))}
                  </div>
              )}

              {/* EDITOR VIEW (for PDF/VIDEO/MCQ) */}
              {editingChapterId && activeTab !== 'CONTENT_TEST' && (
                  <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 animate-in slide-in-from-right">
                      <div className="flex justify-between items-center mb-4 border-b border-slate-200 pb-4">
                          <div>
                              <h4 className="font-black text-slate-800 text-lg">{selChapters.find(c => c.id === editingChapterId)?.title}</h4>
                              <p className="text-xs text-slate-600">Editing Content</p>
                          </div>
                          <button onClick={() => setEditingChapterId(null)} className="text-xs font-bold text-slate-500 hover:text-slate-600">Close Editor</button>
                      </div>
                      
                      {isContentLoading ? (
                          <div className="flex items-center justify-center h-40">
                              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-800"></div>
                          </div>
                      ) : (
                      <>
                          <div className="mb-4 flex gap-2 overflow-x-auto pb-2 border-b border-slate-200">
                             {/* TAB SWITCHER WITHIN EDITOR */}
                             {['CONTENT_PDF', 'CONTENT_VIDEO', 'CONTENT_MCQ', 'CONTENT_AUDIO'].map(tab => (
                                 <button
                                     key={tab}
                                     onClick={() => setActiveTab(tab as any)}
                                     className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${activeTab === tab ? 'bg-slate-800 text-white' : 'bg-white text-slate-600 border border-slate-200'}`}
                                 >
                                     {tab === 'CONTENT_PDF' ? 'PDF' : tab === 'CONTENT_VIDEO' ? 'Videos' : tab === 'CONTENT_MCQ' ? 'MCQ' : 'Audio'}
                                 </button>
                             ))}
                          </div>

                          {/* SYLLABUS MODE TOGGLE - GLOBAL FOR CONTENT EDITOR */}
                          <div className="flex gap-2 mb-6 p-1 bg-slate-100 rounded-2xl w-fit border border-slate-200 shadow-inner">
                                <button 
                                    onClick={() => handleModeSwitch('SCHOOL')}
                                    className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${syllabusMode === 'SCHOOL' ? 'bg-white text-blue-600 shadow-md scale-105' : 'text-slate-600 hover:text-slate-700'}`}
                                >
                                    School Mode
                                </button>
                                <button 
                                    onClick={() => handleModeSwitch('COMPETITION')}
                                    className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${syllabusMode === 'COMPETITION' ? 'bg-white text-purple-600 shadow-md scale-105' : 'text-slate-600 hover:text-slate-700'}`}
                                >
                                    Competition Mode
                                </button>
                          </div>

                      {/* PDF & AI NOTES EDITOR */}
                      {activeTab === 'CONTENT_PDF' && (
                          <div className="space-y-6">
                              {/* NOTE TYPES NAVIGATION TABS */}
                              <div className="flex gap-2 overflow-x-auto pb-2 mb-2 border-b border-slate-200">
                                  {[
                                      {id: 'PREMIUM', label: 'Retention Notes (Premium)', icon: FileText},
                                      {id: 'DEEP_DIVE', label: 'Concept Notes (Deep Dive)', icon: Layers},
                                      {id: 'ADDITIONAL', label: 'Extended Notes (Resources)', icon: FileText},
                                      {id: 'TEACHER', label: "Teacher's Guide", icon: GraduationCap}
                                  ].map(tab => (
                                      <button
                                          key={tab.id}
                                          onClick={() => setActiveNoteTab(tab.id as any)}
                                          className={`px-3 py-2 rounded-xl flex items-center gap-2 font-bold text-xs whitespace-nowrap transition-all ${
                                              activeNoteTab === tab.id
                                              ? 'bg-slate-800 text-white shadow scale-105'
                                              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                                          }`}
                                      >
                                          <tab.icon size={14} /> {tab.label}
                                      </button>
                                  ))}
                              </div>

                              {activeNoteTab === 'PREMIUM' && (
                                  <>
                              {/* UNLIMITED PREMIUM NOTES MANAGER */}
                              <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100 mt-4">
                                  <h4 className="font-bold text-yellow-900 mb-4 flex items-center gap-2">
                                      <FileText size={20} /> Additional Premium Notes ({syllabusMode})
                                  </h4>

                                  <div className="space-y-3 mb-4">
                                      {premiumNotesList.map((note, idx) => (
                                          <div key={idx} className="bg-white p-3 rounded-lg border border-yellow-100 shadow-sm flex flex-col gap-2">
                                              <div className="flex gap-2 items-center">
                                                  <span className="w-6 text-center text-xs font-bold text-yellow-600">{idx + 1}</span>
                                                  <input
                                                      type="text"
                                                      value={note.title}
                                                      onChange={e => {
                                                          const updated = [...premiumNotesList];
                                                          updated[idx].title = e.target.value;
                                                          setPremiumNotesList(updated);
                                                      }}
                                                      placeholder="Note Title (e.g. Part 1)"
                                                      className="flex-1 p-2 border rounded text-xs font-bold"
                                                  />
                                                  <button onClick={() => {
                                                      // Preserve some basic linebreaks
                                                      let html = note.content || '';
                                                      html = html.replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n\n').replace(/<\/div>/gi, '\n');
                                                      const text = new DOMParser().parseFromString(html, 'text/html').body.textContent || '';
                                                      navigator.clipboard.writeText(text.trim());
                                                      alert("Note content copied!");
                                                  }} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded" title="Copy Content">
                                                      <Copy size={16} />
                                                  </button>
                                                  <button onClick={() => setPremiumNotesList(prev => prev.filter((_, i) => i !== idx))} className="text-red-400 hover:text-red-600 p-2">
                                                      <Trash2 size={16} />
                                                  </button>
                                              </div>

                                              <input
                                                  type="text"
                                                  value={note.url || ''}
                                                  onChange={e => {
                                                      const updated = [...premiumNotesList];
                                                      updated[idx].url = e.target.value;
                                                      setPremiumNotesList(updated);
                                                  }}
                                                  placeholder="PDF URL (Optional)..."
                                                  className="w-full p-2 border rounded text-xs text-blue-600"
                                              />

                                              <textarea
                                                  value={note.content || ''}
                                                  onChange={e => {
                                                      const updated = [...premiumNotesList];
                                                      updated[idx].content = e.target.value;
                                                      setPremiumNotesList(updated);
                                                  }}
                                                  className="w-full p-2 border rounded text-xs h-20 font-mono mt-1"
                                                  placeholder="HTML Content for TTS (Optional)..."
                                              />
                                              {/* QUICK REVISION INJECTOR (Helper Button) */}
                                              <div className="flex justify-end mt-1">
                                                  <button
                                                      onClick={() => {
                                                          const updated = [...premiumNotesList];
                                                          const qrTemplate = `\n<div class='recap'><b>🔁 Recap</b><br>Your quick revision point here...</div>\n`;
                                                          updated[idx].content = (updated[idx].content || '') + qrTemplate;
                                                          setPremiumNotesList(updated);
                                                      }}
                                                      className="text-[10px] font-bold text-yellow-600 bg-yellow-50 px-2 py-1 rounded hover:bg-yellow-100 transition-colors flex items-center gap-1 border border-yellow-200"
                                                      title="Append Quick Revision Template"
                                                  >
                                                      <Zap size={12} /> Add Quick Revision
                                                  </button>
                                              </div>
                                          </div>
                                      ))}
                                  </div>

                                  <button
                                      onClick={() => setPremiumNotesList([...premiumNotesList, {title: '', url: '', type: 'PDF', content: '', audioUrl: ''}])}
                                      className="w-full py-2 bg-white border border-yellow-300 text-yellow-600 font-bold rounded-lg hover:bg-yellow-50 border-dashed"
                                  >
                                      + Add Premium Note
                                  </button>
                              </div>

                              </>
                              )}

                              {activeNoteTab === 'DEEP_DIVE' && (
                                  <>
                              {/* UNLIMITED DEEP DIVE MANAGER (TOPICS BREAKDOWN) */}
                              <div className="bg-purple-50 p-4 rounded-xl border border-purple-100">
                                  <h4 className="font-bold text-purple-900 mb-4 flex items-center gap-2">
                                      <Layers size={20} /> Topics Breakdown (Deep Dive)
                                  </h4>
                                  <p className="text-[10px] text-purple-600 mb-4">
                                      Add multiple entries for <b>Topics Breakdown</b>. Each entry represents a specific topic or part.
                                      <br/>• <b>Title:</b> Displayed as the topic name.
                                      <br/>• <b>HTML:</b> Used for Deep Dive content, TTS, and Quick Revision extraction.
                                      <br/>• <b>PDF:</b> Visual document for this topic (Premium view).
                                  </p>

                                  <div className="space-y-4 mb-4">
                                      {deepDiveEntries.map((entry, idx) => (
                                          <div key={idx} className="bg-white p-4 rounded-xl border border-purple-100 shadow-sm space-y-3 relative group">
                                              <div className="absolute top-2 right-2 flex gap-1">
                                                  <button onClick={() => {
                                                      let html = entry.htmlContent || '';
                                                      html = html.replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n\n').replace(/<\/div>/gi, '\n');
                                                      const text = new DOMParser().parseFromString(html, 'text/html').body.textContent || '';
                                                      navigator.clipboard.writeText(text.trim());
                                                      alert("Note content copied!");
                                                  }} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded" title="Copy Content">
                                                      <Copy size={16} />
                                                  </button>
                                                  <button onClick={() => setDeepDiveEntries(prev => prev.filter((_, i) => i !== idx))} className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded">
                                                      <Trash2 size={16} />
                                                  </button>
                                              </div>

                                              <span className="text-xs font-bold text-purple-400 uppercase">Topic {idx + 1}</span>

                                              {/* TITLE INPUT */}
                                              <div className="flex items-center bg-slate-50 border border-purple-100 rounded-lg overflow-hidden">
                                                  <div className="px-3 py-2 text-slate-500 font-bold text-xs">Title</div>
                                                  <input
                                                      type="text"
                                                      value={entry.title || ''}
                                                      onChange={e => {
                                                          const updated = [...deepDiveEntries];
                                                          updated[idx].title = e.target.value;
                                                          setDeepDiveEntries(updated);
                                                      }}
                                                      placeholder="e.g. Introduction to Physics"
                                                      className="flex-1 bg-transparent p-2 text-xs font-bold outline-none text-slate-800"
                                                  />
                                              </div>

                                              {/* PDF LINK */}
                                              <div className="flex items-center bg-slate-50 border border-purple-100 rounded-lg overflow-hidden">
                                                  <div className="px-3 py-2 text-slate-500"><Link size={14} /></div>
                                                  <input
                                                      type="text"
                                                      value={entry.pdfLink}
                                                      onChange={e => {
                                                          const updated = [...deepDiveEntries];
                                                          updated[idx].pdfLink = e.target.value;
                                                          setDeepDiveEntries(updated);
                                                      }}
                                                      placeholder="Google Drive PDF Link..."
                                                      className="flex-1 bg-transparent p-2 text-xs font-bold outline-none text-blue-600"
                                                  />
                                              </div>

                                              {/* HTML CONTENT */}
                                              <textarea
                                                  value={entry.htmlContent}
                                                  onChange={e => {
                                                      const updated = [...deepDiveEntries];
                                                      updated[idx].htmlContent = e.target.value;
                                                      setDeepDiveEntries(updated);
                                                  }}
                                                  className="w-full p-3 border border-purple-100 rounded-lg text-xs font-mono h-32 focus:ring-1 focus:ring-purple-300 outline-none"
                                                  placeholder="<h1>Topic Content</h1><p>Detailed explanation...</p><p>Quick Revision: Key point...</p>"
                                              />
                                              {/* QUICK REVISION INJECTOR (Helper Button) */}
                                              <div className="flex justify-end mt-1">
                                                  <button
                                                      onClick={() => {
                                                          const updated = [...deepDiveEntries];
                                                          const qrTemplate = `\n<div class='recap'><b>🔁 Recap</b><br>Your quick revision point here...</div>\n`;
                                                          updated[idx].htmlContent = (updated[idx].htmlContent || '') + qrTemplate;
                                                          setDeepDiveEntries(updated);
                                                      }}
                                                      className="text-[10px] font-bold text-yellow-600 bg-yellow-50 px-2 py-1 rounded hover:bg-yellow-100 transition-colors flex items-center gap-1 border border-yellow-200"
                                                      title="Append Quick Revision Template"
                                                  >
                                                      <Zap size={12} /> Add Quick Revision
                                                  </button>
                                              </div>
                                          </div>
                                      ))}
                                  </div>

                                  <button
                                      onClick={() => setDeepDiveEntries([...deepDiveEntries, { id: Date.now().toString(), title: '', htmlContent: '', pdfLink: '', audioUrl: '' }])}
                                      className="w-full py-3 bg-white border border-purple-300 text-purple-600 font-bold rounded-xl hover:bg-purple-50 border-dashed flex items-center justify-center gap-2"
                                  >
                                      <Plus size={16} /> Add Topic Breakdown
                                  </button>
                              </div>

                              </>
                              )}

                              {activeNoteTab === 'ADDITIONAL' && (
                                  <>
                              {/* ADDITIONAL NOTES MANAGER */}
                              <div className="bg-cyan-50 p-4 rounded-xl border border-cyan-100 mt-4">
                                  <h4 className="font-bold text-cyan-900 mb-4 flex items-center gap-2">
                                      <FileText size={20} /> Additional Notes (Unlimited)
                                  </h4>
                                  <p className="text-[10px] text-cyan-600 mb-4">
                                      Extra resources. Can be PDF Only, HTML Only, or Both (Premium style).
                                  </p>

                                  <div className="space-y-4 mb-4">
                                      {additionalNotes.map((note, idx) => (
                                          <div key={idx} className="bg-white p-4 rounded-xl border border-cyan-100 shadow-sm space-y-3 relative">
                                              <div className="absolute top-2 right-2 flex gap-1">
                                                  <button onClick={() => {
                                                      let html = note.noteContent || '';
                                                      html = html.replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n\n').replace(/<\/div>/gi, '\n');
                                                      const text = new DOMParser().parseFromString(html, 'text/html').body.textContent || '';
                                                      navigator.clipboard.writeText(text.trim());
                                                      alert("Note content copied!");
                                                  }} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded" title="Copy Content">
                                                      <Copy size={16} />
                                                  </button>
                                                  <button onClick={() => setAdditionalNotes(prev => prev.filter((_, i) => i !== idx))} className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded">
                                                      <Trash2 size={16} />
                                                  </button>
                                              </div>

                                              <div className="flex gap-2">
                                                  <input
                                                      type="text"
                                                      value={note.title}
                                                      onChange={e => {
                                                          const updated = [...additionalNotes];
                                                          updated[idx].title = e.target.value;
                                                          setAdditionalNotes(updated);
                                                      }}
                                                      placeholder="Note Title (e.g. Extra Questions)"
                                                      className="flex-1 p-2 border border-cyan-100 rounded-lg text-xs font-bold outline-none focus:border-cyan-400"
                                                  />
                                              </div>

                                              {/* PDF LINK */}
                                              <input
                                                  type="text"
                                                  value={note.pdfLink}
                                                  onChange={e => {
                                                      const updated = [...additionalNotes];
                                                      updated[idx].pdfLink = e.target.value;
                                                      setAdditionalNotes(updated);
                                                  }}
                                                  placeholder="PDF Link (Optional)..."
                                                  className="w-full p-2 border border-cyan-100 rounded-lg text-xs text-blue-600 outline-none"
                                              />

                                              {/* HTML CONTENT */}
                                              <textarea
                                                  value={note.noteContent}
                                                  onChange={e => {
                                                      const updated = [...additionalNotes];
                                                      updated[idx].noteContent = e.target.value;
                                                      setAdditionalNotes(updated);
                                                  }}
                                                  className="w-full p-2 border border-cyan-100 rounded-lg text-xs font-mono h-20 outline-none"
                                                  placeholder="HTML Content (Optional)..."
                                              />
                                              {/* QUICK REVISION INJECTOR (Helper Button) */}
                                              <div className="flex justify-end mt-1">
                                                  <button
                                                      onClick={() => {
                                                          const updated = [...additionalNotes];
                                                          const qrTemplate = `\n<div class='recap'><b>🔁 Recap</b><br>Your quick revision point here...</div>\n`;
                                                          updated[idx].noteContent = (updated[idx].noteContent || '') + qrTemplate;
                                                          setAdditionalNotes(updated);
                                                      }}
                                                      className="text-[10px] font-bold text-yellow-600 bg-yellow-50 px-2 py-1 rounded hover:bg-yellow-100 transition-colors flex items-center gap-1 border border-yellow-200"
                                                      title="Append Quick Revision Template"
                                                  >
                                                      <Zap size={12} /> Add Quick Revision
                                                  </button>
                                              </div>
                                          </div>
                                      ))}
                                  </div>

                                  <button
                                      onClick={() => setAdditionalNotes([...additionalNotes, { id: Date.now().toString(), title: '', noteContent: '', pdfLink: '', audioUrl: '' }])}
                                      className="w-full py-3 bg-white border border-cyan-300 text-cyan-600 font-bold rounded-xl hover:bg-cyan-50 border-dashed flex items-center justify-center gap-2"
                                  >
                                      <Plus size={16} /> Add Additional Note
                                  </button>
                              </div>

                              </>
                              )}

                              {activeNoteTab === 'TEACHER' && (
                                  <>
                              {/* TEACHING STRATEGY EDITOR */}
                              <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 mt-4">
                                  <h4 className="font-bold text-emerald-900 mb-4 flex items-center gap-2">
                                      <GraduationCap size={20} /> Teaching Strategy (Teacher Mode)
                                  </h4>

                                  <div className="space-y-4 mb-4">
                                      {teachingStrategyNotes.map((note, idx) => (
                                          <div key={note.id} className="bg-white p-3 rounded-lg border border-emerald-200 shadow-sm relative group">
                                              <div className="absolute -top-2 -right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                                                  <button onClick={() => {
                                                      let html = note.content || '';
                                                      html = html.replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n\n').replace(/<\/div>/gi, '\n');
                                                      const text = new DOMParser().parseFromString(html, 'text/html').body.textContent || '';
                                                      navigator.clipboard.writeText(text.trim());
                                                      alert("Note content copied!");
                                                  }} className="bg-blue-100 text-blue-600 p-1.5 rounded-full" title="Copy Content">
                                                      <Copy size={12} />
                                                  </button>
                                                  <button onClick={() => setTeachingStrategyNotes(teachingStrategyNotes.filter((_, i) => i !== idx))} className="bg-red-100 text-red-600 p-1.5 rounded-full">
                                                      <Trash2 size={12} />
                                                  </button>
                                              </div>
                                              <input
                                                  type="text"
                                                  value={note.title}
                                                  onChange={e => {
                                                      const updated = [...teachingStrategyNotes];
                                                      updated[idx].title = e.target.value;
                                                      setTeachingStrategyNotes(updated);
                                                  }}
                                                  className="w-full bg-slate-50 border border-emerald-100 rounded p-2 text-sm font-bold mb-2 outline-none focus:border-emerald-500"
                                                  placeholder="Note Title (e.g. Topic Core, Teaching Method)"
                                              />
                                              <input
                                                  type="text"
                                                  value={note.audioUrl || ''}
                                                  onChange={e => {
                                                      const updated = [...teachingStrategyNotes];
                                                      updated[idx].audioUrl = e.target.value;
                                                      setTeachingStrategyNotes(updated);
                                                  }}
                                                  className="w-full bg-slate-50 border border-emerald-100 rounded p-2 text-xs text-emerald-600 mb-2 outline-none focus:border-emerald-500"
                                                  placeholder="Google Drive Audio Link (Optional)"
                                              />
                                              <textarea
                                                  value={note.content}
                                                  onChange={e => {
                                                      const updated = [...teachingStrategyNotes];
                                                      updated[idx].content = e.target.value;
                                                      setTeachingStrategyNotes(updated);
                                                  }}
                                                  className="w-full p-2 border border-emerald-100 rounded bg-slate-50 text-xs font-mono h-32 outline-none focus:border-emerald-500"
                                                  placeholder="<div class='teacher-section'>\n  <p>Explanation here...</p>\n</div>"
                                              />
                                              {/* QUICK REVISION INJECTOR (Helper Button) */}
                                              <div className="flex justify-end mt-1">
                                                  <button
                                                      onClick={() => {
                                                          const updated = [...teachingStrategyNotes];
                                                          const qrTemplate = `\n<div class='recap'><b>🔁 Recap</b><br>Your quick revision point here...</div>\n`;
                                                          updated[idx].content = (updated[idx].content || '') + qrTemplate;
                                                          setTeachingStrategyNotes(updated);
                                                      }}
                                                      className="text-[10px] font-bold text-yellow-600 bg-yellow-50 px-2 py-1 rounded hover:bg-yellow-100 transition-colors flex items-center gap-1 border border-yellow-200"
                                                      title="Append Quick Revision Template"
                                                  >
                                                      <Zap size={12} /> Add Quick Revision
                                                  </button>
                                              </div>
                                          </div>
                                      ))}
                                      <button
                                          onClick={() => setTeachingStrategyNotes([...teachingStrategyNotes, { id: Date.now().toString(), title: `Strategy ${teachingStrategyNotes.length + 1}`, content: '', type: 'HTML', audioUrl: '' }])}
                                          className="w-full py-2 bg-emerald-100 text-emerald-700 rounded-lg text-sm font-bold border border-emerald-200 border-dashed hover:bg-emerald-200 transition-colors"
                                      >
                                          + Add Strategy Note
                                      </button>
                                  </div>

                                  <div className="pt-4 border-t border-emerald-200">
                                      <p className="text-[10px] text-emerald-600 mb-2 font-bold uppercase">
                                          Legacy Single-Note View
                                      </p>
                                      <textarea
                                          value={teachingStrategyHtml}
                                          onChange={e => setTeachingStrategyHtml(e.target.value)}
                                          className="w-full p-4 border border-emerald-200 rounded-lg text-xs font-mono h-32 outline-none focus:border-emerald-500"
                                          placeholder="<div class='teacher-section'>\n  <h2>🎓 Topic Core</h2>\n  <p>Explanation here...</p>\n</div>"
                                      />
                                  </div>
                              </div>

                              </>
                              )}

                              <div className="flex gap-2">
                                  <label className="flex items-center gap-2 cursor-pointer bg-white px-3 py-3 rounded-xl border border-blue-200">
                                      <input 
                                          type="checkbox" 
                                          checked={editConfig.isNotesHidden || false} 
                                          onChange={e => setEditConfig({...editConfig, isNotesHidden: e.target.checked})}
                                          className="accent-red-600 w-4 h-4"
                                      />
                                      <span className="text-xs font-bold text-slate-600">Hide Notes</span>
                                  </label>
                                  <button onClick={() => generateDirectCode('NOTES', editingChapterId!)} className="px-4 bg-yellow-400 text-black font-bold py-3 rounded-xl shadow hover:bg-yellow-500 flex items-center justify-center gap-2">
                                      <Key size={16} /> Code
                                  </button>
                              </div>
                              <div className="sticky bottom-0 left-0 w-full p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-50 mt-4 md:static md:bg-transparent md:border-t-0 md:p-0 rounded-b-2xl md:rounded-none shadow-[0_-8px_15px_-3px_rgba(0,0,0,0.1)] md:shadow-none">
                                  <button onClick={() => saveChapterContent()} className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow hover:bg-blue-700 border-2 border-white">Save PDF Links</button>
                              </div>
                          </div>
                      )}

                      {/* VIDEO EDITOR (Dynamic List up to 100) */}
                      {activeTab === 'CONTENT_VIDEO' && (
                          <div className="space-y-6">
                              {/* NEW: TOPIC VIDEO MANAGER */}
                              <div className="bg-purple-50 p-4 rounded-xl border border-purple-200">
                                  <h4 className="font-bold text-purple-900 mb-4 flex items-center gap-2">
                                      <Video size={20} /> Topic Video Manager (New)
                                  </h4>

                                  <div className="space-y-3 mb-4">
                                      {topicVideos.map((vid, idx) => (
                                          <div key={idx} className="flex flex-wrap gap-2 items-center bg-white p-3 rounded-lg border border-purple-100 shadow-sm">
                                              <span className="text-xs font-bold text-slate-500 w-6">{idx + 1}</span>
                                              <input
                                                  type="text"
                                                  placeholder="Topic Name"
                                                  value={vid.topic}
                                                  onChange={e => {
                                                      const updated = [...topicVideos];
                                                      updated[idx].topic = e.target.value;
                                                      updated[idx].title = e.target.value;
                                                      setTopicVideos(updated);
                                                  }}
                                                  className="flex-1 p-2 border rounded text-xs font-bold"
                                              />
                                              <input
                                                  type="text"
                                                  placeholder="YouTube URL"
                                                  value={vid.url}
                                                  onChange={e => {
                                                      const updated = [...topicVideos];
                                                      updated[idx].url = e.target.value;
                                                      setTopicVideos(updated);
                                                  }}
                                                  className="flex-1 p-2 border rounded text-xs text-blue-600"
                                              />
                                              <select
                                                  value={vid.isPremium ? 'PREMIUM' : 'FREE'}
                                                  onChange={e => {
                                                      const updated = [...topicVideos];
                                                      updated[idx].isPremium = e.target.value === 'PREMIUM';
                                                      setTopicVideos(updated);
                                                  }}
                                                  className={`p-2 rounded text-xs font-bold border ${vid.isPremium ? 'bg-yellow-100 text-yellow-700 border-yellow-200' : 'bg-green-100 text-green-700 border-green-200'}`}
                                              >
                                                  <option value="FREE">Free</option>
                                                  <option value="PREMIUM">Premium</option>
                                              </select>

                                              <button
                                                  onClick={() => generateDirectCode('VIDEO', vid.id || `${editingChapterId}_pvideo_${idx}`)}
                                                  className="p-2 bg-yellow-100 text-yellow-600 rounded hover:bg-yellow-200"
                                                  title="Generate Unlock Code"
                                              >
                                                  <Key size={16} />
                                              </button>

                                              <button onClick={() => setTopicVideos(prev => prev.filter((_, i) => i !== idx))} className="text-red-400 hover:text-red-600 p-2">
                                                  <Trash2 size={16} />
                                              </button>
                                          </div>
                                      ))}
                                  </div>

                                  <button
                                      onClick={() => setTopicVideos([...topicVideos, { id: Date.now().toString(), title: '', topic: '', url: '', isPremium: false }])}
                                      className="w-full py-2 bg-white border border-purple-300 text-purple-600 font-bold rounded-lg hover:bg-purple-50 border-dashed"
                                  >
                                      + Add Topic Video
                                  </button>

                                  <div className="sticky bottom-0 left-0 w-full p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-50 mt-4 md:static md:bg-transparent md:border-t-0 md:p-0 rounded-b-2xl md:rounded-none shadow-[0_-8px_15px_-3px_rgba(0,0,0,0.1)] md:shadow-none">
                                      <button onClick={saveChapterContent} className="w-full mt-2 bg-purple-600 text-white font-bold py-3 rounded-xl shadow hover:bg-purple-700 transition flex items-center justify-center gap-2 border-2 border-white">
                                          <Save size={18} /> Save Topic Videos
                                      </button>
                                  </div>
                              </div>

                              {/* PREMIUM SERIES MANAGER */}
                              <div className="bg-yellow-50 p-6 rounded-xl border border-yellow-200">
                                  <div className="flex items-center gap-2 mb-3">
                                      <Crown size={20} className="text-yellow-600" />
                                      <h4 className="font-bold text-yellow-900">Premium Video Series (Google Drive)</h4>
                                  </div>

                                  <p className="text-xs text-yellow-800 mb-4 bg-white p-2 rounded border border-yellow-100">
                                      Add exclusive Premium Google Drive links here. These will appear in a special "Premium Series" section for Ultra users.
                                  </p>

                                  <div className="space-y-3 mb-4">
                                      {premiumVideoPlaylist.map((vid, i) => (
                                          <div key={i} className="flex flex-col gap-2 bg-white p-3 rounded-lg border border-yellow-100 shadow-sm">
                                              <div className="flex flex-wrap gap-2 items-center">
                                                  <span className="w-8 text-center text-xs font-bold text-yellow-500 bg-yellow-50 rounded py-2">{i + 1}</span>

                                                  <input
                                                      type="text"
                                                      value={vid.title || ''}
                                                      onChange={(e) => {
                                                          const updated = [...premiumVideoPlaylist];
                                                          updated[i] = {...updated[i], title: e.target.value};
                                                          setPremiumVideoPlaylist(updated);
                                                      }}
                                                      placeholder="Episode Title"
                                                      className="flex-1 min-w-[150px] p-2 border border-slate-200 rounded text-xs font-bold focus:border-yellow-400 focus:ring-1 focus:ring-yellow-200"
                                                  />

                                                  <button
                                                      onClick={() => generateDirectCode('VIDEO', `${editingChapterId}_prem_${i}`)}
                                                      className="p-2 bg-yellow-100 text-yellow-600 rounded hover:bg-yellow-200"
                                                      title="Generate Unlock Code"
                                                  >
                                                      <Key size={16} />
                                                  </button>

                                                  <button
                                                      onClick={() => {
                                                          const updated = premiumVideoPlaylist.filter((_, idx) => idx !== i);
                                                          setPremiumVideoPlaylist(updated);
                                                      }}
                                                      className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                                                  >
                                                      <Trash2 size={16} />
                                                  </button>
                                              </div>

                                              <input
                                                  type="text"
                                                  value={vid.url || ''}
                                                  onChange={(e) => {
                                                      const updated = [...premiumVideoPlaylist];
                                                      updated[i] = {...updated[i], url: e.target.value};
                                                      setPremiumVideoPlaylist(updated);
                                                  }}
                                                  placeholder="Google Drive Link (e.g. drive.google.com/file/...)"
                                                  className="w-full p-2 border border-slate-200 rounded text-xs font-mono text-blue-600 bg-slate-50 focus:bg-white transition-colors"
                                              />
                                          </div>
                                      ))}
                                  </div>

                                  <div className="flex gap-2">
                                      <button
                                          onClick={() => setPremiumVideoPlaylist([...premiumVideoPlaylist, {title: '', url: '', price: 10, access: 'ULTRA'}])}
                                          className="flex-1 py-3 bg-white border-2 border-dashed border-yellow-300 text-yellow-700 font-bold rounded-xl hover:bg-yellow-50 transition-all"
                                      >
                                          + Add Premium Video
                                      </button>
                                  </div>
                                  <div className="sticky bottom-0 left-0 w-full p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-50 mt-4 md:static md:bg-transparent md:border-t-0 md:p-0 rounded-b-2xl md:rounded-none shadow-[0_-8px_15px_-3px_rgba(0,0,0,0.1)] md:shadow-none">
                                      <button onClick={saveChapterContent} className="w-full mt-2 bg-yellow-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-yellow-700 transition-all flex items-center justify-center gap-2 border-2 border-white">
                                          <Save size={18} /> Save Premium Series
                                      </button>
                                  </div>
                              </div>

                          <div className="space-y-6 bg-gradient-to-br from-rose-50 to-pink-50 p-6 rounded-xl border border-rose-200 opacity-50 pointer-events-none grayscale">
                              <div className="flex items-center gap-2 mb-3">
                                  <Video size={20} className="text-rose-600" />
                                  <h4 className="font-bold text-rose-900">Legacy Video Playlist Manager (Max 100)</h4>
                              </div>
                              
                              <p className="text-xs text-rose-700 mb-4 bg-white p-2 rounded border border-rose-100">
                                  Enter YouTube or Google Drive links. Set Price to 0 for Free videos.
                              </p>

                              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                                  {videoPlaylist.map((vid, i) => {
                                      // Ensure valid object structure with optional price defaulting
                                      // const existing = videoPlaylist[i];
                                      // const vid = existing && typeof existing === 'object' ? existing : {title: '', url: '', price: 5};
                                      
                                      return (
                                          <div key={i} className="flex flex-col gap-2 bg-white p-3 rounded-lg border border-rose-100 shadow-sm">
                                              <div className="flex flex-wrap gap-2 items-center">
                                                  <span className="w-8 text-center text-xs font-bold text-rose-500 bg-rose-50 rounded py-2">{i + 1}</span>
                                                  
                                                  <input 
                                                      type="text" 
                                                      value={vid.title || ''} 
                                                      onChange={(e) => {
                                                          const updated = [...videoPlaylist];
                                                          updated[i] = {...updated[i], title: e.target.value};
                                                          setVideoPlaylist(updated);
                                                      }}
                                                      placeholder={`Title (e.g. Lecture ${i + 1})`}
                                                      className="flex-1 p-2 border border-slate-200 rounded text-xs font-bold text-slate-700" 
                                                  />
                                                  
                                                  {/* ACCESS CONTROL */}
                                                  <select
                                                      value={vid.access || 'ULTRA'}
                                                      onChange={(e) => {
                                                          const updated = [...videoPlaylist];
                                                          updated[i] = {...updated[i], access: e.target.value as any};
                                                          setVideoPlaylist(updated);
                                                      }}
                                                      className={`p-2 rounded text-xs font-bold border ${
                                                          vid.access === 'FREE' ? 'bg-green-50 text-green-700 border-green-200' :
                                                          vid.access === 'BASIC' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                                          'bg-purple-50 text-purple-700 border-purple-200'
                                                      }`}
                                                  >
                                                      <option value="FREE">FREE</option>
                                                      <option value="BASIC">BASIC</option>
                                                      <option value="ULTRA">ULTRA</option>
                                                  </select>

                                                  <div className="w-16">
                                                      <input 
                                                          type="number" 
                                                          value={vid.price !== undefined ? vid.price : 5} 
                                                          onChange={(e) => {
                                                              const updated = [...videoPlaylist];
                                                              updated[i] = {...updated[i], price: Number(e.target.value)};
                                                              setVideoPlaylist(updated);
                                                          }}
                                                          className="w-full p-2 border border-slate-200 rounded text-xs text-center font-bold" 
                                                          placeholder="Price"
                                                      />
                                                  </div>

                                                  <button
                                                      onClick={() => generateDirectCode('VIDEO', `${editingChapterId}_legacy_vid_${i}`)}
                                                      className="p-2 bg-yellow-100 text-yellow-600 rounded hover:bg-yellow-200"
                                                      title="Generate Unlock Code"
                                                  >
                                                      <Key size={16} />
                                                  </button>

                                                  <button 
                                                      onClick={() => {
                                                          const updated = videoPlaylist.filter((_, idx) => idx !== i);
                                                          setVideoPlaylist(updated);
                                                      }}
                                                      className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                                                      title="Remove Video"
                                                  >
                                                      <Trash2 size={16} />
                                                  </button>
                                              </div>

                                              <input 
                                                  type="text" 
                                                  value={vid.url || ''} 
                                                  onChange={(e) => {
                                                      const updated = [...videoPlaylist];
                                                      updated[i] = {...updated[i], url: e.target.value};
                                                      setVideoPlaylist(updated);
                                                  }}
                                                  placeholder="https://youtu.be/..."
                                                  className="w-full p-2 border border-slate-200 rounded text-xs font-mono text-blue-600 bg-slate-50" 
                                              />
                                          </div>
                                      );
                                  })}
                              </div>

                              <div className="flex gap-2">
                                  <button 
                                      onClick={() => {
                                          if (videoPlaylist.length >= 100) {
                                              alert("Max 100 videos limit reached!");
                                              return;
                                          }
                                          setVideoPlaylist([...videoPlaylist, {title: '', url: '', price: 5, access: 'ULTRA'}]);
                                      }}
                                      className="flex-1 py-3 bg-white border border-rose-200 text-rose-600 font-bold rounded-xl hover:bg-rose-50 transition dashed"
                                  >
                                      + Add Video
                                  </button>
                                  <label className="flex items-center gap-2 cursor-pointer bg-white px-3 py-3 rounded-xl border border-rose-200">
                                      <input 
                                          type="checkbox" 
                                          checked={editConfig.isVideoHidden || false} 
                                          onChange={e => setEditConfig({...editConfig, isVideoHidden: e.target.checked})}
                                          className="accent-red-600 w-4 h-4"
                                      />
                                      <span className="text-xs font-bold text-slate-600">Hide Videos</span>
                                  </label>
                                  <button onClick={saveChapterContent} className="flex-1 bg-rose-600 text-white font-bold py-3 rounded-xl shadow hover:bg-rose-700 transition">
                                      💾 Save Videos
                                  </button>
                              </div>
                          </div>

                          {/* GLOBAL SAVE BUTTON FOR VIDEOS */}
                          <div className="p-4 bg-white rounded-xl border border-slate-200 sticky bottom-0 z-50 shadow-lg">
                              <button onClick={saveChapterContent} className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow hover:bg-blue-700 transition flex items-center justify-center gap-2">
                                  <Save size={20} /> Save All Video Content
                              </button>
                          </div>
                          </div>
                      )}

                      {/* AUDIO EDITOR (Dynamic List up to 100) */}
                      {activeTab === 'CONTENT_AUDIO' && (
                          <div className="space-y-6 bg-gradient-to-br from-pink-50 to-purple-50 p-6 rounded-xl border border-pink-200">
                              <div className="flex items-center gap-2 mb-3">
                                  <Headphones size={20} className="text-pink-600" />
                                  <h4 className="font-bold text-pink-900">Audio Playlist Manager (Max 100)</h4>
                              </div>
                              
                              <p className="text-xs text-pink-700 mb-4 bg-white p-2 rounded border border-pink-100">
                                  Enter MP3/Audio links. Set Access to ULTRA for Premium Content.
                              </p>

                              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                                  {audioPlaylist.map((track, i) => {
                                      return (
                                          <div key={i} className="flex flex-col gap-2 bg-white p-3 rounded-lg border border-pink-100 shadow-sm">
                                              <div className="flex gap-2 items-center">
                                                  <span className="w-8 text-center text-xs font-bold text-pink-500 bg-pink-50 rounded py-2">{i + 1}</span>
                                                  
                                                  <input 
                                                      type="text" 
                                                      value={track.title || ''} 
                                                      onChange={(e) => {
                                                          const updated = [...audioPlaylist];
                                                          updated[i] = {...updated[i], title: e.target.value};
                                                          setAudioPlaylist(updated);
                                                      }}
                                                      placeholder={`Track Title ${i + 1}`}
                                                      className="flex-1 p-2 border border-slate-200 rounded text-xs font-bold text-slate-700" 
                                                  />
                                                  
                                                  {/* ACCESS CONTROL */}
                                                  <select
                                                      value={track.access || 'ULTRA'}
                                                      onChange={(e) => {
                                                          const updated = [...audioPlaylist];
                                                          updated[i] = {...updated[i], access: e.target.value as any};
                                                          setAudioPlaylist(updated);
                                                      }}
                                                      className={`p-2 rounded text-xs font-bold border ${
                                                          track.access === 'FREE' ? 'bg-green-50 text-green-700 border-green-200' :
                                                          track.access === 'BASIC' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                                                          'bg-purple-50 text-purple-700 border-purple-200'
                                                      }`}
                                                  >
                                                      <option value="FREE">FREE</option>
                                                      <option value="BASIC">BASIC</option>
                                                      <option value="ULTRA">ULTRA</option>
                                                  </select>

                                                  <div className="w-16">
                                                      <input 
                                                          type="number" 
                                                          value={track.price !== undefined ? track.price : 5} 
                                                          onChange={(e) => {
                                                              const updated = [...audioPlaylist];
                                                              updated[i] = {...updated[i], price: Number(e.target.value)};
                                                              setAudioPlaylist(updated);
                                                          }}
                                                          className="w-full p-2 border border-slate-200 rounded text-xs text-center font-bold" 
                                                          placeholder="Price"
                                                      />
                                                  </div>

                                                  <button 
                                                      onClick={() => {
                                                          const updated = audioPlaylist.filter((_, idx) => idx !== i);
                                                          setAudioPlaylist(updated);
                                                      }}
                                                      className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                                                      title="Remove Track"
                                                  >
                                                      <Trash2 size={16} />
                                                  </button>
                                              </div>

                                              <input 
                                                  type="text" 
                                                  value={track.url || ''} 
                                                  onChange={(e) => {
                                                      const updated = [...audioPlaylist];
                                                      updated[i] = {...updated[i], url: e.target.value};
                                                      setAudioPlaylist(updated);
                                                  }}
                                                  placeholder="https://example.com/audio.mp3"
                                                  className="w-full p-2 border border-slate-200 rounded text-xs font-mono text-blue-600 bg-slate-50" 
                                              />
                                          </div>
                                      );
                                  })}
                              </div>

                              <div className="flex gap-2">
                                  <button 
                                      onClick={() => {
                                          if (audioPlaylist.length >= 100) {
                                              alert("Max 100 tracks limit reached!");
                                              return;
                                          }
                                          setAudioPlaylist([...audioPlaylist, {title: '', url: '', price: 5, access: 'ULTRA'}]);
                                      }}
                                      className="flex-1 py-3 bg-white border border-pink-200 text-pink-600 font-bold rounded-xl hover:bg-pink-50 transition dashed"
                                  >
                                      + Add Track
                                  </button>
                                  <label className="flex items-center gap-2 cursor-pointer bg-white px-3 py-3 rounded-xl border border-pink-200">
                                      <input 
                                          type="checkbox" 
                                          checked={editConfig.isAudioHidden || false} 
                                          onChange={e => setEditConfig({...editConfig, isAudioHidden: e.target.checked})}
                                          className="accent-red-600 w-4 h-4"
                                      />
                                      <span className="text-xs font-bold text-slate-600">Hide Audio</span>
                                  </label>
                                  <button onClick={() => generateDirectCode('AUDIO', editingChapterId!)} className="px-4 bg-yellow-400 text-black font-bold py-3 rounded-xl shadow hover:bg-yellow-500 flex items-center justify-center gap-2">
                                      <Key size={16} /> Code
                                  </button>
                              </div>

                              <div className="sticky bottom-0 left-0 w-full p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-50 mt-4 md:static md:bg-transparent md:border-t-0 md:p-0 rounded-b-2xl md:rounded-none shadow-[0_-8px_15px_-3px_rgba(0,0,0,0.1)] md:shadow-none">
                                  <button onClick={saveChapterContent} className="w-full bg-pink-600 text-white font-bold py-3 rounded-xl shadow hover:bg-pink-700 transition border-2 border-white">
                                      <Save size={18} className="inline mr-2" /> Save Audio Playlist
                                  </button>
                              </div>
                          </div>
                      )}



                      {/* MCQ / TEST EDITOR */}
                      {(activeTab === 'CONTENT_MCQ' || activeTab === 'CONTENT_TEST') && (
                          <div className="space-y-4">
                              {/* UNIFIED IMPORT (MCQ + NOTES) */}
                              <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200 shadow-sm">
                                  <div className="flex items-center gap-2 mb-3">
                                      <div className="bg-green-100 p-2 rounded text-green-700">
                                          <Database size={18} />
                                      </div>
                                      <div>
                                          <h4 className="font-bold text-slate-800 text-sm">Unified Content Import (MCQs + Notes)</h4>
                                          <p className="text-[10px] text-slate-600">Paste mixed content here. The system will separate MCQs and Notes automatically.</p>
                                      </div>
                                  </div>

                                  <div className="bg-slate-50 p-2 rounded-lg text-[10px] text-slate-600 mb-2 border border-slate-200 font-mono">
                                      <strong>Supported Format:</strong><br/>
                                      1. <b>MCQs:</b> Standard Vertical format (Questions, Options, Answer).<br/>
                                      2. <b>Bulk Topic:</b> Use <span className="bg-blue-100 px-1 rounded">&lt;TOPIC: Force&gt;</span> to set topic for following questions.<br/>
                                      3. <b>Notes:</b> Use <span className="bg-yellow-100 px-1 rounded">&lt;NOTE: Force&gt; HTML Content &lt;/NOTE&gt;</span><br/>
                                      <br/>
                                      <i>Example:</i><br/>
                                      &lt;TOPIC: Gravity&gt;<br/>
                                      Q1. ... Answer: A<br/>
                                      Q2. ... Answer: B<br/>
                                      &lt;NOTE: Gravity&gt;Gravity is a force...&lt;/NOTE&gt;
                                  </div>

                                  <textarea 
                                      value={importText} 
                                      onChange={e => setImportText(e.target.value)}
                                      placeholder={`Q1. What is Force? ... Answer: A ... Topic: Force

<NOTE: Force>
<b>Force</b> is a push or pull.
</NOTE>`}
                                      className="w-full h-32 p-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-green-500 outline-none mb-2"
                                  />
                                  
                                  <div className="flex gap-2">
                                      <button 
                                          onClick={() => setImportText('')} 
                                          className="flex-1 bg-slate-100 text-slate-600 py-2 rounded-lg font-bold text-xs hover:bg-slate-200"
                                      >
                                          Clear
                                      </button>
                                      <button 
                                          onClick={() => handleUnifiedImport(activeTab === 'CONTENT_TEST')}
                                          className="flex-[2] bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-2 shadow"
                                      >
                                          <Upload size={14} /> Process & Import
                                      </button>
                                  </div>
                              </div>

                              {/* TOPIC WISE NOTES MANAGEMENT */}
                              <div className="bg-orange-50 p-4 rounded-xl border border-orange-200 shadow-sm">
                                  <div className="flex items-center justify-between mb-3">
                                      <div className="flex items-center gap-2">
                                          <div className="bg-orange-100 p-2 rounded text-orange-700">
                                              <FileText size={18} />
                                          </div>
                                          <div>
                                              <h4 className="font-bold text-slate-800 text-sm">Topic Notes 2.0</h4>
 
                                              <p className="text-[10px] text-slate-600">Auto-suggested based on weak topics.</p>

                                              <p className="text-[10px] text-slate-600">Add HTML notes class, subject, and lesson topic wise.</p>

                                          </div>
                                      </div>
                                      <div className="flex gap-2">
                                          <button
                                              onClick={() => {
                                                  const topic = prompt("Enter Topic Name:");
                                                  if(topic) {
                                                      setTopicNotes([...topicNotes, {
                                                          id: `note-${Date.now()}`,
                                                          title: `Note: ${topic}`,
                                                          topic: topic,
                                                          content: "<p>New Note</p>",
                                                          isPremium: false
                                                      }]);
                                                  }
                                              }}
                                              className="bg-white border border-orange-200 text-orange-600 px-3 py-1 rounded-lg text-[10px] font-bold hover:bg-orange-100"
                                          >
                                              + Free Note (HTML)
                                          </button>
                                          <button
                                              onClick={() => {
                                                  const topic = prompt("Enter Topic Name:");
                                                  if(topic) {
                                                      setTopicNotes([...topicNotes, {
                                                          id: `note-${Date.now()}`,
                                                          title: `Premium Note: ${topic}`,
                                                          topic: topic,
                                                          content: "", // Will hold URL
                                                          isPremium: true
                                                      }]);
                                                  }
                                              }}
                                              className="bg-orange-600 text-white px-3 py-1 rounded-lg text-[10px] font-bold hover:bg-orange-700"
                                          >
                                              + Premium (PDF)
                                          </button>
                                      </div>
                                  </div>

                                  {topicNotes.length === 0 ? (
                                      <div className="text-center p-4 text-slate-500 text-xs italic border border-dashed border-orange-200 rounded-lg">
                                          No topic notes added. Import unified content or add manually.
                                      </div>
                                  ) : (
                                      <div className="space-y-2 max-h-60 overflow-y-auto">
                                          {topicNotes.map((note, idx) => (
                                              <div key={note.id} className="bg-white p-3 rounded-lg border border-orange-100 flex flex-col gap-2">
                                                  <div className="flex justify-between items-start">
                                                      <div>
                                                          <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${note.isPremium ? 'bg-purple-100 text-purple-700' : 'bg-green-100 text-green-700'}`}>
                                                              {note.isPremium ? 'PREMIUM PDF' : 'FREE HTML'}
                                                          </span>
                                                          <p className="font-bold text-xs text-slate-700 mt-1">Topic: {note.topic}</p>
                                                      </div>
                                                      <button
                                                          onClick={() => setTopicNotes(topicNotes.filter((_, i) => i !== idx))}
                                                          className="text-red-400 hover:text-red-600"
                                                      >
                                                          <Trash2 size={14} />
                                                      </button>
                                                  </div>

                                                  {note.isPremium ? (
                                                      <input
                                                          type="text"
                                                          value={note.content}
                                                          onChange={e => {
                                                              const updated = [...topicNotes];
                                                              updated[idx].content = e.target.value;
                                                              setTopicNotes(updated);
                                                          }}
                                                          placeholder="Paste PDF URL here..."
                                                          className="w-full p-2 border border-slate-200 rounded text-xs text-blue-600"
                                                      />
                                                  ) : (
                                                      <textarea
                                                          value={note.content}
                                                          onChange={e => {
                                                              const updated = [...topicNotes];
                                                              updated[idx].content = e.target.value;
                                                              setTopicNotes(updated);
                                                          }}
                                                          placeholder="HTML Content..."
                                                          className="w-full h-16 p-2 border border-slate-200 rounded text-xs font-mono"
                                                      />
                                                  )}
                                              </div>
                                          ))}
                                      </div>
                                  )}
                              </div>


                              {/* AI GENERATION */}
                              <div className="bg-gradient-to-r from-violet-50 to-purple-50 p-4 rounded-xl border border-violet-200 shadow-sm mb-4">
                                  <div className="flex items-center gap-2 mb-3">
                                      <div className="bg-violet-100 p-2 rounded text-violet-700">
                                          <BrainCircuit size={18} />
                                      </div>
                                      <div>
                                          <h4 className="font-bold text-slate-800 text-sm">AI Professional Generator</h4>
                                          <p className="text-[10px] text-slate-600">Strict NCERT Pattern • Explanations Included</p>
                                      </div>
                                  </div>
                                  <div className="flex gap-2 items-end">
                                      <div className="flex-1">
                                          <label className="text-[10px] font-bold text-violet-700 uppercase">Count</label>
                                          <select 
                                              value={mcqGenCount} 
                                              onChange={e => setMcqGenCount(Number(e.target.value))}
                                              className="w-full p-2 rounded-lg border border-violet-200 text-sm font-bold bg-white"
                                          >
                                              <option value="20">20 Questions</option>
                                              <option value="50">50 Questions</option>
                                              <option value="100">100 Questions</option>
                                          </select>
                                      </div>
                                      <button 
                                          onClick={handleBulkGenerateMCQs}
                                          disabled={isAiGenerating}
                                          className="flex-[2] bg-violet-600 text-white py-2 rounded-lg font-bold text-xs shadow hover:bg-violet-700 flex items-center justify-center gap-2 disabled:opacity-50"
                                      >
                                          {isAiGenerating ? <RefreshCw className="animate-spin" size={14} /> : <Sparkles size={14} />}
                                          Generate MCQs
                                      </button>
                                      <button
                                          onClick={generateNotePlaceholders}
                                          className="flex-1 bg-amber-100 text-amber-700 py-2 rounded-lg font-bold text-xs shadow-sm border border-amber-200 hover:bg-amber-200 flex items-center justify-center gap-2"
                                          title="Generate Note Placeholders from Topics"
                                      >
                                          <FileText size={14} /> Auto Notes
                                      </button>
                                  </div>
                              </div>

                              <div className="mb-4">
                                  <h3 className="font-bold text-slate-700 text-lg mb-3">Total Questions: {(activeTab === 'CONTENT_TEST' ? editingTestMcqs : editingMcqs).length}</h3>
                                  <div className="flex flex-wrap gap-2.5 items-center">
                                      <button onClick={() => deleteAllMcqs(activeTab === 'CONTENT_TEST')} className="bg-red-50 text-red-600 border border-red-200 px-3.5 py-2 rounded-lg text-sm font-bold hover:bg-red-100 transition-colors">Delete All</button>
                                      <button onClick={() => addMcq(activeTab === 'CONTENT_TEST')} className="bg-white border border-blue-200 text-blue-600 px-3.5 py-2 rounded-lg text-sm font-bold hover:bg-blue-50">+ Add Question</button>
                                      <button
                                          onClick={() => {
                                              const list = activeTab === 'CONTENT_TEST' ? editingTestMcqs : editingMcqs;
                                              if (list.length === 0) { alert("No questions to copy!"); return; }

                                              // Format: Question \t OptA \t OptB \t OptC \t OptD \t AnswerIndex(1-4) \t Explanation
                                              const text = list.map(q => {
                                                  return `${q.question}\t${q.options[0]}\t${q.options[1]}\t${q.options[2]}\t${q.options[3]}\t${q.correctAnswer + 1}\t${q.explanation || ''}`;
                                              }).join('\n');

                                              navigator.clipboard.writeText(text);
                                              alert(`✅ Copied ${list.length} questions to clipboard!\n\nPaste directly into Google Sheets or Excel.`);
                                          }}
                                          className="bg-indigo-100 text-indigo-700 border border-indigo-200 px-3.5 py-2 rounded-lg text-sm font-bold hover:bg-indigo-200 flex items-center gap-1.5"
                                      >
                                          <Copy size={16} /> Copy for Sheets
                                      </button>
                                      <label className="flex items-center gap-2 cursor-pointer bg-white px-3.5 py-2 rounded-lg border border-slate-200 shadow-sm">
                                          <input 
                                              type="checkbox" 
                                              checked={editConfig.isMcqHidden || false} 
                                              onChange={e => setEditConfig({...editConfig, isMcqHidden: e.target.checked})}
                                              className="accent-red-600 w-4 h-4"
                                          />
                                          <span className="text-sm font-bold text-slate-600">Hide</span>
                                      </label>
                                      <button onClick={() => generateDirectCode('MCQ', editingChapterId!)} className="px-3.5 bg-yellow-400 text-black font-bold py-2 rounded-lg shadow-sm hover:bg-yellow-500 flex items-center justify-center gap-1.5 text-sm">
                                          <Key size={16} /> Code
                                      </button>
                                      <button onClick={saveChapterContent} className="px-4 py-2 bg-cyan-600 text-white font-bold rounded-lg shadow-sm hover:bg-cyan-700 flex items-center justify-center gap-1.5 text-sm">
                                          <Save size={16} /> Save
                                      </button>
                                  </div>
                              </div>
                              
                              <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 pb-24">
                                  {(activeTab === 'CONTENT_TEST' ? editingTestMcqs : editingMcqs).map((q, idx) => (
                                      <div key={idx} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm relative group">
                                          <button onClick={() => removeMcq(activeTab === 'CONTENT_TEST', idx)} className="absolute top-2 right-2 text-slate-300 hover:text-red-500"><Trash2 size={16} /></button>
                                          <div className="flex gap-2 mb-2">
                                              <span className="bg-slate-100 text-slate-600 font-bold w-6 h-6 flex items-center justify-center rounded text-xs mt-1">{idx + 1}</span>
                                              <div className="flex-1 space-y-2">
                                                  <textarea
                                                      value={q.question}
                                                      onChange={e => updateMcq(activeTab === 'CONTENT_TEST', idx, 'question', e.target.value)}
                                                      className="w-full p-2 border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                                                      rows={2}

                                                      placeholder="Type question here..."
                                                  />
                                                  <textarea
                                                      value={q.statements ? q.statements.join('\n') : ''}
                                                      onChange={e => {
                                                          const lines = e.target.value.split('\n').filter(l => l.trim() !== '');
                                                          updateMcq(activeTab === 'CONTENT_TEST', idx, 'statements', lines.length > 0 ? lines : undefined);
                                                      }}
                                                      className="w-full p-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 outline-none resize-none bg-slate-50"
                                                      rows={2}
                                                      placeholder="Statements (Optional - One per line)
Statement 1
Statement 2"
                                                  />
                                                  {/* Statements Manager */}
                                                  <div className="space-y-2 pl-2 border-l-2 border-indigo-200">
                                                      {q.statements && q.statements.map((stmt, sIdx) => (
                                                          <div key={sIdx} className="flex gap-2 items-start">
                                                              <span className="text-xs font-bold text-slate-400 mt-2">S{sIdx+1}</span>
                                                              <textarea
                                                                  value={stmt}
                                                                  onChange={(e) => {
                                                                      const newStatements = [...(q.statements || [])];
                                                                      newStatements[sIdx] = e.target.value;
                                                                      updateMcq(activeTab === 'CONTENT_TEST', idx, 'statements', newStatements);
                                                                  }}
                                                                  className="flex-1 p-2 border border-slate-200 rounded-lg text-xs font-medium focus:ring-2 focus:ring-indigo-500 outline-none resize-none bg-slate-50"
                                                                  rows={1}
                                                                  placeholder="Statement text..."
                                                              />
                                                              <button
                                                                  onClick={() => {
                                                                      const newStatements = (q.statements || []).filter((_, i) => i !== sIdx);
                                                                      updateMcq(activeTab === 'CONTENT_TEST', idx, 'statements', newStatements);
                                                                  }}
                                                                  className="text-slate-300 hover:text-red-500 mt-2"
                                                                  title="Remove Statement"
                                                              >
                                                                  <Trash2 size={14} />
                                                              </button>
                                                          </div>
                                                      ))}
                                                      <button
                                                          onClick={() => {
                                                              const newStatements = [...(q.statements || []), ""];
                                                              updateMcq(activeTab === 'CONTENT_TEST', idx, 'statements', newStatements);
                                                          }}
                                                          className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-1 rounded font-bold hover:bg-indigo-100 flex items-center gap-1 w-fit"
                                                      >
                                                          + Add Statement
                                                      </button>
                                                  </div>

                                              </div>
                                          </div>
                                          <div className="grid grid-cols-2 gap-3 ml-8 mt-2">
                                              {q.options.map((opt, oIdx) => (
                                                  <div key={oIdx} className="flex items-center gap-2">
                                                      <input 
                                                          type="radio" 
                                                          name={`q-${activeTab}-${idx}`} 
                                                          checked={q.correctAnswer === oIdx} 
                                                          onChange={() => updateMcq(activeTab === 'CONTENT_TEST', idx, 'correctAnswer', oIdx)}
                                                          className="accent-green-600"
                                                      />
                                                      <input 
                                                          type="text" 
                                                          value={opt} 
                                                          onChange={e => updateMcqOption(activeTab === 'CONTENT_TEST', idx, oIdx, e.target.value)}
                                                          className={`w-full p-1.5 border rounded text-xs ${q.correctAnswer === oIdx ? 'border-green-300 bg-green-50 text-green-800 font-bold' : 'border-slate-200'}`}
                                                          placeholder={`Option ${String.fromCharCode(65+oIdx)}`}
                                                      />
                                                  </div>
                                              ))}
                                          </div>
                                          <div className="ml-8 mt-2">
                                              <input 
                                                  type="text" 
                                                  value={q.explanation} 
                                                  onChange={e => updateMcq(activeTab === 'CONTENT_TEST', idx, 'explanation', e.target.value)}
                                                  className="w-full p-2 border border-dashed border-slate-300 rounded text-xs text-slate-600 bg-slate-50"
                                                  placeholder="Explanation (Optional)"
                                              />
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          </div>
                      )}
                      </>
                      )}
                  </div>
              )}
          </div>
      )}

      {/* 4. SETTINGS TABS */}
      {activeTab.startsWith('CONFIG_') && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Settings: {activeTab.replace('CONFIG_', '')}</h3>
              </div>
              <div className="w-full space-y-6">
                  {/* GENERAL */}
                  {activeTab === 'CONFIG_GENERAL' && (
                      <>
                          {/* LOGO UPLOAD */}
                          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-4">
                              <label className="text-xs font-bold uppercase text-slate-600 block mb-2">App Logo</label>
                              <div className="flex items-center gap-4">
                                  <div className="w-20 h-20 bg-white rounded-full border border-slate-300 flex items-center justify-center overflow-hidden">
                                      {localSettings.appLogo ? (
                                          <img src={localSettings.appLogo} alt="Logo" className="w-full h-full object-contain" />
                                      ) : (
                                          <span className="text-xs text-slate-500 font-bold">{localSettings.appShortName || 'IIC'}</span>
                                      )}
                                  </div>
                                  <div className="flex-1">
                                      <input 
                                          type="file" 
                                          accept="image/*"
                                          onChange={(e) => {
                                              const file = e.target.files?.[0];
                                              if (file) {
                                                  // Check size (e.g., max 2MB before crop)
                                                  if (file.size > 2 * 1024 * 1024) {
                                                      alert("Image too large! Please select an image under 2MB.");
                                                      return;
                                                  }
                                                  const reader = new FileReader();
                                                  reader.onloadend = () => {
                                                      setCropImageSrc(reader.result as string);
                                                  };
                                                  reader.readAsDataURL(file);
                                              }
                                          }}
                                          className="w-full text-xs text-slate-600 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                                      />
                                      <p className="text-[10px] text-slate-500 mt-1">Recommended: Square PNG/JPG</p>
                                  </div>
                                  {localSettings.appLogo && (
                                      <button 
                                          onClick={() => setLocalSettings({...localSettings, appLogo: undefined})}
                                          className="text-red-500 hover:text-red-700 p-2"
                                          title="Remove Logo"
                                      >
                                          <Trash2 size={20} />
                                      </button>
                                  )}
                              </div>
                          </div>

                          <div><label className="text-xs font-bold uppercase text-slate-600">App Name (Long)</label><input type="text" value={localSettings.appName} onChange={e => setLocalSettings({...localSettings, appName: e.target.value})} className="w-full p-3 border rounded-xl" placeholder="IIC" /></div>
                          <div><label className="text-xs font-bold uppercase text-slate-600">App Logo (Image URL)</label><input type="text" value={localSettings.appLogo || ''} onChange={e => setLocalSettings({...localSettings, appLogo: e.target.value})} className="w-full p-3 border rounded-xl" placeholder="https://example.com/logo.png" /></div>
                          <div className="grid grid-cols-2 gap-3">
                              <div><label className="text-xs font-bold uppercase text-slate-600">App Short Name</label><input type="text" value={localSettings.appShortName || 'IIC'} onChange={e => setLocalSettings({...localSettings, appShortName: e.target.value})} className="w-full p-3 border rounded-xl" placeholder="IIC" /></div>
                              <div><label className="text-xs font-bold uppercase text-slate-600">AI Assistant Name</label><input type="text" value={localSettings.aiName || 'IIC AI'} onChange={e => setLocalSettings({...localSettings, aiName: e.target.value})} className="w-full p-3 border rounded-xl" placeholder="IIC AI" /></div>
                          </div>

                      {/* AI Model Control */}
                      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800 mb-4">
                        <div className="flex items-center gap-2 mb-4 text-blue-700 dark:text-blue-400 font-bold">
                          <Bot className="w-5 h-5" />
                          <span>AI Control Tower</span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Active AI Model (1-Click Change)</label>
                            <select 
                              value={localSettings.aiModel} 
                              onChange={(e) => {
                                const newSettings = { ...localSettings, aiModel: e.target.value };
                                setLocalSettings(newSettings);
                                saveSystemSettings(newSettings);
                              }}
                              className="w-full p-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            >
                              {MODELS.map(m => (
                                <option key={m} value={m}>{m}</option>
                              ))}
                            </select>
                            <p className="mt-1 text-xs text-slate-600">App will immediately start using this model for all AI requests.</p>
                          </div>
                        </div>
                      </div>

                      {/* FEATURE TOGGLES (User Request) */}
                      <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200 mb-4">
                          <h4 className="font-bold text-indigo-900 mb-3 flex items-center gap-2"><Settings size={18}/> Feature Toggles (Active/Inactive)</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="bg-white p-3 rounded-lg flex items-center justify-between border border-indigo-100">
                                  <div>
                                      <p className="font-bold text-slate-700 text-xs">Morning Test / Insight Banner</p>
                                      <p className="text-[10px] text-slate-600">Show daily insight banner on Explore page.</p>
                                  </div>
                                  <input
                                      type="checkbox"
                                      checked={localSettings.showMorningInsight !== false}
                                      onChange={() => setLocalSettings({
                                          ...localSettings,
                                          showMorningInsight: localSettings.showMorningInsight === false ? true : false
                                      })}
                                      className="w-5 h-5 accent-indigo-600 cursor-pointer"
                                  />
                              </div>
                              <div className="bg-white p-3 rounded-lg flex items-center justify-between border border-indigo-100">
                                  <div>
                                      <p className="font-bold text-slate-700 text-xs">AI Chat / Ask Doubts</p>
                                      <p className="text-[10px] text-slate-600">Enable 'Ask your doubts' feature globally.</p>
                                  </div>
                                  <input
                                      type="checkbox"
                                      checked={localSettings.isAiEnabled !== false}
                                      onChange={() => setLocalSettings({
                                          ...localSettings,
                                          isAiEnabled: localSettings.isAiEnabled === false ? true : false
                                      })}
                                      className="w-5 h-5 accent-indigo-600 cursor-pointer"
                                  />
                              </div>
                              <div className="bg-white p-3 rounded-lg flex items-center justify-between border border-indigo-100">
                                  <div>
                                      <p className="font-bold text-slate-700 text-xs">Student Logout Button</p>
                                      <p className="text-[10px] text-slate-600">Allow students to log out of the app.</p>
                                  </div>
                                  <input
                                      type="checkbox"
                                      checked={localSettings.isLogoutEnabled !== false}
                                      onChange={() => setLocalSettings({
                                          ...localSettings,
                                          isLogoutEnabled: localSettings.isLogoutEnabled === false ? true : false
                                      })}
                                      className="w-5 h-5 accent-indigo-600 cursor-pointer"
                                  />
                              </div>
                          </div>
                      </div>

                      {/* VERSION CONTROL */}
                          {/* CHAT MODE SELECTOR */}
                          <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200">
                              <label className="text-xs font-bold uppercase text-indigo-800 mb-2 block">Chat System Mode</label>
                              <div className="grid grid-cols-3 gap-2">
                                  {['PRIVATE_ONLY', 'UNIVERSAL_ONLY', 'BOTH'].map(mode => (
                                      <button 
                                          key={mode} 
                                          onClick={() => setLocalSettings({...localSettings, chatMode: mode as any})}
                                          className={`py-2 rounded-lg text-xs font-bold border transition-all ${localSettings.chatMode === mode ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-white text-slate-600 border-indigo-100 hover:bg-indigo-50'}`}
                                      >
                                          {mode.replace('_', ' ')}
                                      </button>
                                  ))}
                              </div>
                          </div>

                          {/* FOOTER CUSTOMIZATION */}
                          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mt-4">
                              <label className="text-xs font-bold uppercase text-slate-800 mb-3 block underline decoration-blue-500 decoration-2 underline-offset-4">Footer Customization</label>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200 shadow-sm">
                                      <div className="flex flex-col">
                                          <span className="text-sm font-bold text-slate-700">Display Footer</span>
                                          <span className="text-[10px] text-slate-500">Show/Hide the "Developed by" line</span>
                                      </div>
                                      <button 
                                          onClick={() => setLocalSettings({...localSettings, showFooter: localSettings.showFooter === false ? true : false})}
                                          className={`w-12 h-6 rounded-full transition-colors relative ${localSettings.showFooter !== false ? 'bg-blue-600' : 'bg-slate-300'}`}
                                      >
                                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localSettings.showFooter !== false ? 'left-7' : 'left-1'}`} />
                                      </button>
                                  </div>
                                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                                      <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">Custom Name / Text</label>
                                      <input 
                                          type="text" 
                                          value={localSettings.footerText || ''} 
                                          onChange={e => setLocalSettings({...localSettings, footerText: e.target.value})}
                                          className="w-full p-2 border rounded-lg text-sm font-bold"
                                          placeholder="App Footer Text"
                                      />
                                  </div>
                                  <div className="md:col-span-2 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                                      <label className="text-[10px] font-bold text-slate-600 uppercase block mb-2">Text Color</label>
                                      <div className="flex gap-3">
                                          <input 
                                              type="color" 
                                              value={localSettings.footerColor || '#94a3b8'} 
                                              onChange={e => setLocalSettings({...localSettings, footerColor: e.target.value})}
                                              className="h-10 w-14 rounded-lg border-2 border-slate-100 p-1 cursor-pointer"
                                          />
                                          <input 
                                              type="text" 
                                              value={localSettings.footerColor || ''} 
                                              onChange={e => setLocalSettings({...localSettings, footerColor: e.target.value})}
                                              className="flex-1 p-2 border rounded-lg text-sm font-mono bg-slate-50"
                                              placeholder="#94a3b8"
                                          />
                                          <button 
                                              onClick={() => setLocalSettings({...localSettings, footerColor: '#94a3b8'})}
                                              className="px-3 py-2 bg-slate-100 text-slate-600 text-[10px] font-bold rounded-lg hover:bg-slate-200"
                                          >
                                              Reset
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div><label className="text-xs font-bold uppercase text-slate-600">Login Screen Message</label><input type="text" value={localSettings.loginMessage} onChange={e => setLocalSettings({...localSettings, loginMessage: e.target.value})} className="w-full p-3 border rounded-xl" /></div>
                          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200">
                              <div>
                                  <h4 className="font-bold text-slate-700">Google Login</h4>
                                  <p className="text-xs text-slate-600">Show/Hide Google Auth on login screen</p>
                              </div>
                              <button 
                                  onClick={async () => {
                                      const newSettings = {...localSettings, showGoogleLogin: !localSettings.showGoogleLogin};
                                      setLocalSettings(newSettings);
                                      try {
                                          await saveSystemSettings(newSettings);
                                      } catch (e) {
                                          console.error("Failed to save Google Login setting", e);
                                      }
                                  }}
                                  className={`px-4 py-2 rounded-lg font-bold transition-all ${localSettings.showGoogleLogin ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
                              >
                                  {localSettings.showGoogleLogin ? 'ENABLED' : 'DISABLED'}
                              </button>
                          </div>
                          
                          <div>
                              <label className="text-xs font-bold uppercase text-slate-600">Home Screen Notice</label>
                              <textarea 
                                  value={localSettings.noticeText || ''} 
                                  onChange={e => setLocalSettings({...localSettings, noticeText: e.target.value})} 
                                  className="w-full p-3 border rounded-xl h-24"
                                  placeholder="Write a notice for students..." 
                              />
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                              <div>
                                  <label className="text-xs font-bold uppercase text-slate-600">Support Chat Cost</label>
                                  <input type="number" value={localSettings.chatCost} onChange={e => setLocalSettings({...localSettings, chatCost: Number(e.target.value)})} className="w-full p-3 border rounded-xl" />
                              </div>
                              <div>
                          <label className="text-xs font-bold text-slate-600 uppercase">Developed By Text</label>
                          <input type="text" value={localSettings.developedBy || ''} onChange={(e) => setLocalSettings({...localSettings, developedBy: e.target.value})} className="w-full p-2 border rounded-lg" placeholder="App Developer Text" />
                      </div>
                      <div>
                                  <label className="text-xs font-bold uppercase text-slate-600">Cooldown (Hours)</label>
                                  <input type="number" value={localSettings.chatCooldownHours || 0} onChange={e => setLocalSettings({...localSettings, chatCooldownHours: Number(e.target.value)})} className="w-full p-3 border rounded-xl" />
                              </div>
                          </div>

                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mt-4">
                      <div className="flex items-center justify-between mb-4">
                          <h4 className="font-bold text-slate-800">Standalone AI Feature</h4>
                          <label className="flex items-center cursor-pointer">
                              <div className="relative">
                                  <input type="checkbox" className="sr-only" checked={localSettings.isAiEnabled || false} onChange={() => toggleSetting('isAiEnabled')} />
                                  <div className={`block w-10 h-6 rounded-full transition-colors ${localSettings.isAiEnabled ? 'bg-green-500' : 'bg-slate-300'}`}></div>
                                  <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${localSettings.isAiEnabled ? 'transform translate-x-4' : ''}`}></div>
                              </div>
                              <div className="ml-3 text-sm font-medium text-slate-700">Enable for Students</div>
                          </label>
                      </div>
                      
                      <div className="space-y-3">
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Custom Prompt for Notes</label>
                              <textarea 
                                  value={localSettings.aiNotesPrompt || ''} 
                                  onChange={e => setLocalSettings({...localSettings, aiNotesPrompt: e.target.value})} 
                                  className="w-full p-2 border rounded-lg h-24 text-sm"
                                  placeholder="Enter custom prompt for the AI Notes generator..."
                              />
                          </div>
                          
                          <div className="grid grid-cols-3 gap-3">
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 uppercase">Free Limit (Daily)</label>
                                  <input 
                                      type="number" 
                                      value={localSettings.aiLimits?.free || 0} 
                                      onChange={e => setLocalSettings({
                                          ...localSettings, 
                                          aiLimits: { ...(localSettings.aiLimits || {free:0, basic:0, ultra:0}), free: Number(e.target.value) }
                                      })} 
                                      className="w-full p-2 border rounded-lg" 
                                  />
                              </div>
                              <div>
                                  <label className="text-[10px] font-bold text-slate-600 uppercase">Basic Limit (Daily)</label>
                                  <input 
                                      type="number" 
                                      value={localSettings.aiLimits?.basic || 0} 
                                      onChange={e => setLocalSettings({
                                          ...localSettings, 
                                          aiLimits: { ...(localSettings.aiLimits || {free:0, basic:0, ultra:0}), basic: Number(e.target.value) }
                                      })} 
                                      className="w-full p-2 border rounded-lg" 
                                  />
                              </div>

                          <div>
                                  <label className="text-[10px] font-bold text-slate-600 uppercase">Ultra Limit (Daily)</label>
                                  <input 
                                      type="number" 
                                      value={localSettings.aiLimits?.ultra || 0} 
                                      onChange={e => setLocalSettings({
                                          ...localSettings, 
                                          aiLimits: { ...(localSettings.aiLimits || {free:0, basic:0, ultra:0}), ultra: Number(e.target.value) }
                                      })} 
                                      className="w-full p-2 border rounded-lg" 
                                  />
                              </div>

                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                          <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Maintenance Bypass Code</label>
                          <input
                              type="text"
                              value={localSettings.maintenanceBypassCode || ''}
                              onChange={e => setLocalSettings({...localSettings, maintenanceBypassCode: e.target.value})}
                              placeholder="Enter dynamic code..."
                              className="w-full p-2 border rounded-lg font-bold text-slate-800"
                          />
                          <p className="text-[10px] text-slate-500 mt-1">This code allows entry during maintenance mode.</p>
                      </div>
                          </div>
                      </div>
                  </div>
                          
                          {/* NEW: Extra Settings */}
                          {/* FOOTER CUSTOMIZATION */}
                          <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200 mt-4">
                              <label className="text-xs font-bold uppercase text-indigo-800 mb-3 block">Footer Customization</label>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="flex items-center justify-between p-2 bg-white rounded-lg border border-indigo-100">
                                      <span className="text-sm font-medium">Show Footer</span>
                                      <button 
                                          onClick={() => setLocalSettings({...localSettings, showFooter: localSettings.showFooter === false ? true : false})}
                                          className={`w-12 h-6 rounded-full transition-colors relative ${localSettings.showFooter !== false ? 'bg-green-500' : 'bg-slate-300'}`}
                                      >
                                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localSettings.showFooter !== false ? 'left-7' : 'left-1'}`} />
                                      </button>
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-600 uppercase">Footer Text</label>
                                      <input 
                                          type="text" 
                                          value={localSettings.footerText || ''} 
                                          onChange={e => setLocalSettings({...localSettings, footerText: e.target.value})}
                                          className="w-full p-2 border rounded-lg text-sm"
                                          placeholder="App Footer Text"
                                      />
                                  </div>
                                  <div className="md:col-span-2">
                                      <label className="text-[10px] font-bold text-slate-600 uppercase">Footer Color (Hex)</label>
                                      <div className="flex gap-2">
                                          <input 
                                              type="color" 
                                              value={localSettings.footerColor || '#94a3b8'} 
                                              onChange={e => setLocalSettings({...localSettings, footerColor: e.target.value})}
                                              className="h-9 w-12 rounded border p-1"
                                          />
                                          <input 
                                              type="text" 
                                              value={localSettings.footerColor || ''} 
                                              onChange={e => setLocalSettings({...localSettings, footerColor: e.target.value})}
                                              className="flex-1 p-2 border rounded-lg text-sm font-mono"
                                              placeholder="#94a3b8"
                                          />
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3 mt-3">
                              <div>
                                  <label className="text-xs font-bold uppercase text-slate-600">Name Change Cost</label>
                                  <input type="number" value={localSettings.nameChangeCost ?? 10} onChange={e => setLocalSettings({...localSettings, nameChangeCost: Number(e.target.value)})} className="w-full p-3 border rounded-xl" />
                              </div>
                              <div>
                                  <label className="text-xs font-bold uppercase text-slate-600">Chat Edit Time (Mins)</label>
                                  <input type="number" value={localSettings.chatEditTimeLimit ?? 15} onChange={e => setLocalSettings({...localSettings, chatEditTimeLimit: Number(e.target.value)})} className="w-full p-3 border rounded-xl" />
                              </div>
                          </div>

                          {/* SYLLABUS TYPE SELECTOR */}
                          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm mt-4">
                              <label className="text-xs font-bold text-slate-500 uppercase mb-2 block">Syllabus Mode</label>
                              <div className="flex gap-4">
                                  <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                      <input 
                                          type="radio" 
                                          name="syllabusType" 
                                          checked={localSettings.syllabusType === 'SCHOOL'} 
                                          onChange={() => setLocalSettings({...localSettings, syllabusType: 'SCHOOL'})}
                                      /> School
                                  </label>
                                  <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                      <input 
                                          type="radio" 
                                          name="syllabusType" 
                                          checked={localSettings.syllabusType === 'COMPETITIVE'} 
                                          onChange={() => setLocalSettings({...localSettings, syllabusType: 'COMPETITIVE'})}
                                      /> Competition
                                  </label>
                                  <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
                                      <input 
                                          type="radio" 
                                          name="syllabusType" 
                                          checked={localSettings.syllabusType === 'DUAL'} 
                                          onChange={() => setLocalSettings({...localSettings, syllabusType: 'DUAL'})}
                                      /> Dual Mode (Both)
                                  </label>
                              </div>
                          </div>

                          <div className="pt-4 border-t border-slate-200 mt-4 relative h-16">
                              <button 
                                  onMouseDown={handleMouseDown}
                                  onClick={() => {
                                      if (isDragging) return;
                                      if (confirm("Force Refresh ALL Students?\nThis will reload their app to apply latest updates.")) {
                                          setLocalSettings({...localSettings, forceRefreshTimestamp: Date.now().toString()});
                                      }
                                  }}
                                  style={{
                                    transform: `translate(${buttonPos.x}px, ${buttonPos.y}px)`,
                                    cursor: isDragging ? 'grabbing' : 'grab',
                                    zIndex: 50,
                                    position: buttonPos.x !== 0 || buttonPos.y !== 0 ? 'fixed' : 'relative',
                                    left: buttonPos.x !== 0 || buttonPos.y !== 0 ? 'auto' : '0',
                                    top: buttonPos.x !== 0 || buttonPos.y !== 0 ? 'auto' : '0',
                                  }}
                                  className={`w-full py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg touch-none select-none ${isDragging ? 'opacity-80' : ''}`}
                              >
                                  ⚠️ Force Update All Apps
                              </button>
                          </div>

                          {/* NEW: POPUP CONTROLS */}
                          <div className="grid grid-cols-2 gap-3 mb-4">
                              <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-slate-200">
                                  <div><p className="font-bold text-slate-700 text-sm">Welcome Popup</p><p className="text-[10px] text-slate-500">Show on startup</p></div>
                                  <input type="checkbox" checked={localSettings.showWelcomePopup !== false} onChange={() => toggleSetting('showWelcomePopup')} className="w-5 h-5 accent-blue-600" />
                              </div>
                              <div className="bg-white p-3 rounded-xl border border-slate-200">
                                  <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">Target Audience</label>
                                  <select 
                                      value={localSettings.welcomePopupTarget || 'ALL'} 
                                      onChange={e => setLocalSettings({...localSettings, welcomePopupTarget: e.target.value as any})}
                                      className="w-full p-2 border rounded-lg text-sm font-bold bg-slate-50"
                                  >
                                      <option value="ALL">Everyone (Free + Ultra)</option>
                                      <option value="FREE_ONLY">Free Users Only</option>
                                      <option value="ULTRA_ONLY">Ultra Users Only</option>
                                  </select>
                              </div>
                              <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-slate-200">
                                  <div><p className="font-bold text-slate-700 text-sm">Terms Popup</p><p className="text-[10px] text-slate-500">Show terms agreement</p></div>
                                  <input type="checkbox" checked={localSettings.showTermsPopup !== false} onChange={() => toggleSetting('showTermsPopup')} className="w-5 h-5 accent-blue-600" />
                              </div>
                          </div>

                          {/* AI & COMPETITION TOGGLES (NEW) */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
                              <div className="flex items-center justify-between bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                                  <div>
                                      <p className="font-bold text-indigo-900 flex items-center gap-2"><Bot size={16}/> Student AI Chat</p>
                                      <p className="text-xs text-indigo-700">Enable AI Tutor for students</p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                      <span className="text-[10px] font-bold text-indigo-400 uppercase">{localSettings.isAiEnabled !== false ? 'Active' : 'Off'}</span>
                                      <input
                                          type="checkbox"
                                          checked={localSettings.isAiEnabled !== false}
                                          onChange={() => toggleSetting('isAiEnabled')}
                                          className="w-5 h-5 accent-indigo-600"
                                      />
                                  </div>
                              </div>

                              <div className="flex items-center justify-between bg-blue-50 p-4 rounded-xl border border-blue-100">
                                  <div>
                                      <p className="font-bold text-blue-900 flex items-center gap-2"><Trophy size={16}/> Competition Mode</p>
                                      <p className="text-xs text-blue-700">Show Competitive Exam section</p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                      <span className="text-[10px] font-bold text-blue-400 uppercase">{localSettings.isCompetitionModeEnabled !== false ? 'Active' : 'Off'}</span>
                                      <input
                                          type="checkbox"
                                          checked={localSettings.isCompetitionModeEnabled !== false}
                                          onChange={() => toggleSetting('isCompetitionModeEnabled')}
                                          className="w-5 h-5 accent-blue-600"
                                      />
                                  </div>
                              </div>

                              {/* 3D MODELS TOGGLE */}
                              <div className="flex items-center justify-between bg-emerald-50 p-4 rounded-xl border border-emerald-100">
                                  <div>
                                      <p className="font-bold text-emerald-900 flex items-center gap-2">3D Models in Notes</p>
                                      <p className="text-xs text-emerald-700">Allow interactive 3D diagrams</p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                      <span className="text-[10px] font-bold text-emerald-500 uppercase">{localSettings.enable3DModels ? 'Active' : 'Off'}</span>
                                      <input
                                          type="checkbox"
                                          checked={localSettings.enable3DModels || false}
                                          onChange={() => toggleSetting('enable3DModels')}
                                          className="w-5 h-5 accent-emerald-600"
                                      />
                                  </div>
                              </div>

                              {/* MCQ MAKER CARD TOGGLE */}
                              <div className="flex items-center justify-between bg-teal-50 p-4 rounded-xl border border-teal-100">
                                  <div>
                                      <p className="font-bold text-teal-900 flex items-center gap-2">MCQ Maker Card (Home)</p>
                                      <p className="text-xs text-teal-700">Show MCQ Maker card on student home page</p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                      <span className="text-[10px] font-bold text-teal-500 uppercase">{localSettings.showMcqMakerCard !== false ? 'Visible' : 'Hidden'}</span>
                                      <input
                                          type="checkbox"
                                          checked={localSettings.showMcqMakerCard !== false}
                                          onChange={() => toggleSetting('showMcqMakerCard')}
                                          className="w-5 h-5 accent-teal-600"
                                      />
                                  </div>
                              </div>

                              {/* HOME RESUME FILTER CHIPS TOGGLE */}
                              <div className="flex items-center justify-between bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                                  <div>
                                      <p className="font-bold text-indigo-900 flex items-center gap-2">📑 Continue Reading Filter Chips</p>
                                      <p className="text-xs text-indigo-700">Show subject filter row (All / Class Notes / Sar Sangrah / Speedy / MCQ) above Home "Continue Reading" card</p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                      <span className="text-[10px] font-bold text-indigo-500 uppercase">{localSettings.showHomeResumeFilter !== false ? 'Visible' : 'Hidden'}</span>
                                      <input
                                          type="checkbox"
                                          checked={localSettings.showHomeResumeFilter !== false}
                                          onChange={() => toggleSetting('showHomeResumeFilter')}
                                          className="w-5 h-5 accent-indigo-600"
                                      />
                                  </div>
                              </div>

                              {/* MCQ MAKER URL */}
                              <div className="bg-teal-50 p-4 rounded-xl border border-teal-100">
                                  <label className="text-[10px] font-bold text-teal-700 uppercase">MCQ Maker App URL</label>
                                  <input
                                      type="text"
                                      value={localSettings.mcqAppUrl || ''}
                                      onChange={e => setLocalSettings({...localSettings, mcqAppUrl: e.target.value})}
                                      placeholder="https://mcq-n3tg.vercel.app/"
                                      className="w-full mt-1 p-2 rounded-lg border border-teal-200 text-sm font-medium"
                                  />
                                  <p className="text-[9px] text-teal-600 mt-1">Loaded inside the MCQ Maker tab. Leave blank to use the default link.</p>
                              </div>
                          </div>

                          <div className="flex items-center justify-between bg-red-50 p-4 rounded-xl border border-red-100">
                              <div><p className="font-bold text-red-800">Maintenance Mode</p><p className="text-xs text-red-600">Lock app for users</p></div>
                              <input type="checkbox" checked={localSettings.maintenanceMode} onChange={() => toggleSetting('maintenanceMode')} className="w-6 h-6 accent-red-600" />
                          </div>
                      </>
                  )}
                  {/* SECURITY */}
                  {activeTab === 'CONFIG_SECURITY' && (
                      <>
                          <div><label className="text-xs font-bold uppercase text-slate-600">Admin Email</label><input type="text" value={localSettings.adminEmail || ''} onChange={e => setLocalSettings({...localSettings, adminEmail: e.target.value})} className="w-full p-3 border rounded-xl" /></div>
                          <div><label className="text-xs font-bold uppercase text-slate-600">Admin Login Code</label><input type="text" value={localSettings.adminCode || ''} onChange={e => setLocalSettings({...localSettings, adminCode: e.target.value})} className="w-full p-3 border rounded-xl" /></div>
                      </>
                  )}
                  {/* VISIBILITY */}
                  {activeTab === 'CONFIG_VISIBILITY' && (
                      <div className="space-y-4">
                          <div>
                              <p className="font-bold text-slate-700 mb-2">Allowed Classes</p>
                              <div className="flex flex-wrap gap-2">
                                  {['6','7','8','9','10','11','12'].map(c => (
                                      <button key={c} onClick={() => setLocalSettings({...localSettings, allowedClasses: toggleItemInList(localSettings.allowedClasses, c as any)})} className={`px-4 py-2 rounded-lg border font-bold ${localSettings.allowedClasses?.includes(c as any) ? 'bg-blue-600 text-white' : 'bg-white'}`}>{c}</button>
                                  ))}
                              </div>
                          </div>

                          <div>
                              <p className="font-bold text-slate-700 mb-2">Content Visibility</p>
                              <div className="flex gap-4 flex-wrap">
                                  {['VIDEO', 'PDF', 'MCQ', 'AUDIO'].map(type => (
                                      <label key={type} className="flex items-center gap-2 bg-white p-3 rounded-lg border border-slate-200 cursor-pointer hover:border-blue-300">
                                          <input
                                              type="checkbox"
                                              // @ts-ignore
                                              checked={localSettings.contentVisibility?.[type] !== false}
                                              onChange={() => {
                                                  const current = localSettings.contentVisibility || {};
                                                  // @ts-ignore
                                                  const isVisible = current[type] !== false;
                                                  // @ts-ignore
                                                  setLocalSettings({...localSettings, contentVisibility: { ...current, [type]: !isVisible }});
                                              }}
                                              className="w-5 h-5 accent-blue-600"
                                          />
                                          <span className="text-xs font-bold text-slate-600">{type}</span>
                                      </label>
                                  ))}
                              </div>
                          </div>

                          <div className="bg-orange-50 p-4 rounded-xl border border-orange-200 mt-4">
                              <div className="flex justify-between items-center">
                                  <div>
                                      <p className="font-bold text-orange-900 text-sm">Hide Topic Notes Globally</p>
                                      <p className="text-xs text-orange-700">If ON, the "Topic Notes" section will be completely hidden from students in the course view.</p>
                                  </div>
                                  <label className="relative inline-flex items-center cursor-pointer">
                                      <input
                                          type="checkbox"
                                          checked={localSettings.areTopicNotesHiddenGlobally || false}
                                          onChange={() => setLocalSettings({...localSettings, areTopicNotesHiddenGlobally: !localSettings.areTopicNotesHiddenGlobally})}
                                          className="sr-only peer"
                                      />
                                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                                  </label>
                              </div>
                          </div>
                      </div>
                  )}
                  {/* AI & ADS & PAYMENT */}
                  {activeTab === 'CONFIG_AI' && (
                    <div className="space-y-6">
                      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                          <Bot className="w-5 h-5 text-blue-500" />
                          AI Provider & Key Management
                        </h3>
                        
                        <div className="space-y-6">
                          {/* Groq Keys Section */}
                          <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                            <h4 className="font-bold text-gray-700 dark:text-gray-300 mb-3 flex items-center justify-between">
                              Groq Cloud API Keys (Tier A)
                              <span className="text-xs font-normal text-slate-600">Add up to 10 keys for rotation</span>
                            </h4>
                            <div className="flex gap-2 mb-4">
                              <input 
                                type="password" 
                                value={newSecureKey} 
                                onChange={e => setNewSecureKey(e.target.value)}
                                placeholder="Paste Groq API Key (gsk_...)"
                                className="flex-1 p-2 border rounded-lg text-sm font-mono"
                              />
                              <button 
                                onClick={async () => {
                                  if (!newSecureKey.trim()) return;
                                  const currentKeys = localSettings.groqApiKeys || [];
                                  if (currentKeys.length >= 10) {
                                    alert("Limit of 10 keys reached for Groq.");
                                    return;
                                  }
                                  const newKeys = [...currentKeys, newSecureKey.trim()];
                                  const newSettings = { ...localSettings, groqApiKeys: newKeys };
                                  setLocalSettings(newSettings);
                                  await saveSystemSettings(newSettings);
                                  setNewSecureKey('');
                                }}
                                className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700"
                              >
                                Add Key
                              </button>
                            </div>
                            
                            <div className="space-y-2">
                              {(localSettings.groqApiKeys || []).map((key, idx) => (
                                <div key={idx} className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 border rounded-lg text-sm font-mono">
                                  <div className="flex items-center gap-2">
                                    <Key className="w-3 h-3 text-slate-500" />
                                    <span>{key.substring(0, 10)}...{key.substring(key.length - 4)}</span>
                                    {keyStatus[idx] && (
                                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${keyStatus[idx] === 'Valid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {keyStatus[idx]}
                                      </span>
                                    )}
                                  </div>
                                  <button 
                                    onClick={async () => {
                                      const newKeys = (localSettings.groqApiKeys || []).filter((_, i) => i !== idx);
                                      const newSettings = { ...localSettings, groqApiKeys: newKeys };
                                      setLocalSettings(newSettings);
                                      await saveSystemSettings(newSettings);
                                    }}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              ))}
                              {(!localSettings.groqApiKeys || localSettings.groqApiKeys.length === 0) && (
                                <p className="text-center text-xs text-slate-600 py-4">No API keys added yet.</p>
                              )}
                            </div>
                          </div>

                          <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                            <h4 className="font-bold text-gray-700 dark:text-gray-300 mb-3 flex items-center justify-between">
                              Gemini API Keys (Tier B)
                              <div className="flex flex-col items-end">
                                <span className="text-xs font-normal text-slate-600">Google Gemini Pro/Flash</span>
                                <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-[10px] text-blue-500 hover:underline">Get API Key ↗</a>
                              </div>
                            </h4>
                            <p className="text-[10px] text-slate-500 mb-2">Keys added here are rotated automatically. You can also set <code>GEMINI_API_KEYS</code> in Vercel Env (comma-separated) as a backup.</p>
                            <div className="flex gap-2 mb-4">
                              <input
                                type="password"
                                value={newGeminiKey}
                                onChange={e => setNewGeminiKey(e.target.value)}
                                placeholder="Paste Gemini API Key (AIza...)"
                                className="flex-1 p-2 border rounded-lg text-sm font-mono"
                              />
                              <button
                                onClick={async () => {
                                  if (!newGeminiKey.trim()) return;
                                  const currentKeys = localSettings.geminiApiKeys || [];
                                  if (currentKeys.length >= 10) {
                                    alert("Limit of 10 keys reached for Gemini.");
                                    return;
                                  }
                                  const newKeys = [...currentKeys, newGeminiKey.trim()];
                                  const newSettings = { ...localSettings, geminiApiKeys: newKeys };
                                  setLocalSettings(newSettings);
                                  await saveSystemSettings(newSettings);
                                  // Sync to secure_keys/gemini for persistence
                                  set(ref(rtdb, 'secure_keys/gemini'), newKeys);
                                  setNewGeminiKey('');
                                }}
                                className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700"
                              >
                                Add Key
                              </button>
                            </div>

                            <div className="space-y-2">
                              {(localSettings.geminiApiKeys || []).map((key, idx) => (
                                <div key={idx} className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 border rounded-lg text-sm font-mono">
                                  <div className="flex items-center gap-2">
                                    <Key className="w-3 h-3 text-slate-500" />
                                    <span>{key.substring(0, 10)}...{key.substring(key.length - 4)}</span>
                                  </div>
                                  <button
                                    onClick={async () => {
                                      const newKeys = (localSettings.geminiApiKeys || []).filter((_, i) => i !== idx);
                                      const newSettings = { ...localSettings, geminiApiKeys: newKeys };
                                      setLocalSettings(newSettings);
                                      await saveSystemSettings(newSettings);
                                      set(ref(rtdb, 'secure_keys/gemini'), newKeys);
                                    }}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              ))}
                              {(!localSettings.geminiApiKeys || localSettings.geminiApiKeys.length === 0) && (
                                <p className="text-center text-xs text-slate-600 py-4">No Gemini keys added yet.</p>
                              )}
                            </div>
                          </div>

                          {/* Other Providers Placeholder */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             {['OpenAI', 'Claude', 'OpenRouter', 'DeepSeek', 'Mistral'].map(provider => (
                               <div key={provider} className="p-4 border rounded-xl opacity-50 cursor-not-allowed bg-gray-50">
                                 <div className="flex items-center justify-between mb-2">
                                   <span className="font-bold text-sm">{provider}</span>
                                   <Lock className="w-3 h-3" />
                                 </div>
                                 <div className="h-2 bg-gray-200 rounded-full w-full"></div>
                               </div>
                             ))}
                          </div>
                        </div>
                      </div>

                      {/* System Prompt Settings */}
                      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                          <Code2 className="w-5 h-5 text-indigo-500" />
                          Global AI Instructions
                        </h3>
                        <textarea 
                          value={localSettings.aiInstruction || ''} 
                          onChange={e => setLocalSettings({...localSettings, aiInstruction: e.target.value})}
                          className="w-full p-4 border rounded-xl h-32 text-sm font-mono bg-gray-50 dark:bg-gray-900"
                          placeholder="You are an expert teacher helping Bihar Board students..."
                        />
                        <div className="mt-4 flex justify-end">
                           <button 
                            onClick={() => saveSystemSettings(localSettings)}
                            className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 shadow-md"
                           >
                             Save AI Config
                           </button>
                        </div>
                      </div>
                    </div>
                  )}
                  {activeTab === 'CONFIG_PAYMENT' && (
                       <>
                          <div className="flex items-center justify-between bg-emerald-50 p-4 rounded-xl border border-emerald-100 mb-6">
                              <div><p className="font-bold text-emerald-800">Enable Payments</p><p className="text-xs text-emerald-600">Show buy options to students</p></div>
                              <input type="checkbox" checked={localSettings.isPaymentEnabled} onChange={() => toggleSetting('isPaymentEnabled')} className="w-6 h-6 accent-emerald-600" />
                          </div>

                          {/* DISCOUNT EVENT MANAGER */}
                          <div className="bg-gradient-to-r from-pink-50 to-rose-50 p-4 rounded-xl border border-pink-200 mb-6">
                              <h4 className="font-bold text-pink-900 mb-4 flex items-center gap-2"><Ticket size={18} /> Discount Event Manager</h4>

                              <div className="flex items-center justify-between bg-white p-3 rounded-lg border border-pink-100 mb-4">
                                  <div>
                                      <p className="font-bold text-slate-800">Event Status</p>
                                      <p className="text-xs text-slate-600">
                                        {localSettings.specialDiscountEvent?.enabled 
                                          ? (new Date(localSettings.specialDiscountEvent.startsAt || Date.now()) > new Date() 
                                              ? `Waiting to start: ${new Date(localSettings.specialDiscountEvent.startsAt!).toLocaleString()}` 
                                              : (localSettings.specialDiscountEvent.startsAt === localSettings.specialDiscountEvent.endsAt ? 'Active Indefinitely' : `Active until ${new Date(localSettings.specialDiscountEvent.endsAt || '').toLocaleString()}`))
                                          : 'Inactive'}
                                      </p>
                                  </div>
                                  <button
                                      onClick={async () => {
                                          const startsAt = calculateStartTime();
                                          const endsAt = calculateEndTimeFromStart(startsAt);
                                          const updated = {
                                              ...localSettings,
                                              specialDiscountEvent: {
                                                  ...(localSettings.specialDiscountEvent || { eventName: 'Flash Sale', discountPercent: 20, showToFreeUsers: true, showToPremiumUsers: false }),
                                                  enabled: !localSettings.specialDiscountEvent?.enabled,
                                                  startsAt: !localSettings.specialDiscountEvent?.enabled ? startsAt : undefined,
                                                  endsAt: !localSettings.specialDiscountEvent?.enabled ? endsAt : undefined,
                                                  cooldownSettings: {
                                                    years: cdYears, months: cdMonths, days: cdDays,
                                                    hours: cdHours, minutes: cdMinutes, seconds: cdSeconds
                                                  },
                                                  duration: {
                                                    years: eventYears, months: eventMonths, days: eventDays,
                                                    hours: eventHours, minutes: eventMinutes, seconds: eventSeconds
                                                  }
                                              }
                                          };
                                          setLocalSettings(updated);
                                          await saveSystemSettings(updated);
                                          alert(`Event ${updated.specialDiscountEvent?.enabled ? 'Started' : 'Stopped'} Successfully!`);
                                      }}
                                      className={`px-4 py-2 rounded-lg font-bold text-xs ${localSettings.specialDiscountEvent?.enabled ? 'bg-pink-600 text-white' : 'bg-slate-200 text-slate-600'}`}
                                  >
                                      {localSettings.specialDiscountEvent?.enabled ? 'Stop Event' : 'Start Event'}
                                  </button>
                              </div>

                              <div className="space-y-6">
                                  {/* Cooldown Timer Setup */}
                                  <div className="bg-white/50 p-3 rounded-lg border border-pink-100">
                                      <label className="text-[10px] font-black text-pink-700 uppercase mb-2 block">Cool Down (Time until Start)</label>
                                      <div className="grid grid-cols-6 gap-2">
                                          {[
                                            {label: 'YY', val: cdYears, set: setCdYears},
                                            {label: 'MM', val: cdMonths, set: setCdMonths},
                                            {label: 'DD', val: cdDays, set: setCdDays},
                                            {label: 'HH', val: cdHours, set: setCdHours},
                                            {label: 'MIN', val: cdMinutes, set: setCdMinutes},
                                            {label: 'SEC', val: cdSeconds, set: setCdSeconds}
                                          ].map(t => (
                                            <div key={t.label}>
                                              <input type="number" value={t.val} onChange={e => t.set(Number(e.target.value))} className="w-full p-1 text-center border rounded text-xs font-bold bg-slate-800 text-white" />
                                              <p className="text-[8px] text-center font-bold text-slate-500 mt-1">{t.label}</p>
                                            </div>
                                          ))}
                                      </div>
                                  </div>

                                  {/* Event Duration Setup */}
                                  <div className="bg-white/50 p-3 rounded-lg border border-pink-100">
                                      <label className="text-[10px] font-black text-pink-700 uppercase mb-2 block">Event Duration (How long it lasts)</label>
                                      <div className="grid grid-cols-6 gap-2">
                                          {[
                                            {label: 'YY', val: eventYears, set: setEventYears},
                                            {label: 'MM', val: eventMonths, set: setEventMonths},
                                            {label: 'DD', val: eventDays, set: setEventDays},
                                            {label: 'HH', val: eventHours, set: setEventHours},
                                            {label: 'MIN', val: eventMinutes, set: setEventMinutes},
                                            {label: 'SEC', val: eventSeconds, set: setEventSeconds}
                                          ].map(t => (
                                            <div key={t.label}>
                                              <input type="number" value={t.val} onChange={e => t.set(Number(e.target.value))} className="w-full p-1 text-center border rounded text-xs font-bold bg-slate-800 text-white" />
                                              <p className="text-[8px] text-center font-bold text-slate-500 mt-1">{t.label}</p>
                                            </div>
                                          ))}
                                      </div>
                                  </div>
                              </div>

                              {localSettings.specialDiscountEvent?.enabled && (
                                  <div className="space-y-4 animate-in fade-in">
                                      <div>
                                          <label className="text-xs font-bold text-pink-700 uppercase">Event Name</label>
                                          <input
                                              type="text"
                                              value={localSettings.specialDiscountEvent?.eventName || ''}
                                              onChange={(e) => setLocalSettings({
                                                  ...localSettings,
                                                  specialDiscountEvent: { ...localSettings.specialDiscountEvent, eventName: e.target.value } as any
                                              })}
                                              className="w-full p-2 border border-pink-200 rounded-lg text-sm font-bold"
                                              placeholder="e.g. Diwali Dhamaka"
                                          />
                                      </div>
                                      
                                      <div className="grid grid-cols-2 gap-3">
                                          <div>
                                              <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">Standard Discount %</label>
                                              <input 
                                                  type="number" 
                                                  value={localSettings.specialDiscountEvent?.discountPercent || 0}
                                                  onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: { ...localSettings.specialDiscountEvent, discountPercent: Number(e.target.value) } as any})}
                                                  className="w-full p-2 border rounded-lg text-sm font-bold"
                                              />
                                          </div>

                                          <div>
                                              <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">Renewal Extra % (Existing Users)</label>
                                              <input 
                                                  type="number" 
                                                  value={localSettings.specialDiscountEvent?.renewalDiscountPercent || 0}
                                                  onChange={e => setLocalSettings({...localSettings, specialDiscountEvent: { ...localSettings.specialDiscountEvent, renewalDiscountPercent: Number(e.target.value) } as any})}
                                                  className="w-full p-2 border rounded-lg text-sm font-bold"
                                              />
                                          </div>
                                      </div>

                              <div className="flex gap-4">
                                   <label className="flex items-center gap-2 text-xs font-bold text-slate-600">
                                       <input 
                                          type="checkbox" 
                                          checked={localSettings.specialDiscountEvent?.showToFreeUsers || false}
                                          onChange={(e) => setLocalSettings({
                                              ...localSettings,
                                              specialDiscountEvent: { ...localSettings.specialDiscountEvent, showToFreeUsers: e.target.checked } as any
                                          })}
                                          className="accent-pink-600"
                                       /> Show to Free Users
                                   </label>
                                   <label className="flex items-center gap-2 text-xs font-bold text-slate-600">
                                       <input 
                                          type="checkbox" 
                                          checked={localSettings.specialDiscountEvent?.showToPremiumUsers || false}
                                          onChange={(e) => setLocalSettings({
                                              ...localSettings,
                                              specialDiscountEvent: { ...localSettings.specialDiscountEvent, showToPremiumUsers: e.target.checked } as any
                                          })}
                                          className="accent-pink-600"
                                       /> Show to Premium Users
                                   </label>
                              </div>
                              <div className="mt-4 p-3 bg-blue-50 border border-blue-100 rounded-lg">
                                <p className="text-[10px] text-blue-800 font-bold uppercase mb-1">Advanced Timer Settings</p>
                                <p className="text-[9px] text-blue-600 mb-2">Set exactly when the discount appears and how long it lasts.</p>
                                <div className="grid grid-cols-2 gap-2">
                                  <button onClick={() => {
                                    const startsAt = calculateStartTime();
                                    const endsAt = calculateEndTimeFromStart(startsAt);
                                    const updated = {
                                      ...localSettings,
                                      specialDiscountEvent: {
                                        ...localSettings.specialDiscountEvent,
                                        startsAt,
                                        endsAt
                                      } as any
                                    };
                                    setLocalSettings(updated);
                                    saveSystemSettings(updated);
                                    alert(`Event Scheduled!\nStart: ${new Date(startsAt).toLocaleString()}\nEnd: ${new Date(endsAt).toLocaleString()}`);
                                  }} className="p-2 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-wider">Update Timer Values</button>
                                  <button onClick={() => {
                                    setEventYears(0); setEventMonths(0); setEventDays(0); setEventHours(0); setEventMinutes(0); setEventSeconds(0);
                                    setCdYears(0); setCdMonths(0); setCdDays(0); setCdHours(0); setCdMinutes(0); setCdSeconds(0);
                                  }} className="p-2 bg-slate-200 text-slate-700 rounded-lg text-[10px] font-black uppercase tracking-wider">Reset Inputs</button>
                                </div>
                              </div>
                                  </div>
                              )}
                          </div>

                          {/* PAYMENT NUMBERS MANAGER */}
                          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm mb-6">
                              <h4 className="font-bold text-slate-800 flex items-center gap-2 mb-4"><MessageSquare size={18} className="text-green-600" /> WhatsApp Support Numbers</h4>
                              <p className="text-xs text-slate-600 mb-4">Add multiple numbers to distribute student traffic. Maximum 1000 users per day per number is recommended.</p>
                              
                              <div className="space-y-3 mb-4">
                                  {localSettings.paymentNumbers?.map((num, idx) => (
                                      <div key={num.id} className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-200">
                                          <div>
                                              <p className="font-bold text-sm text-slate-800">{num.name}</p>
                                              <p className="text-xs text-slate-600 font-mono">{num.number}</p>
                                          </div>
                                          <div className="flex items-center gap-4">
                                              <div className="text-right">
                                                  <p className="text-xs font-bold text-slate-500 uppercase">Traffic</p>
                                                  <div className="flex items-center gap-1">
                                                       <p className="font-black text-green-600">{num.dailyClicks || 0}</p>
                                                       <button 
                                                           onClick={() => {
                                                               const updated = [...(localSettings.paymentNumbers || [])];
                                                               updated[idx].dailyClicks = 0;
                                                               setLocalSettings({...localSettings, paymentNumbers: updated});
                                                           }}
                                                           className="text-[9px] text-slate-500 underline hover:text-slate-600 ml-1"
                                                       >
                                                           Reset
                                                       </button>
                                                  </div>
                                              </div>
                                              <button 
                                                  onClick={() => {
                                                      const updated = localSettings.paymentNumbers!.filter((_, i) => i !== idx);
                                                      setLocalSettings({...localSettings, paymentNumbers: updated});
                                                  }}
                                                  className="text-red-400 hover:text-red-600 p-2"
                                              >
                                                  <Trash2 size={16} />
                                              </button>
                                          </div>
                                      </div>
                                  ))}
                              </div>

                              <div className="flex gap-2">
                                  <input type="text" id="newPayName" placeholder="Name (e.g. Sales 1)" className="flex-1 p-2 border rounded-lg text-sm" />
                                  <input type="text" id="newPayNum" placeholder="Number (9199...)" className="flex-1 p-2 border rounded-lg text-sm" />
                                  <button 
                                      onClick={() => {
                                          const name = (document.getElementById('newPayName') as HTMLInputElement).value;
                                          const num = (document.getElementById('newPayNum') as HTMLInputElement).value;
                                          if(name && num) {
                                              const newEntry = {
                                                  id: `pay-${Date.now()}`,
                                                  name,
                                                  number: num,
                                                  dailyClicks: 0,
                                                  lastResetDate: new Date().toDateString()
                                              };
                                              setLocalSettings({...localSettings, paymentNumbers: [...(localSettings.paymentNumbers || []), newEntry]});
                                              (document.getElementById('newPayName') as HTMLInputElement).value = '';
                                              (document.getElementById('newPayNum') as HTMLInputElement).value = '';
                                          }
                                      }}
                                      className="bg-green-600 text-white px-4 rounded-lg font-bold text-xs"
                                  >
                                      Add Number
                                  </button>
                              </div>
                          </div>
                          
                          {/* CONTENT ACCESS PRICING */}
                          <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200 mb-6">
                              <h4 className="font-bold text-indigo-900 mb-4 flex items-center gap-2"><Banknote size={18} /> Content Access Pricing (Credits)</h4>
                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                      <label className="text-xs font-bold text-indigo-700 uppercase block mb-1">Deep Dive Notes Cost</label>
                                      <input
                                          type="number"
                                          value={localSettings.deepDiveCost !== undefined ? localSettings.deepDiveCost : 5}
                                          onChange={e => setLocalSettings({...localSettings, deepDiveCost: Number(e.target.value)})}
                                          className="w-full p-2 border border-indigo-200 rounded-lg font-bold text-indigo-900"
                                      />
                                  </div>
                                  <div>
                                      <label className="text-xs font-bold text-indigo-700 uppercase block mb-1">Audio Slide Cost</label>
                                      <input
                                          type="number"
                                          value={localSettings.audioSlideCost !== undefined ? localSettings.audioSlideCost : 10}
                                          onChange={e => setLocalSettings({...localSettings, audioSlideCost: Number(e.target.value)})}
                                          className="w-full p-2 border border-indigo-200 rounded-lg font-bold text-indigo-900"
                                      />
                                  </div>
                              </div>
                          </div>

                          {/* PACKAGE MANAGER */}
                          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mt-4">
                              <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><ShoppingBag size={18} /> Store Packages Manager</h4>
                              
                              <div className="grid gap-3 mb-6">
                                  {(!localSettings.packages || localSettings.packages.length === 0) && <p className="text-xs text-slate-500">No packages defined. Default list will be shown to users.</p>}
                                  {localSettings.packages?.map(pkg => (
                                      <div key={pkg.id} className="flex justify-between items-center bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                                          <div>
                                              <p className="font-bold text-sm text-slate-800">{pkg.name}</p>
                                              <div className="text-xs text-slate-600">
    <span className="line-through text-slate-500 mr-2">{pkg.dummyPrice ? `₹${pkg.dummyPrice}` : ''}</span>
    <span className="font-bold text-green-600">₹{pkg.price}</span> = {pkg.credits} Credits
</div>
                                          </div>
                                          <button onClick={() => removePackage(pkg.id)} className="text-red-400 hover:text-red-600 p-2"><Trash2 size={16} /></button>
                                      </div>
                                  ))}
                              </div>

                              <div className="flex gap-2 items-end">
                                  <div className="flex-1">
                                      <label className="text-[10px] font-bold uppercase text-slate-500">Name</label>
                                      <input type="text" placeholder="Pro Pack" value={newPkgName} onChange={e => setNewPkgName(e.target.value)} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <div className="w-20">
                                      <label className="text-[10px] font-bold uppercase text-slate-500">Price (₹)</label>
                                      <input type="number" placeholder="99" value={newPkgPrice} onChange={e => setNewPkgPrice(e.target.value)} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <div className="w-20">
                                      <label className="text-[10px] font-bold uppercase text-slate-500">Credits</label>
                                      <input type="number" placeholder="50" value={newPkgCredits} onChange={e => setNewPkgCredits(e.target.value)} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <button onClick={addPackage} className="bg-emerald-600 text-white p-2 rounded-lg h-[38px] w-[38px] flex items-center justify-center hover:bg-emerald-700 shadow"><Plus size={20} /></button>
                              </div>
                          </div>
                       </>
                  )}

                  {activeTab === 'CONFIG_ADS' && (
                       <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                           <div className="flex items-center justify-between mb-4">
                               <span className="font-bold">Startup Popup Ad</span>
                               <input type="checkbox" checked={localSettings.startupAd?.enabled} onChange={() => setLocalSettings({...localSettings, startupAd: {...localSettings.startupAd!, enabled: !localSettings.startupAd?.enabled}})} className="w-5 h-5 accent-blue-600" />
                           </div>
                           <input type="text" value={localSettings.startupAd?.title} onChange={e => setLocalSettings({...localSettings, startupAd: {...localSettings.startupAd!, title: e.target.value}})} className="w-full p-2 border rounded mb-2" placeholder="Ad Title" />
                           <div className="grid grid-cols-2 gap-2">
                               <input type="color" value={localSettings.startupAd?.bgColor} onChange={e => setLocalSettings({...localSettings, startupAd: {...localSettings.startupAd!, bgColor: e.target.value}})} className="w-full h-10 p-1 border rounded" />
                               <input type="color" value={localSettings.startupAd?.textColor} onChange={e => setLocalSettings({...localSettings, startupAd: {...localSettings.startupAd!, textColor: e.target.value}})} className="w-full h-10 p-1 border rounded" />
                           </div>
                       </div>
                  )}
                  {activeTab === 'CONFIG_GAME' && (
                       <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
                           <h4 className="font-bold text-slate-800 flex items-center gap-2"><Gamepad2 size={18} /> Spin Wheel Configuration</h4>
                           
                           <div>
                               <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Game Cost (Credits)</label>
                               <input type="number" value={localSettings.gameCost} onChange={e => setLocalSettings({...localSettings, gameCost: Number(e.target.value)})} className="w-full p-2 border rounded-lg" />
                               <p className="text-[10px] text-slate-500">Set 0 for free entry within daily limits.</p>
                           </div>

                           <div className="grid grid-cols-3 gap-4 pt-2 border-b border-slate-200 pb-4">
                               <div>
                                   <label className="text-xs font-bold text-purple-600 uppercase block mb-1">Ultra Limit</label>
                                   <input type="number" value={localSettings.spinLimitUltra} onChange={e => setLocalSettings({...localSettings, spinLimitUltra: Number(e.target.value)})} className="w-full p-2 border border-purple-200 bg-purple-50 rounded-lg font-bold" />
                                   <p className="text-[9px] text-slate-500">Real Users</p>
                               </div>
                               <div>
                                   <label className="text-xs font-bold text-blue-600 uppercase block mb-1">Basic Limit</label>
                                   <input type="number" value={localSettings.spinLimitBasic} onChange={e => setLocalSettings({...localSettings, spinLimitBasic: Number(e.target.value)})} className="w-full p-2 border border-blue-200 bg-blue-50 rounded-lg font-bold" />
                                   <p className="text-[9px] text-slate-500">Real Users</p>
                               </div>
                               <div>
                                   <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Normal/Free</label>
                                   <input type="number" value={localSettings.spinLimitFree} onChange={e => setLocalSettings({...localSettings, spinLimitFree: Number(e.target.value)})} className="w-full p-2 border border-slate-200 bg-white rounded-lg font-bold" />
                                   <p className="text-[9px] text-slate-500">Others</p>
                               </div>
                           </div>

                           {/* PRIZE CONFIGURATION */}
                           <div>
                               <h5 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
                                   <Gift size={16} /> Prize Wheel Items
                               </h5>
                               
                               {/* List of current prizes */}
                               <div className="space-y-2 mb-4 max-h-40 overflow-y-auto">
                                   {(localSettings.wheelRewards || []).map((reward: any, idx: number) => {
                                       // Normalize for display
                                       const r = typeof reward === 'number' ? { id: idx, type: 'COINS', value: reward, label: `${reward} CR` } : reward;
                                       return (
                                           <div key={r.id || idx} className="flex justify-between items-center bg-white p-2 rounded-lg border border-slate-200 shadow-sm">
                                               <div className="flex items-center gap-2">
                                                   <div className="w-4 h-4 rounded-full" style={{backgroundColor: r.color || '#ccc'}}></div>
                                                   <span className="text-xs font-bold text-slate-700">{r.label}</span>
                                                   <span className="text-[10px] bg-slate-100 px-1 rounded text-slate-600 font-mono">{r.type}</span>
                                               </div>
                                               <button onClick={() => {
                                                   const updated = [...(localSettings.wheelRewards || [])];
                                                   updated.splice(idx, 1);
                                                   setLocalSettings({...localSettings, wheelRewards: updated});
                                               }} className="text-red-400 hover:text-red-600"><Trash2 size={14} /></button>
                                           </div>
                                       );
                                   })}
                               </div>

                               {/* Add New Prize Form */}
                               <div className="bg-white p-3 rounded-lg border border-slate-200">
                                   <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">Add New Prize</p>
                                   <div className="grid grid-cols-2 gap-2 mb-2">
                                       <select 
                                           value={newReward.type} 
                                           onChange={e => setNewReward({...newReward, type: e.target.value as any})}
                                           className="p-2 border rounded text-xs bg-slate-50"
                                       >
                                           <option value="COINS">Coins</option>
                                           <option value="SUBSCRIPTION">Subscription</option>
                                       </select>
                                       
                                       {newReward.type === 'COINS' ? (
                                           <input type="number" placeholder="Amount" value={newReward.value} onChange={e => setNewReward({...newReward, value: Number(e.target.value), label: `${e.target.value} Coins`})} className="p-2 border rounded text-xs" />
                                       ) : (
                                           <select 
                                               value={String(newReward.value)} 
                                               onChange={e => setNewReward({...newReward, value: e.target.value, label: e.target.value.toString().replace('_', ' ')})}
                                               className="p-2 border rounded text-xs"
                                           >
                                               <option value="WEEKLY_BASIC">Weekly Basic</option>
                                               <option value="MONTHLY_ULTRA">Monthly Ultra</option>
                                               <option value="YEARLY_ULTRA">Yearly Ultra</option>
                                           </select>
                                       )}
                                   </div>
                                   <div className="grid grid-cols-2 gap-2 mb-2">
                                       <input type="text" placeholder="Label (Display Name)" value={newReward.label} onChange={e => setNewReward({...newReward, label: e.target.value})} className="p-2 border rounded text-xs" />
                                       <div className="flex items-center gap-2 border rounded p-1">
                                            <input type="color" value={newReward.color} onChange={e => setNewReward({...newReward, color: e.target.value})} className="w-8 h-6 p-0 border-0 rounded" />
                                            <span className="text-[10px] text-slate-500">{newReward.color}</span>
                                       </div>
                                   </div>
                                   <button 
                                       onClick={() => {
                                           const item = { ...newReward, id: `rew-${Date.now()}` };
                                           // Cast to any to avoid type conflict with number[] legacy
                                           setLocalSettings({ ...localSettings, wheelRewards: [...(localSettings.wheelRewards || []), item] });
                                       }}
                                       className="w-full py-2 bg-indigo-600 text-white font-bold rounded-lg text-xs hover:bg-indigo-700"
                                   >
                                       + Add Prize
                                   </button>
                               </div>
                           </div>
                       </div>
                  )}
                  {activeTab === 'CONFIG_EXTERNAL_APPS' && (
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                          <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Globe size={18} /> Manage External Apps</h4>
                          <p className="text-xs text-slate-600 mb-4">Add up to 20 apps/websites. These will appear in the Student Dashboard.</p>
                          
                          <div className="space-y-3 mb-6">
                              {(localSettings.externalApps || []).map((app, idx) => (
                                  <div key={app.id} className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-2">
                                      <div className="flex justify-between items-start">
                                          <span className="font-bold text-sm text-slate-800">{app.name}</span>
                                          <button onClick={() => {
                                              const updated = localSettings.externalApps!.filter((_, i) => i !== idx);
                                              setLocalSettings({...localSettings, externalApps: updated});
                                          }} className="text-red-400 hover:text-red-600"><Trash2 size={16} /></button>
                                      </div>
                                      <p className="text-[10px] text-blue-600 truncate">{app.url}</p>
                                      
                                      <div className="flex gap-2 text-xs items-center">
                                          <label className="flex items-center gap-1 font-bold text-slate-600">
                                              <input 
                                                  type="checkbox" 
                                                  checked={app.isLocked} 
                                                  onChange={e => {
                                                      const updated = localSettings.externalApps!.map((a, i) => i === idx ? { ...a, isLocked: e.target.checked } : a);
                                                      setLocalSettings({...localSettings, externalApps: updated});
                                                  }} 
                                              /> Lock
                                          </label>
                                          <div className="flex items-center gap-1 ml-auto">
                                              <span className="font-bold text-slate-600">Price:</span>
                                              <input 
                                                  type="number" 
                                                  value={app.creditCost} 
                                                  onChange={e => {
                                                      const updated = localSettings.externalApps!.map((a, i) => i === idx ? { ...a, creditCost: Number(e.target.value) } : a);
                                                      setLocalSettings({...localSettings, externalApps: updated});
                                                  }} 
                                                  className="w-16 p-1 border rounded text-center font-bold"
                                              />
                                          </div>
                                      </div>
                                  </div>
                              ))}
                          </div>

                          {(localSettings.externalApps?.length || 0) < 20 && (
                              <button 
                                  onClick={() => {
                                      const newApp = {
                                          id: `app-${Date.now()}`,
                                          name: 'New App',
                                          url: 'https://google.com',
                                          isLocked: false,
                                          creditCost: 0
                                      };
                                      setLocalSettings({...localSettings, externalApps: [...(localSettings.externalApps || []), newApp]});
                                  }}
                                  className="w-full py-2 bg-indigo-100 text-indigo-700 font-bold rounded-xl border border-indigo-200 hover:bg-indigo-200 dashed"
                              >
                                  + Add App Slot
                              </button>
                          )}
                          
                          {(localSettings.externalApps || []).length > 0 && (
                              <div className="mt-4 p-3 bg-yellow-50 rounded-xl border border-yellow-100 text-xs text-yellow-800">
                                  <strong>Edit Names/URLs:</strong> Edit the display names and destination links for your external app slots.
                              </div>
                          )}
                          
                          {(localSettings.externalApps || []).map((app, idx) => (
                              <div key={`edit-${app.id}`} className="mt-2 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                      <div>
                                          <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">App Display Name</label>
                                          <input 
                                              type="text" 
                                              value={app.name} 
                                              onChange={e => {
                                                   const updated = localSettings.externalApps!.map((a, i) => i === idx ? { ...a, name: e.target.value } : a);
                                                   setLocalSettings({...localSettings, externalApps: updated});
                                              }} 
                                              className="w-full p-2 border border-slate-200 rounded-lg text-sm font-bold focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none" 
                                              placeholder="e.g. Google Drive"
                                          />
                                      </div>
                                      <div>
                                          <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">App URL (HTTPS)</label>
                                          <input 
                                              type="text" 
                                              value={app.url} 
                                              onChange={e => {
                                                   const updated = localSettings.externalApps!.map((a, i) => i === idx ? { ...a, url: e.target.value } : a);
                                                   setLocalSettings({...localSettings, externalApps: updated});
                                              }} 
                                              className="w-full p-2 border border-slate-200 rounded-lg text-sm font-mono text-blue-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none" 
                                              placeholder="https://..."
                                          />
                                      </div>
                                  </div>
                              </div>
                          ))}

                          <div className="mt-6">
                              <button
                                  onClick={handleSaveSettings}
                                  disabled={isSettingsSaving}
                                  className={`w-full py-4 text-white font-black rounded-xl text-lg shadow-xl shadow-green-500/20 flex items-center justify-center gap-3 transition-all hover:-translate-y-1 active:scale-95 ${isSettingsSaving ? 'bg-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500'}`}
                              >
                                  {isSettingsSaving ? (
                                      <>
                                          <div className="w-5 h-5 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                                          Saving Configuration...
                                      </>
                                  ) : (
                                      <>
                                          <Save size={24} />
                                          Save External Apps
                                      </>
                                  )}
                              </button>
                          </div>
                      </div>
                  )}
                  {activeTab === 'CONFIG_APP_STORE' && (
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                          <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2"><ShoppingBag size={18} /> App Store Page</h4>
                          <p className="text-xs text-slate-600 mb-4">Add download links (Play Store, Google Drive, MediaFire, etc.). Students will see these in the Apps tab.</p>

                          {/* HIDE TOGGLE */}
                          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm mb-4 flex items-center justify-between gap-3">
                              <div className="flex-1">
                                  <p className="font-bold text-slate-800 text-sm">Hide App Store Page</p>
                                  <p className="text-[11px] text-slate-500">When enabled, the Apps tab is removed from the student bottom navigation.</p>
                              </div>
                              <label className="relative inline-flex items-center cursor-pointer">
                                  <input
                                      type="checkbox"
                                      className="sr-only peer"
                                      checked={!!localSettings.appStorePageHidden}
                                      onChange={e => setLocalSettings({ ...localSettings, appStorePageHidden: e.target.checked })}
                                  />
                                  <div className="w-11 h-6 bg-slate-200 rounded-full peer peer-checked:bg-red-500 transition-all after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-5"></div>
                              </label>
                          </div>

                          {/* APP LIST */}
                          <div className="space-y-3 mb-4">
                              {(localSettings.downloadApps || []).map((app, idx) => (
                                  <div key={app.id} className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm space-y-2">
                                      <div className="flex justify-between items-start gap-2">
                                          <div className="flex items-center gap-2 flex-1 min-w-0">
                                              {app.iconUrl ? (
                                                  <img src={app.iconUrl} alt="" className="w-9 h-9 rounded-lg object-cover bg-slate-100 border border-slate-200" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
                                              ) : (
                                                  <div className="w-9 h-9 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center"><ShoppingBag size={16} className="text-slate-400" /></div>
                                              )}
                                              <span className="font-bold text-sm text-slate-800 truncate">{app.name || 'Untitled App'}</span>
                                          </div>
                                          <button
                                              onClick={() => {
                                                  const updated = (localSettings.downloadApps || []).filter((_, i) => i !== idx);
                                                  setLocalSettings({ ...localSettings, downloadApps: updated });
                                              }}
                                              className="text-red-400 hover:text-red-600 p-1"
                                              aria-label="Delete app"
                                          ><Trash2 size={16} /></button>
                                      </div>

                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                          <div>
                                              <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">App Name</label>
                                              <input
                                                  type="text"
                                                  value={app.name || ''}
                                                  onChange={e => {
                                                      const updated = (localSettings.downloadApps || []).map((a, i) => i === idx ? { ...a, name: e.target.value } : a);
                                                      setLocalSettings({ ...localSettings, downloadApps: updated });
                                                  }}
                                                  className="w-full p-2 border border-slate-200 rounded-lg text-sm font-bold focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                                                  placeholder="e.g. WhatsApp"
                                              />
                                          </div>
                                          <div>
                                              <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">Store</label>
                                              <select
                                                  value={app.store || 'OTHER'}
                                                  onChange={e => {
                                                      const updated = (localSettings.downloadApps || []).map((a, i) => i === idx ? { ...a, store: e.target.value as any } : a);
                                                      setLocalSettings({ ...localSettings, downloadApps: updated });
                                                  }}
                                                  className="w-full p-2 border border-slate-200 rounded-lg text-sm font-bold focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none bg-white"
                                              >
                                                  <option value="PLAY_STORE">Play Store</option>
                                                  <option value="APP_STORE">App Store (iOS)</option>
                                                  <option value="GOOGLE_DRIVE">Google Drive</option>
                                                  <option value="MEDIAFIRE">MediaFire</option>
                                                  <option value="OTHER">Other / Direct Link</option>
                                              </select>
                                          </div>
                                      </div>

                                      <div>
                                          <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">Download URL</label>
                                          <input
                                              type="url"
                                              value={app.downloadUrl || ''}
                                              onChange={e => {
                                                  const updated = (localSettings.downloadApps || []).map((a, i) => i === idx ? { ...a, downloadUrl: e.target.value } : a);
                                                  setLocalSettings({ ...localSettings, downloadApps: updated });
                                              }}
                                              className="w-full p-2 border border-slate-200 rounded-lg text-sm font-mono text-blue-600 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                                              placeholder="https://www.mediafire.com/file/..."
                                          />
                                      </div>

                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                          <div>
                                              <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">Icon URL (optional)</label>
                                              <input
                                                  type="url"
                                                  value={app.iconUrl || ''}
                                                  onChange={e => {
                                                      const updated = (localSettings.downloadApps || []).map((a, i) => i === idx ? { ...a, iconUrl: e.target.value } : a);
                                                      setLocalSettings({ ...localSettings, downloadApps: updated });
                                                  }}
                                                  className="w-full p-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                                                  placeholder="https://.../icon.png"
                                              />
                                          </div>
                                          <div className="grid grid-cols-2 gap-2">
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">Version</label>
                                                  <input
                                                      type="text"
                                                      value={app.version || ''}
                                                      onChange={e => {
                                                          const updated = (localSettings.downloadApps || []).map((a, i) => i === idx ? { ...a, version: e.target.value } : a);
                                                          setLocalSettings({ ...localSettings, downloadApps: updated });
                                                      }}
                                                      className="w-full p-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                                                      placeholder="1.0.0"
                                                  />
                                              </div>
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">Size</label>
                                                  <input
                                                      type="text"
                                                      value={app.size || ''}
                                                      onChange={e => {
                                                          const updated = (localSettings.downloadApps || []).map((a, i) => i === idx ? { ...a, size: e.target.value } : a);
                                                          setLocalSettings({ ...localSettings, downloadApps: updated });
                                                      }}
                                                      className="w-full p-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                                                      placeholder="25 MB"
                                                  />
                                              </div>
                                          </div>
                                      </div>

                                      <div>
                                          <label className="text-[10px] font-bold text-slate-500 uppercase mb-1 block">Description (optional)</label>
                                          <textarea
                                              value={app.description || ''}
                                              onChange={e => {
                                                  const updated = (localSettings.downloadApps || []).map((a, i) => i === idx ? { ...a, description: e.target.value } : a);
                                                  setLocalSettings({ ...localSettings, downloadApps: updated });
                                              }}
                                              className="w-full p-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none resize-none"
                                              rows={2}
                                              placeholder="Short description shown to students"
                                          />
                                      </div>
                                  </div>
                              ))}

                              {(localSettings.downloadApps || []).length === 0 && (
                                  <div className="bg-white p-6 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
                                      No apps added yet. Click below to add your first one.
                                  </div>
                              )}
                          </div>

                          <button
                              onClick={() => {
                                  const newApp = {
                                      id: `dapp-${Date.now()}`,
                                      name: 'New App',
                                      downloadUrl: '',
                                      store: 'OTHER' as const,
                                      description: '',
                                  };
                                  setLocalSettings({ ...localSettings, downloadApps: [...(localSettings.downloadApps || []), newApp] });
                              }}
                              className="w-full py-2.5 bg-purple-100 text-purple-700 font-bold rounded-xl border border-dashed border-purple-300 hover:bg-purple-200 flex items-center justify-center gap-2"
                          >
                              <Plus size={16} /> Add App
                          </button>

                          <div className="mt-6">
                              <button
                                  onClick={handleSaveSettings}
                                  disabled={isSettingsSaving}
                                  className={`w-full py-4 text-white font-black rounded-xl text-lg shadow-xl shadow-purple-500/20 flex items-center justify-center gap-3 transition-all hover:-translate-y-1 active:scale-95 ${isSettingsSaving ? 'bg-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-purple-500 to-fuchsia-600 hover:from-purple-400 hover:to-fuchsia-500'}`}
                              >
                                  {isSettingsSaving ? (
                                      <>
                                          <div className="w-5 h-5 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                                          Saving...
                                      </>
                                  ) : (
                                      <>
                                          <Save size={24} />
                                          Save App Store
                                      </>
                                  )}
                              </button>
                          </div>
                      </div>
                  )}
                  {activeTab === 'CONFIG_REWARDS' && (
                       <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
                           <h4 className="font-bold text-slate-800 flex items-center gap-2"><Gift size={18} /> Engagement Rewards (Padhai karo aur rewards jito)</h4>
                           <p className="text-xs text-slate-600">
                               Configure rewards for students based on their daily study time.
                               <br/>Time is tracked when student is online and active.
                           </p>
                           
                           <div className="space-y-4">
                               {localSettings.engagementRewards?.map((reward, idx) => (
                                   <div key={reward.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                                       <div className="flex justify-between items-center mb-3">
                                            <div className="flex items-center gap-2">
                                                <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-bold">
                                                    {(reward.seconds / 60).toFixed(0)} Mins
                                                </span>
                                                <span className={`px-2 py-1 rounded text-xs font-bold ${reward.type === 'COINS' ? 'bg-yellow-100 text-yellow-700' : 'bg-purple-100 text-purple-700'}`}>
                                                    {reward.type}
                                                </span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <label className="flex items-center gap-1 text-xs font-bold text-slate-600">
                                                    <input 
                                                        type="checkbox" 
                                                        checked={reward.enabled} 
                                                        onChange={e => {
                                                            const updated = [...(localSettings.engagementRewards || [])];
                                                            updated[idx].enabled = e.target.checked;
                                                            setLocalSettings({...localSettings, engagementRewards: updated});
                                                        }}
                                                    /> Active
                                                </label>
                                                <button onClick={() => {
                                                    const updated = localSettings.engagementRewards!.filter((_, i) => i !== idx);
                                                    setLocalSettings({...localSettings, engagementRewards: updated});
                                                }} className="text-red-400 hover:text-red-600"><Trash2 size={16} /></button>
                                            </div>
                                       </div>
                                       
                                       <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                                           <div>
                                               <label className="text-[10px] font-bold text-slate-500 uppercase">Time (Seconds)</label>
                                               <input 
                                                   type="number" 
                                                   value={reward.seconds} 
                                                   onChange={e => {
                                                       const updated = [...(localSettings.engagementRewards || [])];
                                                       updated[idx].seconds = Number(e.target.value);
                                                       setLocalSettings({...localSettings, engagementRewards: updated});
                                                   }} 
                                                   className="w-full p-2 border rounded-lg text-sm"
                                               />
                                               <p className="text-[9px] text-slate-500 text-right">={(reward.seconds / 60).toFixed(1)} mins</p>
                                           </div>
                                           <div>
                                               <label className="text-[10px] font-bold text-slate-500 uppercase">Display Label</label>
                                               <input 
                                                   type="text" 
                                                   value={reward.label} 
                                                   onChange={e => {
                                                       const updated = [...(localSettings.engagementRewards || [])];
                                                       updated[idx].label = e.target.value;
                                                       setLocalSettings({...localSettings, engagementRewards: updated});
                                                   }} 
                                                   className="w-full p-2 border rounded-lg text-sm"
                                               />
                                           </div>
                                       </div>

                                       <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                                           <div className="flex gap-4 mb-2">
                                               <label className="flex items-center gap-1 text-xs">
                                                   <input 
                                                       type="radio" 
                                                       checked={reward.type === 'COINS'} 
                                                       onChange={() => {
                                                           const updated = [...(localSettings.engagementRewards || [])];
                                                           updated[idx].type = 'COINS';
                                                           setLocalSettings({...localSettings, engagementRewards: updated});
                                                       }}
                                                   /> Coins
                                               </label>
                                               <label className="flex items-center gap-1 text-xs">
                                                   <input 
                                                       type="radio" 
                                                       checked={reward.type === 'SUBSCRIPTION'} 
                                                       onChange={() => {
                                                           const updated = [...(localSettings.engagementRewards || [])];
                                                           updated[idx].type = 'SUBSCRIPTION';
                                                           setLocalSettings({...localSettings, engagementRewards: updated});
                                                       }}
                                                   /> Subscription
                                               </label>
                                           </div>

                                           {reward.type === 'COINS' ? (
                                               <div>
                                                   <label className="text-[10px] font-bold text-slate-500 uppercase">Coin Amount</label>
                                                   <input 
                                                       type="number" 
                                                       value={reward.amount || 0} 
                                                       onChange={e => {
                                                           const updated = [...(localSettings.engagementRewards || [])];
                                                           updated[idx].amount = Number(e.target.value);
                                                           setLocalSettings({...localSettings, engagementRewards: updated});
                                                       }} 
                                                       className="w-full p-2 border rounded-lg text-sm"
                                                   />
                                               </div>
                                           ) : (
                                               <div className="grid grid-cols-3 gap-2">
                                                   <div>
                                                       <label className="text-[10px] font-bold text-slate-500 uppercase">Tier</label>
                                                       <select 
                                                           value={reward.subTier} 
                                                           onChange={e => {
                                                               const updated = [...(localSettings.engagementRewards || [])];
                                                               // @ts-ignore
                                                               updated[idx].subTier = e.target.value;
                                                               setLocalSettings({...localSettings, engagementRewards: updated});
                                                           }} 
                                                           className="w-full p-2 border rounded-lg text-xs"
                                                       >
                                                           <option value="WEEKLY">Weekly</option>
                                                           <option value="MONTHLY">Monthly</option>
                                                           <option value="LIFETIME">Lifetime</option>
                                                       </select>
                                                   </div>
                                                   <div>
                                                       <label className="text-[10px] font-bold text-slate-500 uppercase">Level</label>
                                                       <select 
                                                           value={reward.subLevel} 
                                                           onChange={e => {
                                                               const updated = [...(localSettings.engagementRewards || [])];
                                                               // @ts-ignore
                                                               updated[idx].subLevel = e.target.value;
                                                               setLocalSettings({...localSettings, engagementRewards: updated});
                                                           }} 
                                                           className="w-full p-2 border rounded-lg text-xs"
                                                       >
                                                           <option value="BASIC">Basic</option>
                                                           <option value="ULTRA">Ultra</option>
                                                       </select>
                                                   </div>
                                                   <div>
                                                       <label className="text-[10px] font-bold text-slate-500 uppercase">Duration (Hrs)</label>
                                                       <input 
                                                           type="number" 
                                                           value={reward.durationHours || 4} 
                                                           onChange={e => {
                                                               const updated = [...(localSettings.engagementRewards || [])];
                                                               updated[idx].durationHours = Number(e.target.value);
                                                               setLocalSettings({...localSettings, engagementRewards: updated});
                                                           }} 
                                                           className="w-full p-2 border rounded-lg text-sm"
                                                       />
                                                   </div>
                                               </div>
                                           )}
                                       </div>
                                   </div>
                               ))}
                               
                               <button 
                                   onClick={() => {
                                       const newReward = {
                                           id: `rew-def-${Date.now()}`,
                                           seconds: 60,
                                           type: 'COINS',
                                           amount: 1,
                                           label: '1 Min Reward',
                                           enabled: true
                                       };
                                       setLocalSettings({
                                           ...localSettings, 
                                           // @ts-ignore
                                           engagementRewards: [...(localSettings.engagementRewards || []), newReward]
                                       });
                                   }}
                                   className="w-full py-3 border-2 border-dashed border-slate-300 text-slate-600 font-bold rounded-xl hover:bg-slate-50 hover:border-slate-400 hover:text-slate-600 transition"
                               >
                                   + Add New Reward Milestone
                               </button>
                           </div>
                       </div>
                  )}
                  {activeTab === 'CONFIG_CHAT' && (
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                           <h4 className="font-bold text-slate-800 flex items-center gap-2 mb-4"><MessageSquare size={18} /> Chat Room Manager</h4>
                           <p className="text-xs text-slate-600 mb-4">Create up to 10 chat rooms for students. Toggle visibility.</p>
                           
                           <div className="space-y-3 mb-6">
                               {(!localSettings.chatRooms || localSettings.chatRooms.length === 0) && (
                                   <p className="text-sm text-slate-500 text-center py-4">No rooms created.</p>
                               )}
                               
                               {localSettings.chatRooms?.map((room, idx) => (
                                   <div key={room.id} className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
                                       <div>
                                           <p className="font-bold text-slate-800 text-sm">{room.name}</p>
                                           <p className="text-xs text-slate-600">{room.description}</p>
                                       </div>
                                       <div className="flex items-center gap-2">
                                           <label className="text-[10px] font-bold uppercase text-slate-500 flex items-center gap-1">
                                               <input 
                                                  type="checkbox" 
                                                  checked={room.enabled} 
                                                  onChange={(e) => {
                                                      const updated = [...(localSettings.chatRooms || [])];
                                                      updated[idx].enabled = e.target.checked;
                                                      setLocalSettings({...localSettings, chatRooms: updated});
                                                  }}
                                                  className="w-4 h-4 accent-blue-600"
                                               /> {room.enabled ? 'ACTIVE' : 'OFF'}
                                           </label>
                                           <button onClick={() => {
                                               const updated = localSettings.chatRooms!.filter((_, i) => i !== idx);
                                               setLocalSettings({...localSettings, chatRooms: updated});
                                           }} className="text-red-400 hover:text-red-600 p-2"><Trash2 size={16} /></button>
                                       </div>
                                   </div>
                               ))}
                           </div>

                           {(!localSettings.chatRooms || localSettings.chatRooms.length < 10) && (
                               <div className="bg-white p-3 rounded-xl border border-slate-200">
                                   <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">Add New Room</p>
                                   <div className="flex gap-2 mb-2">
                                       <input 
                                           type="text" 
                                           placeholder="Room Name (e.g. Doubts)" 
                                           value={newRoomName} 
                                           onChange={e => setNewRoomName(e.target.value)} 
                                           className="flex-1 p-2 border rounded-lg text-sm"
                                       />
                                       <select className="p-2 border rounded-lg text-xs bg-slate-50">
                                           <option value="PUBLIC">Public</option>
                                       </select>
                                   </div>
                                   <input 
                                       type="text" 
                                       placeholder="Description (Optional)" 
                                       value={newRoomDesc} 
                                       onChange={e => setNewRoomDesc(e.target.value)} 
                                       className="w-full p-2 border rounded-lg text-sm mb-2"
                                   />
                                   <button 
                                       onClick={() => {
                                           if(!newRoomName) return;
                                           const newRoom = {
                                               id: `room-${Date.now()}`,
                                               name: newRoomName,
                                               description: newRoomDesc,
                                               type: 'PUBLIC',
                                               enabled: true
                                           };
                                           setLocalSettings({...localSettings, chatRooms: [...(localSettings.chatRooms || []), newRoom]});
                                           setNewRoomName(''); setNewRoomDesc('');
                                       }}
                                       className="w-full py-2 bg-teal-600 text-white font-bold rounded-lg text-xs hover:bg-teal-700"
                                   >
                                       + Create Room
                                   </button>
                               </div>
                           )}
                      </div>
                  )}
              </div>
          </div>
      )}

                  {/* FEATURE GATING CONFIG */}
                  {activeTab === 'CONFIG_GATING' && (
                      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
                          <div className="flex items-center gap-4 mb-6 border-b pb-4">
                              <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                              <h3 className="text-xl font-black text-slate-800">Access Control & Gating</h3>
                          </div>

                          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                              <div className="flex items-center gap-3 mb-6">
                                  <div className="p-3 bg-red-100 rounded-xl text-red-600"><Lock size={24} /></div>
                                  <div>
                                      <h4 className="font-bold text-slate-800 text-lg">Tier Permissions</h4>
                                      <p className="text-xs text-slate-600">Control exactly what each user tier can access. "ALL" overrides everything.</p>
                                  </div>
                              </div>

                              <div className="space-y-6">
                                  {['FREE', 'BASIC', 'ULTRA'].map(tier => (
                                      <div key={tier} className="bg-white p-4 rounded-xl border border-slate-200">
                                          <div className="flex items-center justify-between mb-3">
                                              <span className={`px-3 py-1 rounded-lg text-xs font-black tracking-widest ${
                                                  tier === 'FREE' ? 'bg-slate-100 text-slate-600' :
                                                  tier === 'BASIC' ? 'bg-blue-100 text-blue-600' :
                                                  'bg-purple-100 text-purple-600'
                                              }`}>
                                                  {tier} TIER
                                              </span>
                                              <label className="flex items-center gap-2 cursor-pointer">
                                                  <input 
                                                      type="checkbox"
                                                      checked={(localSettings.tierPermissions?.[tier as keyof typeof localSettings.tierPermissions] || []).includes('ALL')}
                                                      onChange={(e) => {
                                                          const updated = e.target.checked 
                                                              ? ['ALL'] // Exclusive
                                                              : [];
                                                          setLocalSettings({
                                                              ...localSettings,
                                                              tierPermissions: { ...(localSettings.tierPermissions || {}), [tier]: updated } as any
                                                          });
                                                      }}
                                                      className="w-4 h-4 accent-red-600"
                                                  />
                                                  <span className="text-xs font-bold text-slate-600">Grant ALL Access</span>
                                              </label>
                                          </div>

                                          {!(localSettings.tierPermissions?.[tier as keyof typeof localSettings.tierPermissions] || []).includes('ALL') && (
                                              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                                  {[
                                                      { id: 'NOTES_SIMPLE', label: 'Simple Notes (HTML)' },
                                                      { id: 'NOTES_PREMIUM', label: 'Premium Notes (HTML)' },
                                                      { id: 'NOTES_IMAGE_AI', label: 'AI Image Notes' },
                                                      { id: 'PDF_FREE', label: 'Free PDF Links' },
                                                      { id: 'PDF_PREMIUM', label: 'Premium PDF Links' },
                                                      { id: 'PDF_ULTRA', label: 'Ultra PDF Links' },
                                                      { id: 'VIDEO_LECTURE', label: 'Video Lectures' },
                                                      { id: 'MCQ_SIMPLE', label: 'MCQ Practice' },
                                                      { id: 'MCQ_ANALYSIS', label: 'MCQ Analysis' },
                                                      { id: 'WEEKLY_TEST', label: 'Weekly Tests' }
                                                  ].map(feat => {
                                                      const perms = localSettings.tierPermissions?.[tier as keyof typeof localSettings.tierPermissions] || [];
                                                      const isChecked = perms.includes(feat.id);
                                                      return (
                                                          <label key={feat.id} className="flex items-center gap-2 p-2 border rounded-lg hover:bg-slate-50 cursor-pointer">
                                                              <input 
                                                                  type="checkbox"
                                                                  checked={isChecked}
                                                                  onChange={(e) => {
                                                                      const newPerms = e.target.checked
                                                                          ? [...perms, feat.id]
                                                                          : perms.filter(p => p !== feat.id);
                                                                      setLocalSettings({
                                                                          ...localSettings,
                                                                          tierPermissions: { ...(localSettings.tierPermissions || {}), [tier]: newPerms } as any
                                                                      });
                                                                  }}
                                                                  className="w-4 h-4 accent-blue-600"
                                                              />
                                                              <span className="text-[10px] font-bold text-slate-700">{feat.label}</span>
                                                          </label>
                                                      );
                                                  })}
                                              </div>
                                          )}
                                      </div>
                                  ))}
                              </div>
                              
                              <div className="mt-6 flex justify-end">
                                  <button onClick={() => handleSaveSettings()} className="bg-red-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-red-700 flex items-center gap-2">
                                      <Save size={18} /> Save Access Rules
                                  </button>
                              </div>
                          </div>
                      </div>
                  )}




      {activeTab === 'HOMEWORK_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right space-y-6">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Homework Manager</h3>
              </div>
              <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
                  <h4 className="font-bold text-indigo-900 mb-4 flex items-center justify-between">
                      <div className="flex items-center gap-2"><BookOpen size={18} /> Manage Homework</div>
                      <div className="flex bg-indigo-100 rounded-lg p-1">
                          <button onClick={() => setHomeworkTab('ADD')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-colors ${homeworkTab === 'ADD' ? 'bg-white text-indigo-800 shadow' : 'text-indigo-600 hover:bg-indigo-200/50'}`}>Add New</button>
                          <button onClick={() => setHomeworkTab('HISTORY')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-colors ${homeworkTab === 'HISTORY' ? 'bg-white text-indigo-800 shadow' : 'text-indigo-600 hover:bg-indigo-200/50'}`}>History</button>
                          <button onClick={() => setHomeworkTab('COMP_MCQ')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-colors ${homeworkTab === 'COMP_MCQ' ? 'bg-white text-indigo-800 shadow' : 'text-indigo-600 hover:bg-indigo-200/50'}`}>Comp MCQ ({(localSettings.competitionMcqs || []).length})</button>
                      </div>
                  </h4>
                  {homeworkTab === 'ADD' && (
                      <div className="bg-white p-6 rounded-xl border border-indigo-200 shadow-sm animate-in fade-in space-y-4 w-full">
                          <p className="text-xs text-indigo-700 mb-2">Add a new daily homework lesson. It will be displayed on the student dashboard.</p>
                          <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Target Subject (Optional)</label>
                              <select value={newHomework.targetSubject} onChange={e => setNewHomework({...newHomework, targetSubject: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-white">
                                  <option value="none">None (Standard Homework)</option>
                                  <option value="mcq">MCQ</option>
                                  <option value="sarSangrah">Sar Sangrah</option>
                                  <option value="speedySocialScience">Speedy Social Science</option>
                                  <option value="speedyScience">Speedy Science</option>
                                  <option value="lucent">Lucent GK (Page-wise Notes)</option>
                              </select>
                          </div>
                          {newHomework.targetSubject === 'lucent' ? (
                              <div className="space-y-4 border-t border-indigo-100 pt-4">
                                  <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3 text-xs text-indigo-800">
                                      <strong>Lucent Mode:</strong> Choose subject → enter lesson name → add page-no wise notes. Yeh notes student ko Lucent Book ke andar lesson kholne par page-wise dikhenge (year/month/week wise nahi).
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Lucent Subject</label>
                                      <select value={newLucent.subject} onChange={e => setNewLucent({...newLucent, subject: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-white">
                                          {LUCENT_SUBJECT_OPTIONS.map(opt => (
                                              <option key={opt.id} value={opt.id}>{opt.name}</option>
                                          ))}
                                      </select>
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Lesson Name / Title</label>
                                      <input type="text" value={newLucent.lessonTitle} onChange={e => setNewLucent({...newLucent, lessonTitle: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500" placeholder="e.g. Chapter 1: मौलिक अधिकार" />
                                  </div>
                                  <div className="space-y-3">
                                      <div className="flex items-center justify-between">
                                          <label className="text-[10px] font-bold text-slate-500 uppercase">Pages ({newLucent.pages.length})</label>
                                          <button type="button" onClick={() => {
                                              const lastNo = parseInt((newLucent.pages[newLucent.pages.length - 1]?.pageNo || '0'), 10);
                                              const nextNo = isNaN(lastNo) ? newLucent.pages.length + 1 : lastNo + 1;
                                              setNewLucent({...newLucent, pages: [...newLucent.pages, { id: Date.now().toString() + Math.random(), pageNo: String(nextNo), content: '' }]});
                                          }} className="bg-indigo-600 text-white px-3 py-1 rounded-md text-xs font-bold hover:bg-indigo-700 flex items-center gap-1">
                                              <Plus size={12} /> Add Page
                                          </button>
                                      </div>
                                      {newLucent.pages.map((pg, pgIdx) => (
                                          <div key={pg.id} className="border border-slate-200 rounded-lg p-3 bg-slate-50 space-y-2 relative">
                                              {newLucent.pages.length > 1 && (
                                                  <button type="button" onClick={() => {
                                                      const updated = newLucent.pages.filter((_, i) => i !== pgIdx);
                                                      setNewLucent({...newLucent, pages: updated});
                                                  }} className="absolute top-2 right-2 p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded">
                                                      <Trash2 size={14} />
                                                  </button>
                                              )}
                                              <div className="grid grid-cols-[100px_1fr] gap-2 items-start">
                                                  <div>
                                                      <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1">Page No.</label>
                                                      <input type="text" value={pg.pageNo} onChange={e => {
                                                          const updated = [...newLucent.pages];
                                                          updated[pgIdx] = { ...updated[pgIdx], pageNo: e.target.value };
                                                          setNewLucent({...newLucent, pages: updated});
                                                      }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500" placeholder="1" />
                                                  </div>
                                                  <div>
                                                      <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1">Note Content</label>
                                                      <textarea value={pg.content} onChange={e => {
                                                          const updated = [...newLucent.pages];
                                                          updated[pgIdx] = { ...updated[pgIdx], content: e.target.value };
                                                          setNewLucent({...newLucent, pages: updated});
                                                      }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-24 focus:border-indigo-500" placeholder="Page ke notes likhein..." />
                                                  </div>
                                              </div>
                                          </div>
                                      ))}
                                  </div>
                                  <div className="pt-2">
                                      <button onClick={() => {
                                          if (!newLucent.lessonTitle.trim()) return alert('Lesson name nahi diya.');
                                          const validPages = newLucent.pages.filter(p => p.pageNo.trim() && p.content.trim());
                                          if (validPages.length === 0) return alert('Kam se kam ek page ka content add karein.');
                                          const entry: LucentNoteEntry = {
                                              id: Date.now().toString(),
                                              subject: newLucent.subject,
                                              lessonTitle: newLucent.lessonTitle.trim(),
                                              pages: validPages,
                                              createdAt: new Date().toISOString(),
                                          };
                                          const updated = [...(localSettings.lucentNotes || []), entry];
                                          const newSettings = { ...localSettings, lucentNotes: updated };
                                          setLocalSettings(newSettings);
                                          handleSaveSettings(newSettings);
                                          setNewLucent({ subject: newLucent.subject, lessonTitle: '', pages: [{ id: Date.now().toString(), pageNo: '1', content: '' }] });
                                          setAlertConfig({ isOpen: true, message: '✅ Lucent Lesson Added Successfully!' });
                                      }} className="w-full bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-indigo-700 flex items-center justify-center gap-2 transition-colors">
                                          <Save size={18} /> Save Lucent Lesson
                                      </button>
                                  </div>
                              </div>
                          ) : (
                              <>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Date</label>
                                      <input type="date" value={newHomework.date} onChange={e => setNewHomework({...newHomework, date: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500" />
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Lesson Name / Title</label>
                                      <input type="text" value={newHomework.title} onChange={e => setNewHomework({...newHomework, title: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500" placeholder="e.g. Science Chapter 1 Review" />
                                  </div>
                                  {(newHomework.targetSubject === 'sarSangrah' || newHomework.targetSubject === 'speedyScience' || newHomework.targetSubject === 'speedySocialScience') && (
                                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                                          <label className="text-[10px] font-bold text-amber-700 uppercase block mb-1 flex items-center gap-1">
                                              📖 Page Number (Optional — for page-wise sorting)
                                          </label>
                                          <input
                                              type="text"
                                              inputMode="numeric"
                                              value={newHomework.pageNo}
                                              onChange={e => setNewHomework({...newHomework, pageNo: e.target.value.replace(/[^0-9]/g, '')})}
                                              className="w-full p-2 border border-amber-300 rounded text-sm outline-none focus:border-amber-500 bg-white"
                                              placeholder="e.g. 20"
                                          />
                                          <p className="text-[10px] text-amber-700 mt-1">
                                              Page number dene par yeh note Home page par "Continue Reading" me page number ke saath dikhega aur student ke liye page-line wise sort hoga.
                                          </p>
                                      </div>
                                  )}
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Notes (Optional)</label>
                                      <textarea value={newHomework.notes} onChange={e => setNewHomework({...newHomework, notes: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-20 focus:border-indigo-500" placeholder="Enter notes..." />
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">MCQ Text (Optional)</label>
                                      <textarea value={newHomework.mcqText} onChange={e => setNewHomework({...newHomework, mcqText: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-20 focus:border-indigo-500" placeholder="Enter MCQ text..." />
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Audio URL (Optional)</label>
                                      <input type="text" value={newHomework.audioUrl} onChange={e => setNewHomework({...newHomework, audioUrl: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500" placeholder="Enter Audio Link" />
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Video URL (Optional)</label>
                                      <input type="text" value={newHomework.videoUrl} onChange={e => setNewHomework({...newHomework, videoUrl: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500" placeholder="Enter Video Link" />
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">PDF URL — Google Drive Link (Optional)</label>
                                      <input type="text" value={newHomework.pdfUrl} onChange={e => setNewHomework({...newHomework, pdfUrl: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500" placeholder="https://drive.google.com/file/d/..." />
                                      <p className="text-[10px] text-slate-400 mt-1">Google Drive ka PDF link daalein — app ke andar khulega, download blocked rahega.</p>
                                  </div>
                                  <div className="pt-2">
                                      <button onClick={() => {
                                          if(!newHomework.title.trim()) return alert("Lesson Name / Title cannot be empty.");
                                          let parsedMcqs: any[] = [];
                                          if (newHomework.mcqText && newHomework.mcqText.trim()) {
                                              const parsed = parseMCQText(newHomework.mcqText.trim());
                                              if (parsed.questions.length > 0) {
                                                  parsedMcqs = parsed.questions;
                                              } else {
                                                  alert("Failed to parse MCQs. Saving without MCQs.");
                                              }
                                          }
                                          const isPageWiseSubject = ['sarSangrah', 'speedyScience', 'speedySocialScience'].includes(newHomework.targetSubject);
                                          const hwItem: any = {
                                              id: Date.now().toString(),
                                              date: newHomework.date,
                                              title: newHomework.title,
                                              notes: newHomework.notes,
                                              mcqText: newHomework.mcqText,
                                              parsedMcqs: parsedMcqs,
                                              audioUrl: newHomework.audioUrl,
                                              videoUrl: newHomework.videoUrl,
                                              pdfUrl: newHomework.pdfUrl || undefined,
                                              targetSubject: newHomework.targetSubject === 'none' ? undefined : newHomework.targetSubject
                                          };
                                          if (isPageWiseSubject && newHomework.pageNo.trim()) {
                                              hwItem.pageNo = newHomework.pageNo.trim();
                                          }
                                          const updated = [...(localSettings.homework || []), hwItem];
                                          const newSettings = {...localSettings, homework: updated};
                                          setLocalSettings(newSettings);
                                          handleSaveSettings(newSettings);
                                          setNewHomework({ date: new Date().toISOString().split('T')[0], title: '', notes: '', mcqText: '', audioUrl: '', videoUrl: '', pdfUrl: '', targetSubject: 'none', pageNo: '' });
                                          setAlertConfig({isOpen: true, message: '✅ Homework Added Successfully!'});
                                      }} className="w-full bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-indigo-700 flex items-center justify-center gap-2 transition-colors">
                                          <Save size={18} /> Save Homework
                                      </button>
                                  </div>
                              </>
                          )}
                      </div>
                  )}
                  {homeworkTab === 'HISTORY' && (
                      <div className="animate-in fade-in">
                          <div className="flex justify-between items-center mb-4 mt-2">
                              <p className="text-xs font-bold text-indigo-800 uppercase tracking-wider">Saved Homework ({(localSettings.homework || []).length})</p>
                              <button onClick={() => {
                                  const updated = (localSettings.homework || []).map(hw => {
                                      if (hw.mcqText && hw.mcqText.trim()) {
                                          const parsed = parseMCQText(hw.mcqText.trim());
                                          return { ...hw, parsedMcqs: parsed.questions };
                                      }
                                      return { ...hw, parsedMcqs: [] };
                                  });
                                  setLocalSettings({...localSettings, homework: updated});
                                  handleSaveSettings({...localSettings, homework: updated});
                                  setAlertConfig({isOpen: true, message: '✅ Edits Saved Successfully!'});
                              }} className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold text-xs shadow hover:bg-indigo-700 flex items-center gap-2 transition-colors">
                                  <Save size={14} /> Save Edits
                              </button>
                          </div>
                          <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                              {[...(localSettings.homework || [])].reverse().map((hw, reversedIndex) => {
                                  const i = (localSettings.homework || []).length - 1 - reversedIndex;
                                  return (<div key={hw.id} className="bg-white p-4 rounded-xl border border-indigo-200 shadow-sm relative group hover:border-indigo-400 transition-colors">
                                      <button onClick={() => {
                                          if(!confirm('Delete this homework?')) return;
                                          const updated = (localSettings.homework || []).filter((_, idx) => idx !== i);
                                          setLocalSettings({...localSettings, homework: updated});
                                      }} className="absolute top-2 right-2 p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors opacity-50 group-hover:opacity-100">
                                          <Trash2 size={16} />
                                      </button>
                                      <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4">
                                          <div>
                                              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Date</label>
                                              <input type="date" value={hw.date} onChange={e => {
                                                  const updated = [...(localSettings.homework || [])];
                                                  updated[i] = { ...updated[i], date: e.target.value };
                                                  setLocalSettings({...localSettings, homework: updated});
                                              }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-slate-50" />
                                          </div>
                                          <div className="space-y-3">
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Title</label>
                                                  <input type="text" value={hw.title} onChange={e => {
                                                      const updated = [...(localSettings.homework || [])];
                                                      updated[i] = { ...updated[i], title: e.target.value };
                                                      setLocalSettings({...localSettings, homework: updated});
                                                  }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-slate-50" />
                                              </div>
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Notes</label>
                                                  <textarea value={hw.notes || ''} onChange={e => {
                                                      const updated = [...(localSettings.homework || [])];
                                                      updated[i] = { ...updated[i], notes: e.target.value };
                                                      setLocalSettings({...localSettings, homework: updated});
                                                  }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-16 focus:border-indigo-500 bg-slate-50" />
                                              </div>
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">MCQ Text (Re-parse on save)</label>
                                                  <textarea value={hw.mcqText || ''} onChange={e => {
                                                      const updated = [...(localSettings.homework || [])];
                                                      updated[i] = { ...updated[i], mcqText: e.target.value };
                                                      setLocalSettings({...localSettings, homework: updated});
                                                  }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-16 focus:border-indigo-500 bg-slate-50" />
                                              </div>
                                              <div className="grid grid-cols-2 gap-2">
                                                <div>
                                                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Audio URL</label>
                                                    <input type="text" value={hw.audioUrl || ''} onChange={e => {
                                                        const updated = [...(localSettings.homework || [])];
                                                        updated[i] = { ...updated[i], audioUrl: e.target.value };
                                                        setLocalSettings({...localSettings, homework: updated});
                                                    }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-slate-50" />
                                                </div>
                                                <div>
                                                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Video URL</label>
                                                    <input type="text" value={hw.videoUrl || ''} onChange={e => {
                                                        const updated = [...(localSettings.homework || [])];
                                                        updated[i] = { ...updated[i], videoUrl: e.target.value };
                                                        setLocalSettings({...localSettings, homework: updated});
                                                    }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-slate-50" />
                                                </div>
                                              </div>
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">PDF URL (Google Drive)</label>
                                                  <input type="text" value={hw.pdfUrl || ''} onChange={e => {
                                                      const updated = [...(localSettings.homework || [])];
                                                      updated[i] = { ...updated[i], pdfUrl: e.target.value || undefined };
                                                      setLocalSettings({...localSettings, homework: updated});
                                                  }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-slate-50" placeholder="https://drive.google.com/file/d/..." />
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              )})}
                              {(localSettings.homework || []).length === 0 && (
                                  <div className="text-center py-8 text-slate-500 text-sm">No Homework entries saved yet.</div>
                              )}
                          </div>

                          {/* --- LUCENT NOTES HISTORY --- */}
                          <div className="mt-8 pt-6 border-t border-indigo-200">
                              {/* Hide built-in syllabus toggle (default: hidden) */}
                              {(() => {
                                  const isHidden = localSettings.hideLucentSyllabus !== false; // default true
                                  return (
                                      <div className="bg-white border-2 border-indigo-200 rounded-2xl p-4 mb-4 flex items-center justify-between gap-3 shadow-sm">
                                          <div className="flex-1 min-w-0">
                                              <p className="font-black text-sm text-indigo-900">Hide built-in Lucent Syllabus</p>
                                              <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                                                  ON (default): Students sirf aapke add kiye lessons dekhenge — subject-wise → page-wise. Built-in / AI syllabus hidden rahega.
                                                  <br/>OFF: Aapke lessons + AI-generated chapters dono dikhenge.
                                              </p>
                                          </div>
                                          <button
                                              onClick={() => {
                                                  const newSettings = { ...localSettings, hideLucentSyllabus: !isHidden };
                                                  setLocalSettings(newSettings);
                                                  handleSaveSettings(newSettings);
                                              }}
                                              className={`shrink-0 relative w-14 h-7 rounded-full transition-colors ${isHidden ? 'bg-indigo-600' : 'bg-slate-300'}`}
                                              aria-label="Toggle Lucent built-in syllabus visibility"
                                          >
                                              <span className={`absolute top-0.5 w-6 h-6 bg-white rounded-full shadow transition-transform ${isHidden ? 'translate-x-7' : 'translate-x-0.5'}`} />
                                          </button>
                                      </div>
                                  );
                              })()}
                              <div className="flex justify-between items-center mb-4">
                                  <p className="text-xs font-bold text-indigo-800 uppercase tracking-wider">📘 Saved Lucent Lessons ({(localSettings.lucentNotes || []).length})</p>
                              </div>
                              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                                  {[...(localSettings.lucentNotes || [])].reverse().map((entry, reversedIndex) => {
                                      const i = (localSettings.lucentNotes || []).length - 1 - reversedIndex;
                                      const subjLabel = LUCENT_SUBJECT_OPTIONS.find(o => o.id === entry.subject)?.name || entry.subject;
                                      return (
                                          <div key={entry.id} className="bg-white p-4 rounded-xl border border-indigo-200 shadow-sm relative group hover:border-indigo-400 transition-colors">
                                              <button onClick={() => {
                                                  if (!confirm('Delete this Lucent lesson?')) return;
                                                  const updated = (localSettings.lucentNotes || []).filter((_, idx) => idx !== i);
                                                  const newSettings = { ...localSettings, lucentNotes: updated };
                                                  setLocalSettings(newSettings);
                                                  handleSaveSettings(newSettings);
                                              }} className="absolute top-2 right-2 p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors opacity-50 group-hover:opacity-100">
                                                  <Trash2 size={16} />
                                              </button>
                                              <div className="space-y-3">
                                                  <div className="grid grid-cols-2 gap-2">
                                                      <div>
                                                          <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Subject</label>
                                                          <select value={entry.subject} onChange={e => {
                                                              const updated = [...(localSettings.lucentNotes || [])];
                                                              updated[i] = { ...updated[i], subject: e.target.value };
                                                              setLocalSettings({ ...localSettings, lucentNotes: updated });
                                                          }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-slate-50">
                                                              {LUCENT_SUBJECT_OPTIONS.map(opt => (
                                                                  <option key={opt.id} value={opt.id}>{opt.name}</option>
                                                              ))}
                                                          </select>
                                                      </div>
                                                      <div>
                                                          <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Lesson Title</label>
                                                          <input type="text" value={entry.lessonTitle} onChange={e => {
                                                              const updated = [...(localSettings.lucentNotes || [])];
                                                              updated[i] = { ...updated[i], lessonTitle: e.target.value };
                                                              setLocalSettings({ ...localSettings, lucentNotes: updated });
                                                          }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-indigo-500 bg-slate-50" />
                                                      </div>
                                                  </div>
                                                  <div className="space-y-2">
                                                      <div className="flex items-center justify-between">
                                                          <label className="text-[10px] font-bold text-slate-500 uppercase">Pages ({entry.pages.length})</label>
                                                          <button type="button" onClick={() => {
                                                              const lastNo = parseInt(entry.pages[entry.pages.length - 1]?.pageNo || '0', 10);
                                                              const nextNo = isNaN(lastNo) ? entry.pages.length + 1 : lastNo + 1;
                                                              const updated = [...(localSettings.lucentNotes || [])];
                                                              updated[i] = { ...updated[i], pages: [...entry.pages, { id: Date.now().toString() + Math.random(), pageNo: String(nextNo), content: '' }] };
                                                              setLocalSettings({ ...localSettings, lucentNotes: updated });
                                                          }} className="bg-indigo-600 text-white px-2 py-0.5 rounded text-[10px] font-bold hover:bg-indigo-700 flex items-center gap-1">
                                                              <Plus size={10} /> Add Page
                                                          </button>
                                                      </div>
                                                      {entry.pages.map((pg, pgIdx) => (
                                                          <div key={pg.id} className="border border-slate-200 rounded-lg p-2 bg-slate-50 grid grid-cols-[80px_1fr_30px] gap-2 items-start">
                                                              <input type="text" value={pg.pageNo} onChange={e => {
                                                                  const updated = [...(localSettings.lucentNotes || [])];
                                                                  const pages = [...updated[i].pages];
                                                                  pages[pgIdx] = { ...pages[pgIdx], pageNo: e.target.value };
                                                                  updated[i] = { ...updated[i], pages };
                                                                  setLocalSettings({ ...localSettings, lucentNotes: updated });
                                                              }} className="w-full p-1.5 border border-slate-200 rounded text-xs outline-none focus:border-indigo-500" placeholder="Page #" />
                                                              <textarea value={pg.content} onChange={e => {
                                                                  const updated = [...(localSettings.lucentNotes || [])];
                                                                  const pages = [...updated[i].pages];
                                                                  pages[pgIdx] = { ...pages[pgIdx], content: e.target.value };
                                                                  updated[i] = { ...updated[i], pages };
                                                                  setLocalSettings({ ...localSettings, lucentNotes: updated });
                                                              }} className="w-full p-1.5 border border-slate-200 rounded text-xs outline-none h-16 focus:border-indigo-500" placeholder="Note..." />
                                                              {entry.pages.length > 1 && (
                                                                  <button type="button" onClick={() => {
                                                                      const updated = [...(localSettings.lucentNotes || [])];
                                                                      const pages = updated[i].pages.filter((_, idx) => idx !== pgIdx);
                                                                      updated[i] = { ...updated[i], pages };
                                                                      setLocalSettings({ ...localSettings, lucentNotes: updated });
                                                                  }} className="p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded">
                                                                      <Trash2 size={12} />
                                                                  </button>
                                                              )}
                                                          </div>
                                                      ))}
                                                  </div>
                                                  <button onClick={() => {
                                                      handleSaveSettings(localSettings);
                                                      setAlertConfig({ isOpen: true, message: '✅ Lucent Lesson Updated!' });
                                                  }} className="w-full bg-indigo-600 text-white px-3 py-2 rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center justify-center gap-1">
                                                      <Save size={12} /> Save Changes
                                                  </button>
                                              </div>
                                          </div>
                                      );
                                  })}
                                  {(localSettings.lucentNotes || []).length === 0 && (
                                      <div className="text-center py-6 text-slate-500 text-xs">No Lucent lessons saved yet. Add karne ke liye "Add New" tab me jayein aur Target Subject me "Lucent GK" choose karein.</div>
                                  )}
                              </div>
                          </div>
                      </div>
                  )}
                  {homeworkTab === 'COMP_MCQ' && (
                      <div className="bg-white p-6 rounded-xl border border-indigo-200 shadow-sm animate-in fade-in space-y-4 w-full">
                          <p className="text-xs text-indigo-700 mb-2">Competition page ke "Practice MCQ Maker" me dikhne wale official MCQs. Paste karein, parse karein, save karein. Student users yahan se attempt karenge instant feedback ke saath.</p>
                          <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">MCQ Text (multiple questions, same parser as Homework)</label>
                              <textarea
                                  value={newCompMcqText}
                                  onChange={e => setNewCompMcqText(e.target.value)}
                                  placeholder="Q. ... A) ... B) ... C) ... D) ... Ans: ..."
                                  className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-40 focus:border-indigo-500 font-mono"
                              />
                          </div>
                          <div className="flex gap-2">
                              <button
                                  onClick={() => {
                                      if (!newCompMcqText.trim()) return alert('MCQ text khaali hai.');
                                      const parsed = parseMCQText(newCompMcqText.trim());
                                      if (!parsed.questions || parsed.questions.length === 0) {
                                          return alert('Parse fail ho gaya. Format check karein.');
                                      }
                                      const merged = [...(localSettings.competitionMcqs || []), ...parsed.questions];
                                      const newSettings = { ...localSettings, competitionMcqs: merged };
                                      setLocalSettings(newSettings);
                                      handleSaveSettings(newSettings);
                                      setNewCompMcqText('');
                                      setAlertConfig({ isOpen: true, message: `✅ ${parsed.questions.length} MCQ added! Total: ${merged.length}` });
                                  }}
                                  className="flex-1 bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-indigo-700 flex items-center justify-center gap-2 transition-colors"
                              >
                                  <Save size={18} /> Parse & Append
                              </button>
                              <button
                                  onClick={() => {
                                      if (!confirm('Saare Competition MCQs delete karein?')) return;
                                      const newSettings = { ...localSettings, competitionMcqs: [] };
                                      setLocalSettings(newSettings);
                                      handleSaveSettings(newSettings);
                                      setAlertConfig({ isOpen: true, message: '🗑 All cleared.' });
                                  }}
                                  className="bg-rose-50 text-rose-700 border border-rose-200 px-4 py-3 rounded-xl font-bold text-sm hover:bg-rose-100 transition-colors"
                              >
                                  Clear All
                              </button>
                          </div>
                          <div className="border-t border-slate-200 pt-4">
                              <p className="text-xs font-bold text-indigo-800 uppercase tracking-wider mb-3">Saved Competition MCQs ({(localSettings.competitionMcqs || []).length})</p>
                              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                                  {(localSettings.competitionMcqs || []).length === 0 && (
                                      <div className="text-center py-6 text-slate-400 text-sm">Koi MCQ nahi. Upar paste karke add karein.</div>
                                  )}
                                  {(localSettings.competitionMcqs || []).map((q, qi) => (
                                      <div key={qi} className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs">
                                          <div className="flex items-start justify-between gap-2 mb-2">
                                              <p className="font-bold text-slate-800 flex-1 whitespace-pre-wrap">Q{qi + 1}. {q.question}</p>
                                              <button
                                                  onClick={() => {
                                                      if (!confirm('Yeh MCQ delete karein?')) return;
                                                      const updated = (localSettings.competitionMcqs || []).filter((_, i) => i !== qi);
                                                      const newSettings = { ...localSettings, competitionMcqs: updated };
                                                      setLocalSettings(newSettings);
                                                      handleSaveSettings(newSettings);
                                                  }}
                                                  className="p-1 text-rose-400 hover:text-rose-600"
                                              >
                                                  <Trash2 size={14} />
                                              </button>
                                          </div>
                                          <div className="space-y-1">
                                              {q.options.map((opt: string, oi: number) => (
                                                  <p key={oi} className={`pl-2 ${oi === q.correctAnswer ? 'text-emerald-700 font-bold' : 'text-slate-600'}`}>
                                                      {String.fromCharCode(65 + oi)}. {opt} {oi === q.correctAnswer && '✓'}
                                                  </p>
                                              ))}
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          </div>
                      </div>
                  )}
              </div>
          </div>
      )}

      {activeTab === 'DAILY_GK_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right space-y-6">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Daily GK Manager</h3>
              </div>
              <div className="bg-teal-50 p-6 rounded-2xl border border-teal-100">

                  <h4 className="font-bold text-teal-900 mb-4 flex items-center justify-between">
                      <div className="flex items-center gap-2"><Book size={18} /> Manage Daily GK</div>
                      <div className="flex bg-teal-100 rounded-lg p-1">
                          <button onClick={() => setGkTab('ADD')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-colors ${gkTab === 'ADD' ? 'bg-white text-teal-800 shadow' : 'text-teal-600 hover:bg-teal-200/50'}`}>Add New</button>
                          <button onClick={() => setGkTab('HISTORY')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-colors ${gkTab === 'HISTORY' ? 'bg-white text-teal-800 shadow' : 'text-teal-600 hover:bg-teal-200/50'}`}>History & Bank</button>
                      </div>
                  </h4>

                  {gkTab === 'ADD' && (
                      <div className="bg-white p-6 rounded-xl border border-teal-200 shadow-sm animate-in fade-in space-y-4 w-full">
                          <p className="text-xs text-teal-700 mb-2">Add a new daily general knowledge question. It will be saved and moved to the history bank.</p>
                          <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Date</label>
                              <input type="date" value={newGk.date} onChange={e => setNewGk({...newGk, date: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-teal-500" />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Question</label>
                              <textarea value={newGk.question} onChange={e => setNewGk({...newGk, question: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-20 focus:border-teal-500" placeholder="Enter question..." />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Answer</label>
                              <textarea value={newGk.answer} onChange={e => setNewGk({...newGk, answer: e.target.value})} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-20 focus:border-teal-500" placeholder="Enter answer..." />
                          </div>
                          <div className="pt-2">
                              <button onClick={() => {
                                  if(!newGk.question.trim() || !newGk.answer.trim()) return alert("Question and Answer cannot be empty.");
                                  const updated = [...(localSettings.dailyGk || []), { id: Date.now().toString(), date: newGk.date, question: newGk.question, answer: newGk.answer }];
                                  const newSettings = {...localSettings, dailyGk: updated};
                                  setLocalSettings(newSettings);
                                  handleSaveSettings(newSettings); // Force immediate save
                                  setNewGk({ date: new Date().toISOString().split('T')[0], question: '', answer: '' }); // Clear
                                  setAlertConfig({isOpen: true, message: '✅ GK Added Successfully!'});
                              }} className="w-full bg-teal-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-teal-700 flex items-center justify-center gap-2 transition-colors">
                                  <Save size={18} /> Save & Add to Bank
                              </button>
                          </div>
                      </div>
                  )}

                  {gkTab === 'HISTORY' && (
                      <div className="animate-in fade-in">
                          <div className="bg-white p-4 rounded-xl border border-teal-200 mb-6 shadow-sm">
                              <h5 className="font-bold text-slate-800 text-sm mb-2">📋 Copy Random GK Questions</h5>
                              <p className="text-xs text-slate-500 mb-3">Randomly select questions from all different days and copy them to clipboard with answers.</p>
                              <div className="flex flex-wrap gap-2">
                                  {[10, 20, 25, 30, 50, 100, 200].map(num => (
                                      <button key={num} onClick={() => copyRandomGk(num)} className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-1.5 px-3 rounded-lg border border-slate-200 transition-colors">
                                          Copy {num}
                                      </button>
                                  ))}
                              </div>
                          </div>

                          <div className="flex justify-between items-center mb-4">
                              <p className="text-xs font-bold text-teal-800 uppercase tracking-wider">Saved GK Entries ({(localSettings.dailyGk || []).length})</p>
                              <button onClick={() => handleSaveSettings()} className="bg-teal-600 text-white px-4 py-2 rounded-lg font-bold text-xs shadow hover:bg-teal-700 flex items-center gap-2 transition-colors">
                                  <Save size={14} /> Save Edits
                              </button>
                          </div>

                          <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                              {[...(localSettings.dailyGk || [])].reverse().map((gk, reversedIndex) => {
                                  const i = (localSettings.dailyGk || []).length - 1 - reversedIndex;
                                  return (<div key={gk.id} className="bg-white p-4 rounded-xl border border-teal-200 shadow-sm relative group hover:border-teal-400 transition-colors">
                                      <button onClick={() => {
                                          if(!confirm('Delete this entry?')) return;
                                          const updated = (localSettings.dailyGk || []).filter((_, idx) => idx !== i);
                                          setLocalSettings({...localSettings, dailyGk: updated});
                                      }} className="absolute top-2 right-2 p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors opacity-50 group-hover:opacity-100">
                                          <Trash2 size={16} />
                                      </button>
                                      <div className="grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4">
                                          <div>
                                              <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Date</label>
                                              <input type="date" value={gk.date} onChange={e => {
                                                  const updated = [...(localSettings.dailyGk || [])];
                                                  updated[i] = { ...updated[i], date: e.target.value };
                                                  setLocalSettings({...localSettings, dailyGk: updated});
                                              }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none focus:border-teal-500 bg-slate-50" />
                                          </div>
                                          <div className="space-y-3">
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Question</label>
                                                  <textarea value={gk.question} onChange={e => {
                                                      const updated = [...(localSettings.dailyGk || [])];
                                                      updated[i] = { ...updated[i], question: e.target.value };
                                                      setLocalSettings({...localSettings, dailyGk: updated});
                                                  }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-16 focus:border-teal-500 bg-slate-50" />
                                              </div>
                                              <div>
                                                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Answer</label>
                                                  <textarea value={gk.answer} onChange={e => {
                                                      const updated = [...(localSettings.dailyGk || [])];
                                                      updated[i] = { ...updated[i], answer: e.target.value };
                                                      setLocalSettings({...localSettings, dailyGk: updated});
                                                  }} className="w-full p-2 border border-slate-200 rounded text-sm outline-none h-16 focus:border-teal-500 bg-slate-50" />
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              )})}
                              {(localSettings.dailyGk || []).length === 0 && (
                                  <div className="text-center py-8 text-slate-500 text-sm">No Daily GK entries saved yet.</div>
                              )}
                          </div>
                      </div>
                  )}

              </div>

              {/* GLOBAL CHALLENGE MCQ SECTION */}
              <div className="bg-orange-50 p-6 rounded-2xl border border-orange-100 mt-6">
                  <h4 className="font-bold text-orange-900 mb-4 flex items-center gap-2"><Trophy size={18} /> Global Challenge MCQ</h4>
                  <p className="text-xs text-orange-700 mb-4">Paste MCQ text here. It will be parsed and displayed as a challenge on the student dashboard under the top bar.</p>

                  <textarea
                      id="global-challenge-mcq-input"
                      className="w-full h-32 p-3 border border-orange-200 rounded-xl mb-4 text-sm font-mono focus:ring-2 focus:ring-orange-500"
                      placeholder="e.g. Q1. What is the capital of France? \nA. London\nB. Paris\nC. Berlin\nD. Madrid\nAns: B"
                  />

                  <div className="flex gap-4">
                      <button
                          onClick={() => {
                              const textarea = document.getElementById('global-challenge-mcq-input') as HTMLTextAreaElement;
                              if (textarea && textarea.value.trim()) {
                                  const parsed = parseMCQText(textarea.value.trim());
                                  if (parsed.questions.length > 0) {
                                      setLocalSettings({...localSettings, globalChallengeMcq: parsed.questions});
                                      textarea.value = '';
                                      alert(`Successfully parsed and added ${parsed.questions.length} questions! Remember to Save Settings.`);
                                  } else {
                                      alert("Failed to parse any questions. Please check the format.");
                                  }
                              } else {
                                  alert("Please enter MCQ text first.");
                              }
                          }}
                          className="bg-orange-600 text-white px-4 py-2 rounded-xl font-bold shadow hover:bg-orange-700 flex items-center gap-2 text-sm"
                      >
                          <Plus size={16} /> Parse & Add Challenge
                      </button>
                      <button
                          onClick={() => {
                              if (confirm("Are you sure you want to clear the current global challenge?")) {
                                  setLocalSettings({...localSettings, globalChallengeMcq: []});
                              }
                          }}
                          className="bg-red-100 text-red-600 px-4 py-2 rounded-xl font-bold hover:bg-red-200 flex items-center gap-2 text-sm border border-red-200"
                      >
                          <Trash2 size={16} /> Clear Challenge
                      </button>
                  </div>

                  {localSettings.globalChallengeMcq && localSettings.globalChallengeMcq.length > 0 && (
                      <div className="mt-4 p-4 bg-white rounded-xl border border-orange-200 shadow-inner">
                          <h5 className="font-bold text-slate-800 text-sm mb-2">Current Challenge ({localSettings.globalChallengeMcq.length} Questions)</h5>
                          <div className="text-xs text-slate-600 max-h-32 overflow-y-auto custom-scrollbar pr-2 space-y-2">
                              {localSettings.globalChallengeMcq.map((q, idx) => (
                                  <div key={idx} className="bg-slate-50 p-2 rounded border border-slate-100">
                                      <p className="font-bold text-slate-700">{idx + 1}. {q.question}</p>
                                      <p className="text-slate-500 mt-1">Ans: {q.options[q.correctAnswer]}</p>
                                  </div>
                              ))}
                          </div>
                      </div>
                  )}

                  <div className="mt-6">
                      <button onClick={() => handleSaveSettings()} className="bg-orange-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-orange-700 flex items-center gap-2">
                          <Save size={18} /> Save Global Challenge
                      </button>
                  </div>
              </div>
          </div>
      )}

      {activeTab === 'CHALLENGE_CREATOR_20' && (
          <ChallengeCreator20 onBack={() => setActiveTab('DASHBOARD')} language={localSettings.aiModel?.includes('Hindi') ? 'Hindi' : 'English'} />
      )}

      {activeTab === 'CONFIG_CHALLENGE' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right space-y-6">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Challenge Config (Legacy 1.0) & Theme</h3>
              </div>

              {/* CHALLENGE CONFIG */}
              <div className="bg-gradient-to-br from-red-50 to-orange-50 p-6 rounded-3xl border border-red-100 space-y-4">
                  <h4 className="font-bold text-red-900 flex items-center gap-2 text-lg"><Trophy size={20} /> Daily MCQ Challenge</h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-white p-4 rounded-xl border border-red-100 shadow-sm">
                          <label className="text-xs font-bold text-slate-600 uppercase mb-2 block">Reward Condition</label>
                          <div className="flex items-center gap-2">
                              <input
                                  type="number"
                                  value={localSettings.dailyChallengeConfig?.rewardPercentage || 90}
                                  onChange={e => setLocalSettings({
                                      ...localSettings,
                                      dailyChallengeConfig: { ...(localSettings.dailyChallengeConfig || { mode: 'AUTO', rewardPercentage: 90, selectedChapterIds: [] }), rewardPercentage: Number(e.target.value) }
                                  })}
                                  className="w-20 p-2 border rounded-lg font-black text-xl text-center"
                              />
                              <span className="font-bold text-slate-600">% Score required</span>
                          </div>
                          <p className="text-[10px] text-slate-500 mt-2">Students scoring above this get 1 Month Free Subscription.</p>
                      </div>

                      <div className="bg-white p-4 rounded-xl border border-red-100 shadow-sm">
                          <label className="text-xs font-bold text-slate-600 uppercase mb-2 block">Question Source Mode</label>
                          <div className="flex gap-2">
                              <button
                                  onClick={() => setLocalSettings({
                                      ...localSettings,
                                      dailyChallengeConfig: { ...(localSettings.dailyChallengeConfig || { mode: 'AUTO', rewardPercentage: 90, selectedChapterIds: [] }), mode: 'AUTO' }
                                  })}
                                  className={`flex-1 py-2 rounded-lg font-bold text-xs ${localSettings.dailyChallengeConfig?.mode === 'AUTO' ? 'bg-red-600 text-white shadow-lg' : 'bg-slate-100 text-slate-600'}`}
                              >
                                  🤖 Auto Mix (All)
                              </button>
                              <button
                                  onClick={() => setLocalSettings({
                                      ...localSettings,
                                      dailyChallengeConfig: { ...(localSettings.dailyChallengeConfig || { mode: 'AUTO', rewardPercentage: 90, selectedChapterIds: [] }), mode: 'MANUAL' }
                                  })}
                                  className={`flex-1 py-2 rounded-lg font-bold text-xs ${localSettings.dailyChallengeConfig?.mode === 'MANUAL' ? 'bg-red-600 text-white shadow-lg' : 'bg-slate-100 text-slate-600'}`}
                              >
                                  ✍️ Manual Select
                              </button>
                          </div>
                          <p className="text-[10px] text-slate-500 mt-2">
                              {localSettings.dailyChallengeConfig?.mode === 'AUTO'
                                  ? "Questions will be randomly mixed from ALL available chapters for the student's class."
                                  : "Only questions from specific chapters selected below will be used."}
                          </p>
                      </div>
                  </div>

                  {localSettings.dailyChallengeConfig?.mode === 'MANUAL' && (
                      <div className="bg-white p-4 rounded-xl border border-red-100">
                          <h5 className="font-bold text-slate-700 text-sm mb-3">Select Source Chapters (Manual Mode)</h5>
                          <SubjectSelector />

                          {selSubject && selChapters.length > 0 ? (
                              <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                                  {selChapters.map(ch => {
                                      const isSelected = (localSettings.dailyChallengeConfig?.selectedChapterIds || []).includes(ch.id);
                                      return (
                                          <button
                                              key={ch.id}
                                              onClick={() => {
                                                  const current = localSettings.dailyChallengeConfig?.selectedChapterIds || [];
                                                  const updated = isSelected
                                                      ? current.filter(id => id !== ch.id)
                                                      : [...current, ch.id];

                                                  setLocalSettings({
                                                      ...localSettings,
                                                      dailyChallengeConfig: { ...(localSettings.dailyChallengeConfig || { mode: 'MANUAL', rewardPercentage: 90 }), selectedChapterIds: updated }
                                                  });
                                              }}
                                              className={`text-left p-2 rounded-lg text-xs font-bold border ${isSelected ? 'bg-red-50 border-red-300 text-red-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                                          >
                                              {isSelected ? '✅' : '⬜'} {ch.title}
                                          </button>
                                      );
                                  })}
                              </div>
                          ) : (
                              <p className="text-xs text-slate-500">Select Board, Class & Subject to view chapters.</p>
                          )}

                          <div className="mt-2 pt-2 border-t text-xs text-slate-600 font-medium">
                              Selected: {localSettings.dailyChallengeConfig?.selectedChapterIds?.length || 0} chapters
                          </div>
                      </div>
                  )}
              </div>

              {/* THEME CONFIG */}
              <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-3xl border border-indigo-100 space-y-4">
                  <h4 className="font-bold text-indigo-900 flex items-center gap-2 text-lg"><Palette size={20} /> App Theme Settings</h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-white p-4 rounded-xl border border-indigo-100 shadow-sm">
                          <label className="text-xs font-bold text-slate-600 uppercase mb-2 block">Default Theme (Free Users)</label>
                          <div className="grid grid-cols-2 gap-2">
                              {['BASIC', 'ULTRA', 'DARK', 'LIGHT'].map(theme => (
                                  <button
                                      key={theme}
                                      onClick={() => setLocalSettings({
                                          ...localSettings,
                                          themeConfig: { ...(localSettings.themeConfig || { freeTheme: 'BASIC', enableTop3Gold: true }), freeTheme: theme as any }
                                      })}
                                      className={`py-2 rounded-lg font-bold text-xs ${localSettings.themeConfig?.freeTheme === theme ? 'bg-indigo-600 text-white shadow' : 'bg-slate-100 text-slate-600'}`}
                                  >
                                      {theme}
                                  </button>
                              ))}
                          </div>
                          <p className="text-[10px] text-slate-500 mt-2">Set the default look for non-premium students.</p>
                      </div>

                      <div className="bg-white p-4 rounded-xl border border-indigo-100 shadow-sm flex items-center justify-between">
                          <div>
                              <p className="font-bold text-slate-800 text-sm">Top 3 Gold Theme</p>
                              <p className="text-[10px] text-slate-600">Auto-upgrade leaderboard toppers to Gold Theme.</p>
                          </div>
                          <input
                              type="checkbox"
                              checked={localSettings.themeConfig?.enableTop3Gold !== false}
                              onChange={e => setLocalSettings({
                                  ...localSettings,
                                  themeConfig: { ...(localSettings.themeConfig || { freeTheme: 'BASIC', enableTop3Gold: true }), enableTop3Gold: e.target.checked }
                              })}
                              className="w-6 h-6 accent-indigo-600"
                          />
                      </div>
                  </div>
              </div>

              <button onClick={() => handleSaveSettings()} className="w-full bg-green-600 text-white font-black py-4 rounded-2xl shadow-lg hover:bg-green-700 transition-all flex items-center justify-center gap-2">
                  <Save size={20} /> Save Configuration
              </button>
          </div>
      )}

      {/* --- AI STUDIO TAB --- */}

      {/* --- AI NOTES MANAGER TAB --- */}


      {/* --- DEPLOYMENT / APP UPDATE TAB (Restored without junk) --- */}
      {activeTab === 'DEPLOY' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">App Update Configuration</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* APP UPDATE CONFIGURATION */}
                  <div className="bg-green-50 p-6 rounded-3xl border border-green-100 space-y-4">
                      <div>
                          <div className="w-12 h-12 bg-green-600 text-white rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-green-200">
                              <RefreshCw size={24} />
                          </div>
                          <h4 className="text-xl font-black text-green-900 mb-2">Configure App Update</h4>
                          <p className="text-xs text-green-700 mb-4">Manage Force Updates and version notifications.</p>
                      </div>

                      <div className="space-y-3">
                          <div>
                              <label className="text-[10px] font-bold text-green-700 uppercase">Version Code</label>
                              <input
                                  type="text"
                                  value={localSettings.latestVersion || ''}
                                  onChange={e => setLocalSettings({...localSettings, latestVersion: e.target.value})}
                                  placeholder="e.g. 1.2.5"
                                  className="w-full p-2 rounded-lg border border-green-200 text-sm font-bold"
                              />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-green-700 uppercase">Official App Share Link</label>
                              <input
                                  type="text"
                                  value={localSettings.officialAppUrl || ''}
                                  onChange={e => setLocalSettings({...localSettings, officialAppUrl: e.target.value})}
                                  placeholder="https://play.google.com/..."
                                  className="w-full p-2 rounded-lg border border-green-200 text-sm"
                              />
                              <p className="text-[9px] text-green-600 mt-1">Used when sharing Marksheets via WhatsApp.</p>
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-green-700 uppercase">Update Link (Play Store)</label>
                              <input
                                  type="text"
                                  value={localSettings.updateUrl || ''}
                                  onChange={e => setLocalSettings({...localSettings, updateUrl: e.target.value})}
                                  placeholder="https://..."
                                  className="w-full p-2 rounded-lg border border-green-200 text-sm"
                              />
                          </div>
                          <div>
                              <label className="text-[10px] font-bold text-green-700 uppercase">Launch Date</label>
                              <input
                                  type="datetime-local"
                                  value={localSettings.launchDate || ''}
                                  onChange={e => setLocalSettings({...localSettings, launchDate: e.target.value})}
                                  className="w-full p-2 rounded-lg border border-green-200 text-sm"
                              />
                          </div>
                          {/* GRACE PERIOD CONFIG */}
                          <div className="bg-white p-3 rounded-xl border border-green-200">
                              <label className="text-[10px] font-bold text-green-700 uppercase mb-2 block">Grace Period (Lock App After)</label>
                              <div className="grid grid-cols-4 gap-2">
                                  <div>
                                      <input
                                          type="number"
                                          value={localSettings.updateGracePeriod?.days || 0}
                                          onChange={e => {
                                              const val = Math.max(0, parseInt(e.target.value) || 0);
                                              const newGrace = {
                                                  ...(localSettings.updateGracePeriod || { days: 0, hours: 0, minutes: 0, seconds: 0 }),
                                                  days: val
                                              };
                                              setLocalSettings({...localSettings, updateGracePeriod: newGrace});
                                          }}
                                          className="w-full p-2 rounded-lg border border-green-100 text-sm text-center font-bold"
                                          min="0"
                                          placeholder="D"
                                      />
                                      <p className="text-[9px] text-green-600 text-center mt-1 uppercase">days</p>
                                  </div>
                                  <div>
                                      <input
                                          type="number"
                                          value={localSettings.updateGracePeriod?.hours || 0}
                                          onChange={e => {
                                              const val = Math.max(0, parseInt(e.target.value) || 0);
                                              const newGrace = {
                                                  ...(localSettings.updateGracePeriod || { days: 0, hours: 0, minutes: 0, seconds: 0 }),
                                                  hours: val
                                              };
                                              setLocalSettings({...localSettings, updateGracePeriod: newGrace});
                                          }}
                                          className="w-full p-2 rounded-lg border border-green-100 text-sm text-center font-bold"
                                          min="0"
                                          placeholder="H"
                                      />
                                      <p className="text-[9px] text-green-600 text-center mt-1 uppercase">hours</p>
                                  </div>
                                  <div>
                                      <input
                                          type="number"
                                          value={localSettings.updateGracePeriod?.minutes || 0}
                                          onChange={e => {
                                              const val = Math.max(0, parseInt(e.target.value) || 0);
                                              const newGrace = {
                                                  ...(localSettings.updateGracePeriod || { days: 0, hours: 0, minutes: 0, seconds: 0 }),
                                                  minutes: val
                                              };
                                              setLocalSettings({...localSettings, updateGracePeriod: newGrace});
                                          }}
                                          className="w-full p-2 rounded-lg border border-green-100 text-sm text-center font-bold"
                                          min="0"
                                          placeholder="M"
                                      />
                                      <p className="text-[9px] text-green-600 text-center mt-1 uppercase">minutes</p>
                                  </div>
                                  <div>
                                      <input
                                          type="number"
                                          value={localSettings.updateGracePeriod?.seconds || 0}
                                          onChange={e => {
                                              const val = Math.max(0, parseInt(e.target.value) || 0);
                                              const newGrace = {
                                                  ...(localSettings.updateGracePeriod || { days: 0, hours: 0, minutes: 0, seconds: 0 }),
                                                  seconds: val
                                              };
                                              setLocalSettings({...localSettings, updateGracePeriod: newGrace});
                                          }}
                                          className="w-full p-2 rounded-lg border border-green-100 text-sm text-center font-bold"
                                          min="0"
                                          placeholder="S"
                                      />
                                      <p className="text-[9px] text-green-600 text-center mt-1 uppercase">seconds</p>
                                  </div>
                              </div>
                          </div>

                          {/* POPUP RECURRENCE */}
                          <div className="bg-white p-3 rounded-xl border border-green-200">
                              <label className="text-[10px] font-bold text-green-700 uppercase mb-2 block">Popup Frequency (Show Every)</label>
                              <div className="flex gap-2">
                                  <input
                                      type="number"
                                      value={localSettings.updatePopupFrequency?.value || 0}
                                      onChange={e => {
                                          const val = Math.max(0, parseInt(e.target.value) || 0);
                                          const newFreq = {
                                              unit: 'hours',
                                              ...(localSettings.updatePopupFrequency || {}),
                                              value: val
                                          };
                                          // @ts-ignore
                                          setLocalSettings({...localSettings, updatePopupFrequency: newFreq});
                                      }}
                                      className="flex-1 p-2 rounded-lg border border-green-100 text-sm font-bold"
                                      min="0"
                                      placeholder="Value"
                                  />
                                  <select
                                      value={localSettings.updatePopupFrequency?.unit || 'hours'}
                                      onChange={e => {
                                          const newFreq = {
                                              value: 0,
                                              ...(localSettings.updatePopupFrequency || {}),
                                              unit: e.target.value
                                          };
                                          // @ts-ignore
                                          setLocalSettings({...localSettings, updatePopupFrequency: newFreq});
                                      }}
                                      className="flex-1 p-2 rounded-lg border border-green-100 text-sm font-bold bg-white"
                                  >
                                      {['seconds', 'minutes', 'hours', 'days', 'months', 'years'].map(u => (
                                          <option key={u} value={u}>{u.toUpperCase()}</option>
                                      ))}
                                  </select>
                              </div>
                          </div>

                          <div>
                              <label className="text-[10px] font-bold text-green-700 uppercase">Auto-Close Duration (Sec)</label>
                              <input
                                  type="number"
                                  value={localSettings.updatePopupDurationSeconds || 0}
                                  onChange={e => setLocalSettings({...localSettings, updatePopupDurationSeconds: parseInt(e.target.value)})}
                                  className="w-full p-2 rounded-lg border border-green-200 text-sm"
                                  min="0"
                              />
                              <p className="text-[9px] text-green-600 mt-1">0 = Stays until closed.</p>
                          </div>
                          <label className="flex items-center gap-2 cursor-pointer mt-4 p-2 bg-white rounded-lg border border-green-100">
                              <input
                                  type="checkbox"
                                  checked={localSettings.forceUpdate}
                                  onChange={e => setLocalSettings({...localSettings, forceUpdate: e.target.checked})}
                                  className="w-5 h-5 accent-green-600"
                              />
                              <span className="text-sm font-bold text-slate-700">Require Force Update</span>
                          </label>
                      </div>
                  </div>

                  <div className="space-y-6">
                      <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200">
                          <h4 className="font-bold text-slate-800 flex items-center gap-2 mb-4"><Monitor size={18} /> Update Mechanics</h4>
                          <ul className="text-xs text-slate-600 space-y-3">
                              <li className="flex items-start gap-2">
                                  <CheckCircle size={14} className="text-green-500 mt-0.5 shrink-0" />
                                  <span><b>Version Match:</b> If a user's app version doesn't match the one set here, they see an update notice.</span>
                              </li>
                              <li className="flex items-start gap-2">
                                  <CheckCircle size={14} className="text-green-500 mt-0.5 shrink-0" />
                                  <span><b>Grace Period:</b> The countdown begins exactly on the 'Launch Date'.</span>
                              </li>
                              <li className="flex items-start gap-2">
                                  <CheckCircle size={14} className="text-green-500 mt-0.5 shrink-0" />
                                  <span><b>Force Update:</b> If checked OR if grace period expires, the app is locked until updated.</span>
                              </li>
                          </ul>
                      </div>

                      <button onClick={() => handleSaveSettings()} className="w-full px-6 py-4 bg-green-600 text-white font-bold rounded-2xl shadow-xl hover:bg-green-700 flex items-center justify-center gap-2 text-lg">
                          <Save size={24} /> Deploy Update
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* 5. UTILITY TABS */}
      {activeTab === 'DEMAND' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center gap-4 mb-6"><button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button><h3 className="text-xl font-black text-slate-800">User Demands</h3></div>
              <div className="space-y-3">
                  {demands.length === 0 && <p className="text-slate-500">No demands yet.</p>}
                  {demands.map((d, i) => (
                      <div key={i} className="p-4 border rounded-xl bg-slate-50 flex justify-between items-start">
                          <div>
                              <p className="font-bold text-slate-800">{d.details}</p>
                              <p className="text-xs text-slate-500 mt-1">{new Date(d.timestamp).toLocaleString()}</p>
                          </div>
                          <span className="text-xs font-bold text-blue-600 bg-blue-100 px-2 py-1 rounded">{d.id}</span>
                      </div>
                  ))}
              </div>
          </div>
      )}
      
      {activeTab === 'ACCESS' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center gap-4 mb-6"><button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button><h3 className="text-xl font-black text-slate-800">Login Requests</h3></div>
              <div className="space-y-3">
                  {recoveryRequests.filter(r => r.status === 'PENDING').length === 0 && <p className="text-slate-500">No pending requests.</p>}
                  {recoveryRequests.filter(r => r.status === 'PENDING').map((req) => (
                      <div key={req.id} className="p-4 border rounded-xl bg-slate-50 flex justify-between items-center">
                          <div><p className="font-bold text-slate-800">{req.name}</p><p className="text-xs text-slate-600 font-mono">{req.mobile} • {req.id}</p></div>
                          <button onClick={() => handleApproveRequest(req)} className="bg-green-600 text-white px-4 py-2 rounded-lg text-xs font-bold shadow hover:bg-green-700">Approve Access</button>
                      </div>
                  ))}
              </div>
          </div>
      )}

      {/* --- NOTIFY USERS TAB (Targeted Notifications) --- */}
      {activeTab === 'NOTIFY_USERS' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-pink-800">Targeted Notifications</h3>
              </div>

              <div className="bg-pink-50 p-6 rounded-xl border border-pink-200 mb-6">
                  <h4 className="font-bold text-pink-900 mb-4 flex items-center gap-2">
                      <Megaphone size={20} /> Broadcast Message
                  </h4>
                  <div className="space-y-4">
                      <textarea
                          placeholder="Type your message here..."
                          className="w-full h-24 p-3 rounded-xl border border-pink-200 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                          id="notify-message"
                      />

                      <div className="flex flex-wrap gap-4">
                          <label className="flex items-center gap-2 cursor-pointer">
                              <input type="radio" name="target" value="ALL" defaultChecked className="accent-pink-600 w-4 h-4" />
                              <span className="text-sm font-bold text-slate-700">All Users</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer">
                              <input type="radio" name="target" value="FREE" className="accent-pink-600 w-4 h-4" />
                              <span className="text-sm font-bold text-slate-700">Free Users Only</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer">
                              <input type="radio" name="target" value="PREMIUM" className="accent-pink-600 w-4 h-4" />
                              <span className="text-sm font-bold text-slate-700">Premium Users Only</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer">
                              <input type="radio" name="target" value="LOW_SCORE" className="accent-pink-600 w-4 h-4" />
                              <span className="text-sm font-bold text-slate-700">Low Scorers (&lt; 40%)</span>
                          </label>
                      </div>

                      <button
                          onClick={() => {
                              const msg = (document.getElementById('notify-message') as HTMLTextAreaElement).value;
                              const target = (document.querySelector('input[name="target"]:checked') as HTMLInputElement).value;

                              if (!msg) return alert("Please enter a message.");

                              if (confirm(`Send to ${target} users?`)) {
                                  // Logic to filter and send
                                  const targetUsers = users.filter(u => {
                                      if (target === 'ALL') return true;
                                      if (target === 'FREE') return u.subscriptionTier === 'FREE';
                                      if (target === 'PREMIUM') return u.subscriptionTier !== 'FREE';
                                      if (target === 'LOW_SCORE') {
                                          // Simple heuristic: Average score < 40%
                                          if (!u.mcqHistory || u.mcqHistory.length === 0) return false;
                                          const avg = u.mcqHistory.reduce((acc, h) => acc + (h.score/h.totalQuestions), 0) / u.mcqHistory.length;
                                          return avg < 0.4;
                                      }
                                      return false;
                                  });

                                  // Batch Update (Simulation)
                                  // In real app, we would push to individual inboxes or a broadcast topic
                                  // For now, let's push to a 'global_notifications' or iterate
                                  // Since we don't have a backend batch job, we'll iterate (limit to 50 for safety in demo)

                                  let sentCount = 0;
                                  targetUsers.slice(0, 50).forEach(u => {
                                      const newMsg = {
                                          id: `broadcast-${Date.now()}`,
                                          text: msg,
                                          date: new Date().toISOString(),
                                          read: false,
                                          type: 'TEXT'
                                      };
                                      // We can't update state for all users instantly without lag
                                      // Ideally this writes to a '/notifications' node in Firebase that clients listen to
                                      // For this demo, we'll just alert success.
                                      sentCount++;
                                  });

                                  alert(`Message queued for ${sentCount} users (Demo Limit: 50).`);
                              }
                          }}
                          className="px-6 py-3 bg-pink-600 text-white font-bold rounded-xl shadow-lg hover:bg-pink-700 flex items-center gap-2"
                      >
                          <Megaphone size={18} /> Send Broadcast
                      </button>
                  </div>
              </div>

              {/* IN-APP NOTIFICATIONS (SystemSettings-based, auto-show toast to students) */}
              {(() => {
                const notifs: AppNotification[] = localSettings.notifications || [];
                const addNotif = () => {
                  if (!newNotifTitle.trim() || !newNotifBody.trim()) { alert('Title and body required'); return; }
                  const n: AppNotification = {
                    id: `notif_${Date.now()}`,
                    title: newNotifTitle.trim(),
                    body: newNotifBody.trim(),
                    type: newNotifType,
                    rewardCredits: newNotifType === 'reward' && newNotifCredits ? parseInt(newNotifCredits, 10) : undefined,
                    createdAt: new Date().toISOString(),
                  };
                  const updated = { ...localSettings, notifications: [...notifs, n] };
                  setLocalSettings(updated);
                  localStorage.setItem('nst_system_settings', JSON.stringify(updated));
                  saveSystemSettings(updated);
                  setNewNotifTitle('');
                  setNewNotifBody('');
                  setNewNotifCredits('');
                };
                const removeNotif = (id: string) => {
                  const updated = { ...localSettings, notifications: notifs.filter(n => n.id !== id) };
                  setLocalSettings(updated);
                  localStorage.setItem('nst_system_settings', JSON.stringify(updated));
                  saveSystemSettings(updated);
                };
                return (
                  <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-200 mt-6">
                    <h4 className="font-black text-indigo-900 mb-4 flex items-center gap-2 text-base">
                      <Bell size={20} className="text-indigo-600" /> In-App Notifications
                      <span className="text-xs font-bold text-indigo-500 bg-indigo-100 px-2 py-0.5 rounded-full">{notifs.length} total</span>
                    </h4>
                    <p className="text-xs text-indigo-700 mb-4">Ye notifications students ko app open karne par toast (popup) ke roop mein dikhti hain. Reward type mein students credits claim kar sakte hain.</p>
                    {/* Add form */}
                    <div className="bg-white rounded-xl p-4 border border-indigo-200 mb-4 space-y-3">
                      <input
                        type="text"
                        placeholder="Title (e.g. Congratulations!)"
                        value={newNotifTitle}
                        onChange={e => setNewNotifTitle(e.target.value)}
                        className="w-full p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-400 outline-none"
                      />
                      <textarea
                        placeholder="Message / Body"
                        value={newNotifBody}
                        onChange={e => setNewNotifBody(e.target.value)}
                        className="w-full h-20 p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-400 outline-none resize-none"
                      />
                      <div className="flex items-center gap-3 flex-wrap">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" checked={newNotifType === 'info'} onChange={() => setNewNotifType('info')} className="accent-indigo-600" />
                          <span className="text-sm font-bold text-slate-700">Info</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" checked={newNotifType === 'reward'} onChange={() => setNewNotifType('reward')} className="accent-amber-600" />
                          <span className="text-sm font-bold text-slate-700">Reward (Credits)</span>
                        </label>
                        {newNotifType === 'reward' && (
                          <input
                            type="number"
                            placeholder="Credits"
                            value={newNotifCredits}
                            onChange={e => setNewNotifCredits(e.target.value)}
                            className="w-24 p-2 rounded-xl border border-amber-300 text-sm focus:ring-2 focus:ring-amber-400 outline-none"
                          />
                        )}
                      </div>
                      <button
                        onClick={addNotif}
                        className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 text-sm"
                      >
                        <Plus size={16} /> Add Notification
                      </button>
                    </div>
                    {/* List */}
                    {notifs.length === 0 ? (
                      <p className="text-sm text-slate-400 text-center py-4">Koi notification nahi. Upar se add karein.</p>
                    ) : (
                      <div className="space-y-2">
                        {[...notifs].reverse().map(n => (
                          <div key={n.id} className={`flex items-start gap-3 rounded-xl p-3 border ${n.type === 'reward' ? 'bg-amber-50 border-amber-200' : 'bg-white border-slate-200'}`}>
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${n.type === 'reward' ? 'bg-amber-200 text-amber-700' : 'bg-indigo-100 text-indigo-600'}`}>
                              {n.type === 'reward' ? <Gift size={16} /> : <Bell size={16} />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-black text-sm text-slate-800">{n.title}</p>
                              <p className="text-xs text-slate-600 mt-0.5">{n.body}</p>
                              {n.type === 'reward' && n.rewardCredits && (
                                <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full mt-1 inline-block">{n.rewardCredits} Credits</span>
                              )}
                              <p className="text-[9px] text-slate-400 mt-1">
                                {(() => { try { return new Date(n.createdAt).toLocaleString(); } catch { return n.createdAt; } })()}
                              </p>
                            </div>
                            <button onClick={() => removeNotif(n.id)} className="p-1.5 rounded-full hover:bg-red-100 text-slate-400 hover:text-red-500 shrink-0">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })()}
          </div>
      )}

      {/* --- SUB-ADMINS TAB --- */}
      {activeTab === 'SUB_ADMINS' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Manage Sub-Admins</h3>
              </div>

              <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 mb-8">
                  <h4 className="font-bold text-indigo-900 mb-2">Promote User to Sub-Admin</h4>
                  <div className="flex gap-2">
                      <input 
                          type="text" 
                          placeholder="Enter User ID or Email" 
                          value={newSubAdminId} 
                          onChange={e => setNewSubAdminId(e.target.value)} 
                          className="flex-1 p-3 rounded-xl border border-indigo-200"
                      />
                      <button onClick={() => promoteToSubAdmin(newSubAdminId)} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold shadow hover:bg-indigo-700">
                          Promote
                      </button>
                  </div>
              </div>

              <div className="space-y-4">
                  <h4 className="font-bold text-slate-800">Active Sub-Admins</h4>
                  {users.filter(u => u.role === 'SUB_ADMIN').map(admin => (
                      <div key={admin.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                          <div className="flex justify-between items-start mb-4">
                              <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center font-bold">
                                      {(admin.name || 'A').charAt(0)}
                                  </div>
                                  <div>
                                      <p className="font-bold text-slate-800">{admin.name}</p>
                                      <p className="text-xs text-slate-600">{admin.email || admin.id}</p>
                                  </div>
                              </div>
                              <div className="flex flex-col items-end gap-1">
                                  <button onClick={() => setViewingSubAdminReport(admin.id)} className="text-indigo-600 text-xs font-bold hover:underline mb-1">
                                      📊 View Sales Report
                                  </button>
                                  <button onClick={() => demoteSubAdmin(admin.id)} className="text-red-500 text-xs font-bold hover:underline">
                                      Remove Admin Rights
                                  </button>
                              </div>
                          </div>
                          
                          <div className="bg-slate-50 p-3 rounded-lg">
                              <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">Permissions</p>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-h-40 overflow-y-auto">
                                  {ADMIN_PERMISSIONS.map(perm => {
                                      const hasPerm = (admin.permissions || []).includes(perm);
                                      return (
                                          <button 
                                              key={perm}
                                              onClick={() => toggleSubAdminPermission(admin.id, perm)}
                                              className={`px-2 py-1 rounded text-[10px] font-bold border text-left truncate transition-all ${
                                                  hasPerm 
                                                  ? 'bg-green-100 text-green-700 border-green-200' 
                                                  : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'
                                              }`}
                                              title={perm}
                                          >
                                              {hasPerm ? '☑️' : '⬜'} {perm.replace(/_/g, ' ')}
                                          </button>
                                      );
                                  })}
                              </div>
                          </div>
                      </div>
                  ))}
                  {users.filter(u => u.role === 'SUB_ADMIN').length === 0 && (
                      <p className="text-slate-500 text-sm text-center py-8">No Sub-Admins assigned.</p>
                  )}
              </div>
          </div>
      )}

      {activeTab === 'DATABASE' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center gap-4 mb-6"><button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button><h3 className="text-xl font-black text-slate-800">Database Viewer</h3></div>

              {/* NUCLEAR RESET BUTTON */}
              <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-xl">
                  <h4 className="text-red-800 font-bold mb-2 flex items-center gap-2"><AlertTriangle size={20} /> DANGER ZONE</h4>
                  <p className="text-xs text-red-600 mb-4">This action will delete ALL content (Notes, Videos, Syllabus) from the database. This cannot be undone.</p>
                  <button
                      onClick={async () => {
                          const steps = ["RESET", "DELETE", "CONFIRM", "1234", "FINAL"];
                          for (let i = 0; i < steps.length; i++) {
                              const input = prompt(`SECURITY CHECK (${i+1}/5):\nTo proceed, type: ${steps[i]}`);
                              if (input !== steps[i]) {
                                  alert("❌ Incorrect Code. Reset Aborted.");
                                  return;
                              }
                          }

                          if (confirm("⚠️ NUCLEAR RESET: Are you sure you want to delete ALL content data?")) {
                              if (confirm("🔴 FINAL WARNING: This will wipe Firebase Content. Are you absolutely sure?")) {
                                  resetAllContent()
                                    .then(() => {
                                        alert("✅ Database Reset Complete.");
                                        window.location.reload();
                                    })
                                    .catch(e => {
                                        alert("⚠️ " + e.message);
                                        window.location.reload();
                                    });
                              }
                          }
                      }}
                      className="w-full py-3 bg-red-600 text-white font-bold rounded-xl shadow-lg hover:bg-red-700 animate-pulse flex items-center justify-center gap-2"
                  >
                      <AlertOctagon size={18} /> ☢️ RESET ALL CONTENT DATA
                  </button>

                  <button
                      onClick={async () => {
                          if(confirm("🧹 Clear Local Cache Only?\n\nThis will remove 'Old Notes' stored on this device without affecting the Cloud Database. You will be logged out.")) {
                              try {
                                  localStorage.clear();
                                  await storage.clear();
                                  alert("✅ Cache Cleared!");
                                  window.location.reload();
                              } catch(e) {
                                  alert("Error clearing cache: " + e);
                              }
                          }
                      }}
                      className="w-full mt-4 py-3 bg-orange-100 text-orange-700 font-bold rounded-xl border border-orange-200 hover:bg-orange-200 flex items-center justify-center gap-2"
                  >
                      <RefreshCw size={18} /> 🧹 Clear Local Cache Only (Fix "Old Notes")
                  </button>

                  <button
                      onClick={() => {
                          if(confirm("Reset ALL System Settings to Default?")) {
                              localStorage.removeItem('nst_system_settings');
                              if(isFirebaseConnected) {
                                  // Optionally clear from firebase or just let next save overwrite
                                  alert("Settings cleared locally. Save a change to sync defaults to cloud.");
                              }
                              window.location.reload();
                          }
                      }}
                      className="w-full mt-4 py-3 bg-slate-800 text-white font-bold rounded-xl border border-slate-700 hover:bg-slate-900 flex items-center justify-center gap-2"
                  >
                      <RotateCcw size={18} /> Reset All Settings to Default
                  </button>
              </div>

              <div className="bg-slate-900 rounded-xl p-4">
                  <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                      {['nst_users', 'nst_system_settings', 'nst_activity_log', 'nst_iic_posts', 'nst_leaderboard'].map(k => (
                          <button key={k} onClick={() => setDbKey(k)} className={`px-3 py-1 rounded text-xs font-mono whitespace-nowrap ${dbKey === k ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500'}`}>{k}</button>
                      ))}
                  </div>
                  <textarea value={dbContent} onChange={e => setDbContent(e.target.value)} className="w-full h-96 bg-slate-950 text-green-400 font-mono text-xs p-4 rounded-lg focus:outline-none border border-slate-800 resize-none" spellCheck={false} />
                  <button onClick={() => { localStorage.setItem(dbKey, dbContent); alert("Database Updated Forcefully!"); }} className="mt-4 bg-red-600 text-white px-6 py-3 rounded-lg font-bold w-full hover:bg-red-700">⚠️ SAVE CHANGES (DANGEROUS)</button>
              </div>
          </div>
      )}

      {/* --- GIFT CODES TAB --- */}
      {activeTab === 'CODES' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Gift Code Generator</h3>
              </div>
              
              <div className="bg-pink-50 p-6 rounded-2xl border border-pink-100 mb-8">
                  <div className="flex flex-wrap gap-4 items-end">
                      <div>
                          <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Code Type</label>
                          <select 
                              value={newCodeType} 
                              onChange={e => setNewCodeType(e.target.value as any)}
                              className="p-3 rounded-xl border border-pink-200 font-bold bg-white"
                          >
                              <option value="CREDITS">Credits (Coins)</option>
                              <option value="SUBSCRIPTION">Subscription</option>
                              <option value="DISCOUNT">Discount Coupon</option>
                              <option value="CONTENT_UNLOCK">Content Unlock</option>
                          </select>
                      </div>

                      {newCodeType === 'CREDITS' ? (
                          <div>
                              <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Amount</label>
                              <input type="number" value={newCodeAmount} onChange={e => setNewCodeAmount(Number(e.target.value))} className="p-3 rounded-xl border border-pink-200 w-32 font-bold" />
                          </div>
                      ) : newCodeType === 'DISCOUNT' ? (
                          <div>
                              <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Discount %</label>
                              <input type="number" value={newCodeDiscount} onChange={e => setNewCodeDiscount(Number(e.target.value))} className="p-3 rounded-xl border border-pink-200 w-32 font-bold" min="1" max="100" />
                          </div>
                      ) : newCodeType === 'SUBSCRIPTION' ? (
                          <>
                              <div>
                                  <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Plan Duration</label>
                                  <select value={newCodeSubTier} onChange={e => setNewCodeSubTier(e.target.value)} className="p-3 rounded-xl border border-pink-200 bg-white font-bold">
                                      <option value="WEEKLY">Weekly (7 Days)</option>
                                      <option value="MONTHLY">Monthly (30 Days)</option>
                                      <option value="3_MONTHLY">Quarterly (3 Months)</option>
                                      <option value="YEARLY">Yearly (1 Year)</option>
                                      <option value="LIFETIME">Lifetime</option>
                                  </select>
                              </div>
                              <div>
                                  <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Level</label>
                                  <select value={newCodeSubLevel} onChange={e => setNewCodeSubLevel(e.target.value)} className="p-3 rounded-xl border border-pink-200 bg-white font-bold">
                                      <option value="BASIC">Basic</option>
                                      <option value="ULTRA">Ultra</option>
                                  </select>
                              </div>
                          </>
                      ) : (
                          <div className="flex gap-2">
                                <div>
                                  <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Type</label>
                                  <select value={newCodeContentType} onChange={e => setNewCodeContentType(e.target.value as any)} className="p-3 rounded-xl border border-pink-200 bg-white font-bold">
                                      <option value="VIDEO">Video</option>
                                      <option value="PDF">Notes</option>
                                      <option value="MCQ">MCQ</option>
                                      <option value="AUDIO">Audio</option>
                                  </select>
                                </div>
                                <div>
                                  <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Subject</label>
                                  <select value={newCodeContentSubject} onChange={e => {
                                      setNewCodeContentSubject(e.target.value);
                                      const s = getSubjectsList(newCodeContentClass, 'Science', newCodeContentBoard).find(sub => sub.name === e.target.value);
                                      if (s) {
                                          fetchChapters(newCodeContentBoard, newCodeContentClass, 'Science', s, 'English').then(ch => setNewCodeContentChaptersList(ch));
                                      }
                                  }} className="p-3 rounded-xl border border-pink-200 bg-white font-bold w-32 truncate">
                                      <option value="">Select</option>
                                      {getSubjectsList(newCodeContentClass, 'Science', newCodeContentBoard).map(s => (
                                          <option key={s.id} value={s.name}>{s.name}</option>
                                      ))}
                                  </select>
                                </div>
                                <div>
                                  <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Chapter</label>
                                  <select value={newCodeContentChapter} onChange={e => setNewCodeContentChapter(e.target.value)} className="p-3 rounded-xl border border-pink-200 bg-white font-bold w-48 truncate">
                                      <option value="">Select Chapter</option>
                                      {newCodeContentChaptersList.map(ch => (
                                          <option key={ch.id} value={ch.id}>{ch.title}</option>
                                      ))}
                                  </select>
                                </div>
                          </div>
                      )}

                      <div>
                          <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Quantity</label>
                          <input type="number" value={newCodeCount} onChange={e => setNewCodeCount(Number(e.target.value))} className="p-3 rounded-xl border border-pink-200 w-24 font-bold" />
                      </div>
                      <div>
                          <label className="text-xs font-bold text-pink-700 uppercase block mb-1">Max Uses</label>
                          <input type="number" value={newCodeMaxUses} onChange={e => setNewCodeMaxUses(Number(e.target.value))} className="p-3 rounded-xl border border-pink-200 w-24 font-bold" min="1" />
                      </div>
                      <button onClick={generateCodes} className="bg-pink-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-pink-700 flex items-center gap-2">
                          <Gift size={20} /> Generate
                      </button>
                  </div>
              </div>

              <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 text-slate-600 uppercase text-xs"><tr className="border-b"><th className="p-3">Code</th><th className="p-3">Reward</th><th className="p-3">Status</th><th className="p-3 text-right">Action</th></tr></thead>
                      <tbody>
                          {giftCodes.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-slate-500">No codes generated yet.</td></tr>}
                          {giftCodes.map(code => (
                              <tr key={code.id} className="border-b last:border-0 hover:bg-slate-50">
                                  <td className="p-3 font-mono font-bold text-slate-700 flex items-center gap-2">
                                      {code.code}
                                      <button onClick={() => { navigator.clipboard.writeText(code.code); alert("Code Copied!"); }} className="p-1 hover:bg-slate-200 rounded text-slate-600 hover:text-blue-600 transition-colors" title="Copy Code">
                                          <Copy size={14} />
                                      </button>
                                  </td>
                                  <td className="p-3 font-bold text-pink-600">
                                      {code.type === 'SUBSCRIPTION' 
                                          ? `${code.subTier} ${code.subLevel}` 
                                          : code.type === 'DISCOUNT' ? `${code.discountPercent}% OFF`
                                          : code.type === 'CONTENT_UNLOCK' ? `${code.contentType} (${code.contentId})`
                                          : `${code.amount} CR`}
                                  </td>
                                  <td className="p-3">
                                      <div className="flex flex-col gap-1">
                                          {code.isRedeemed ? (
                                              <span className="bg-red-100 text-red-600 px-2 py-1 rounded text-xs font-bold w-fit">Fully Redeemed</span>
                                          ) : (
                                              <span className="bg-green-100 text-green-600 px-2 py-1 rounded text-xs font-bold w-fit">
                                                  Active ({code.usedCount || 0}/{code.maxUses || 1})
                                              </span>
                                          )}
                                          
                                          {/* Show Redeemed Users */}
                                          {code.redeemedBy && code.redeemedBy.length > 0 && (
                                              <div className="mt-1 flex flex-wrap gap-1">
                                                  {code.redeemedBy.map(uid => (
                                                      <button 
                                                          key={uid}
                                                          onClick={() => {
                                                              setActiveTab('USERS');
                                                              setSearchTerm(uid);
                                                          }}
                                                          className="text-[9px] font-mono bg-slate-100 text-blue-600 px-1.5 py-0.5 rounded border border-slate-200 hover:bg-blue-50"
                                                          title={`View User ${uid}`}
                                                      >
                                                          {uid.slice(0, 6)}...
                                                      </button>
                                                  ))}
                                              </div>
                                          )}
                                      </div>
                                  </td>
                                  <td className="p-3 text-right"><button onClick={() => deleteCode(code.id)} className="text-slate-300 hover:text-red-500"><Trash2 size={16} /></button></td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

      {/* ... (Rest of AdminDashboard remains unchanged) ... */}
      
      {/* ... (Previous code continues for SUBJECTS_MGR, USERS, RECYCLE etc...) */}
      {activeTab === 'SUBJECTS_MGR' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Custom Subject Manager</h3>
              </div>

              <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100 mb-8">
                  <div className="flex flex-wrap gap-4 items-end">
                      <div className="flex-1">
                          <label className="text-xs font-bold text-emerald-700 uppercase block mb-1">Subject Name</label>
                          <input type="text" value={newSubName} onChange={e => setNewSubName(e.target.value)} placeholder="e.g. Physical Education" className="p-3 rounded-xl border border-emerald-200 w-full" />
                      </div>
                      <div className="flex-1">
                          <label className="text-xs font-bold text-emerald-700 uppercase block mb-1">Icon Style</label>
                          <select value={newSubIcon} onChange={e => setNewSubIcon(e.target.value)} className="p-3 rounded-xl border border-emerald-200 w-full bg-white">
                              <option value="book">Book</option>
                              <option value="science">Flask</option>
                              <option value="math">Calculator</option>
                              <option value="globe">Globe</option>
                              <option value="computer">Computer</option>
                              <option value="active">Activity</option>
                          </select>
                      </div>
                      <button onClick={addSubject} className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-emerald-700">
                          Add Subject
                      </button>
                  </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.values({...DEFAULT_SUBJECTS, ...customSubjects}).map((sub: any) => (
                      <div key={sub.id} className="p-4 border rounded-xl flex items-center gap-3 bg-white">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${sub.color}`}>
                              <Book size={20} />
                          </div>
                          <div>
                              <p className="font-bold text-sm">{sub.name}</p>
                              <p className="text-[10px] text-slate-500 uppercase">{sub.id}</p>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      )}

      {/* --- SUBSCRIPTION PLANS EDITOR --- */}
      {activeTab === 'SUBSCRIPTION_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Subscription Manager</h3>
                  <div className="ml-auto flex items-center gap-2">
                      <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-bold">
                          👑 {users.filter(u => u.subscriptionTier && u.subscriptionTier !== 'FREE').length} Premium Users
                      </span>
                  </div>
              </div>

              <div className="relative mb-6">
                  <Search className="absolute left-3 top-3 text-slate-500" size={18} />
                  <input type="text" placeholder="Search by Name, Email or ID..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-purple-500" />
              </div>

              <div className="grid gap-4">
                  {users.filter(u => (u.name || '').toLowerCase().includes((searchTerm || '').toLowerCase()) || (u.email || '').toLowerCase().includes((searchTerm || '').toLowerCase())).map(u => (
                      <div key={u.id} className={`p-4 rounded-xl border-2 ${u.subscriptionTier === 'LIFETIME' ? 'border-yellow-300 bg-yellow-50' : u.subscriptionTier === 'YEARLY' ? 'border-purple-300 bg-purple-50' : u.subscriptionTier === 'MONTHLY' ? 'border-blue-300 bg-blue-50' : u.subscriptionTier === 'WEEKLY' ? 'border-green-300 bg-green-50' : 'border-slate-200 bg-slate-50'}`}>
                          <div className="flex items-start justify-between mb-3">
                              <div>
                                  <p className="font-bold text-slate-800">{u.name}</p>
                                  <p className="text-xs text-slate-600">{u.email} • ID: {u.id}</p>
                              </div>
                              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                  u.subscriptionTier === 'LIFETIME' ? 'bg-yellow-200 text-yellow-800' :
                                  u.subscriptionTier === 'YEARLY' ? 'bg-purple-200 text-purple-800' :
                                  u.subscriptionTier === 'MONTHLY' ? 'bg-blue-200 text-blue-800' :
                                  u.subscriptionTier === 'WEEKLY' ? 'bg-green-200 text-green-800' :
                                  'bg-slate-200 text-slate-700'
                              }`}>
                                  {u.subscriptionTier === 'LIFETIME' ? '🌟 LIFETIME' : u.subscriptionTier === 'YEARLY' ? '📅 YEARLY' : u.subscriptionTier === 'MONTHLY' ? '📆 MONTHLY' : u.subscriptionTier === 'WEEKLY' ? '⏰ WEEKLY' : 'FREE'}
                              </span>
                          </div>

                          <div className="grid grid-cols-4 gap-3 mb-3 text-xs">
                              <div className="bg-white p-2 rounded border border-slate-200">
                                  <p className="text-slate-600 font-bold uppercase">Credits</p>
                                  <p className="font-black text-blue-600">{u.credits || 0}</p>
                              </div>
                              <div className="bg-white p-2 rounded border border-slate-200">
                                  <p className="text-slate-600 font-bold uppercase">Price (₹)</p>
                                  <p className="font-black text-slate-800">₹{u.subscriptionPrice || 0}</p>
                              </div>
                              <div className="bg-white p-2 rounded border border-slate-200">
                                  <p className="text-slate-600 font-bold uppercase">Expires</p>
                                  <p className="font-black text-slate-800">
                                      {u.subscriptionTier === 'LIFETIME' ? 'Never' : (u.subscriptionEndDate && !isNaN(new Date(u.subscriptionEndDate).getTime())) ? new Date(u.subscriptionEndDate).toLocaleDateString() : '—'}
                                  </p>
                              </div>
                              <div className="bg-white p-2 rounded border border-slate-200">
                                  <p className="text-slate-600 font-bold uppercase">Admin Grant</p>
                                  <p className="font-black text-slate-800">{u.grantedByAdmin ? '✅' : '—'}</p>
                              </div>
                          </div>

                          <button 
                              onClick={() => openEditUser(u)}
                              className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-2 rounded-lg font-bold text-xs hover:shadow-lg transition"
                          >
                              ⚙️ Manage Subscription
                          </button>
                      </div>
                  ))}
              </div>
          </div>
      )}

      {/* --- TEACHERS TAB (NEW) --- */}
      {activeTab === 'TEACHERS' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center justify-between mb-6 border-b pb-4">
                  <div className="flex items-center gap-4">
                      <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                      <h3 className="text-xl font-black text-slate-800">Teacher Management</h3>
                  </div>
              </div>

              {/* Teacher Codes Manager */}
              <div className="bg-purple-50 p-4 rounded-xl border border-purple-200 mb-8">
                  <h4 className="font-bold text-purple-800 mb-3 flex items-center gap-2"><KeyRound size={18}/> Teacher Access Codes</h4>
                  <div className="flex gap-2 mb-4">
                      <input
                          type="number"
                          value={newTeacherCodePrice}
                          onChange={e => setNewTeacherCodePrice(e.target.value)}
                          placeholder="Price (₹)"
                          className="px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-purple-500 w-32"
                      />
                      <input
                          type="number"
                          value={newTeacherCodeDuration}
                          onChange={e => setNewTeacherCodeDuration(e.target.value)}
                          placeholder="Duration (Days)"
                          className="px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-purple-500 w-40"
                      />
                      <button
                          onClick={() => {
                              const newCode: TeacherCode = {
                                  code: `TCH${1000 + (parseInt(generateSecureRandomString(6, '0123456789')) % 9000)}`,
                                  price: Number(newTeacherCodePrice) || 299,
                                  durationDays: Number(newTeacherCodeDuration) || 365,
                                  isActive: true,
                                  createdBy: currentUser?.name || 'Admin',
                                  createdAt: new Date().toISOString(),
                                  uses: 0
                              };
                              const updatedCodes = [newCode, ...teacherCodes];
                              setTeacherCodes(updatedCodes);
                              setLocalSettings({...localSettings, teacherCodes: updatedCodes});
                              saveSystemSettings({...localSettings, teacherCodes: updatedCodes});
                              alert(`Generated Teacher Code: ${newCode.code} (Valid for ${newCode.durationDays} days)`);
                          }}
                          className="bg-purple-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-purple-700"
                      >
                          Generate New Code
                      </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {teacherCodes.map((tc, idx) => (
                          <div key={idx} className="bg-white p-3 rounded-lg border border-purple-100 shadow-sm flex items-center justify-between">
                              <div>
                                  <p className="font-mono font-black text-slate-800 tracking-wider">{tc.code}</p>
                                  <p className="text-[10px] text-slate-600">₹{tc.price} • {tc.durationDays || 365} Days • Uses: {tc.uses || 0}</p>
                              </div>
                              <div className="flex items-center gap-2">
                                  <button
                                      onClick={() => {
                                          const updated = [...teacherCodes];
                                          updated[idx].isActive = !updated[idx].isActive;
                                          setTeacherCodes(updated);
                                          setLocalSettings({...localSettings, teacherCodes: updated});
                                          saveSystemSettings({...localSettings, teacherCodes: updated});
                                      }}
                                      className={`px-2 py-1 rounded text-[10px] font-bold ${tc.isActive ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                                  >
                                      {tc.isActive ? 'ACTIVE' : 'DISABLED'}
                                  </button>
                                  <button
                                      onClick={() => {
                                          if(confirm("Delete this code?")) {
                                              const updated = teacherCodes.filter((_, i) => i !== idx);
                                              setTeacherCodes(updated);
                                              setLocalSettings({...localSettings, teacherCodes: updated});
                                              saveSystemSettings({...localSettings, teacherCodes: updated});
                                          }
                                      }}
                                      className="p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                                  >
                                      <Trash2 size={14}/>
                                  </button>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>

              {/* Teacher Store Subscription Plans Manager */}
              <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200 mb-8">
                  <h4 className="font-bold text-indigo-800 mb-3 flex items-center gap-2"><ShoppingBag size={18}/> Teacher Store Subscription Plans</h4>
                  <div className="flex flex-wrap gap-2 mb-4">
                      <input
                          type="text"
                          id="newTPlanName"
                          placeholder="Plan Name (e.g. Pro Teacher)"
                          className="px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 flex-1 min-w-[200px]"
                      />
                      <input
                          type="number"
                          id="newTPlanPrice"
                          placeholder="Price (₹)"
                          className="px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 w-24"
                      />
                      <input
                          type="number"
                          id="newTPlanDuration"
                          placeholder="Duration (Days)"
                          className="px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 w-32"
                      />
                      <input
                          type="text"
                          id="newTPlanBenefits"
                          placeholder="Benefits (comma separated)"
                          className="px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 flex-1 min-w-[200px]"
                      />
                      <button
                          onClick={() => {
                              const nameInput = document.getElementById('newTPlanName') as HTMLInputElement;
                              const priceInput = document.getElementById('newTPlanPrice') as HTMLInputElement;
                              const durInput = document.getElementById('newTPlanDuration') as HTMLInputElement;
                              const benInput = document.getElementById('newTPlanBenefits') as HTMLInputElement;

                              if (!nameInput.value || !priceInput.value || !durInput.value) {
                                  alert("Please fill name, price, and duration.");
                                  return;
                              }

                              const newPlan: TeacherStorePlan = {
                                  id: `TPLAN_${Date.now()}`,
                                  name: nameInput.value,
                                  price: Number(priceInput.value),
                                  durationDays: Number(durInput.value),
                                  benefits: benInput.value.split(',').map(s => s.trim()).filter(Boolean),
                                  isActive: true
                              };

                              const updatedPlans = [...teacherStorePlans, newPlan];
                              setTeacherStorePlans(updatedPlans);
                              setLocalSettings({...localSettings, teacherStorePlans: updatedPlans});
                              saveSystemSettings({...localSettings, teacherStorePlans: updatedPlans});

                              nameInput.value = ''; priceInput.value = ''; durInput.value = ''; benInput.value = '';
                          }}
                          className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-indigo-700"
                      >
                          Add Plan
                      </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {teacherStorePlans.map((plan, idx) => (
                          <div key={idx} className="bg-white p-4 rounded-xl border border-indigo-100 shadow-sm relative">
                              <div className="flex justify-between items-start mb-2">
                                  <div>
                                      <h5 className="font-bold text-slate-800 text-lg">{plan.name}</h5>
                                      <p className="text-indigo-600 font-black">₹{plan.price} <span className="text-slate-600 font-normal text-xs">/ {plan.durationDays} days</span></p>
                                  </div>
                                  <div className="flex gap-2">
                                      <button
                                          onClick={() => {
                                              const updated = [...teacherStorePlans];
                                              updated[idx].isActive = !updated[idx].isActive;
                                              setTeacherStorePlans(updated);
                                              setLocalSettings({...localSettings, teacherStorePlans: updated});
                                              saveSystemSettings({...localSettings, teacherStorePlans: updated});
                                          }}
                                          className={`text-[10px] px-2 py-1 rounded-full font-bold ${plan.isActive ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-700 hover:bg-red-200'}`}
                                      >
                                          {plan.isActive ? 'Active' : 'Inactive'}
                                      </button>
                                      <button
                                          onClick={() => {
                                              if(window.confirm('Delete plan?')) {
                                                  const updated = teacherStorePlans.filter((_, i) => i !== idx);
                                                  setTeacherStorePlans(updated);
                                                  setLocalSettings({...localSettings, teacherStorePlans: updated});
                                                  saveSystemSettings({...localSettings, teacherStorePlans: updated});
                                              }
                                          }}
                                          className="text-slate-500 hover:text-red-500"
                                      >
                                          <Trash2 size={16}/>
                                      </button>
                                  </div>
                              </div>
                              <ul className="text-sm text-slate-600 list-disc list-inside mt-2 space-y-1">
                                  {plan.benefits.map((b, i) => <li key={i}>{b}</li>)}
                              </ul>
                          </div>
                      ))}
                  </div>
              </div>

              {/* Teachers Leaderboard / List */}
              <div className="mb-4 flex items-center justify-between">
                  <h4 className="font-bold text-slate-800">Registered Teachers</h4>
                  <div className="relative">
                      <Search className="absolute left-3 top-2.5 text-slate-500" size={16} />
                      <input type="text" placeholder="Search Teachers..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-purple-500 text-sm" />
                  </div>
              </div>

              <div className="overflow-x-auto border rounded-xl">
                  <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                          <tr className="uppercase text-[10px] font-bold tracking-wider">
                              <th className="p-4">Rank / Name</th>
                              <th className="p-4">Contact</th>
                              <th className="p-4">Class</th>
                              <th className="p-4">Code Used</th>
                              <th className="p-4">Active Time</th>
                              <th className="p-4 text-right">Actions</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {users.filter(u => u.role === 'TEACHER' && ((u.name || '').toLowerCase().includes((searchTerm || '').toLowerCase()) || (u.id || '').includes(searchTerm)))
                                .sort((a, b) => (b.totalActiveDays || 0) - (a.totalActiveDays || 0))
                                .map((u, index) => (
                              <tr key={u.id} className="hover:bg-slate-50 transition-colors group">
                                  <td className="p-4">
                                      <div className="flex items-center gap-3">
                                          {index < 3 ? (
                                              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-white shadow-md ${index === 0 ? 'bg-yellow-400' : index === 1 ? 'bg-slate-300' : 'bg-amber-600'}`}>
                                                  #{index + 1}
                                              </div>
                                          ) : (
                                              <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center font-bold text-xs">
                                                  #{index + 1}
                                              </div>
                                          )}
                                          <div>
                                              <p className="font-bold text-slate-800 flex items-center gap-1">
                                                  {u.name} {index < 3 && <Award size={14} className="text-yellow-500"/>}
                                              </p>
                                              <p className="text-[10px] text-slate-500 font-mono">{u.id}</p>
                                          </div>
                                      </div>
                                  </td>
                                  <td className="p-4">
                                      <p className="text-xs text-slate-600">{u.email}</p>
                                      <p className="text-[10px] text-slate-500 font-mono">{u.mobile}</p>
                                  </td>
                                  <td className="p-4 font-bold text-slate-700">{u.classLevel || '-'}</td>
                                  <td className="p-4"><span className="px-2 py-1 bg-purple-50 text-purple-700 rounded font-mono text-[10px] font-bold border border-purple-100">{u.teacherCode || 'N/A'}</span></td>
                                  <td className="p-4 font-bold text-blue-600">{u.totalActiveDays || 0} days</td>
                                  <td className="p-4 text-right flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <button onClick={() => openEditUser(u)} className="p-2 text-slate-500 hover:text-orange-600 bg-white shadow-sm border border-slate-200 rounded-lg" title="Edit"><Edit3 size={14} /></button>
                                      <button onClick={() => deleteUser(u.id)} className="p-2 text-slate-500 hover:text-red-600 bg-white shadow-sm border border-slate-200 rounded-lg" title="Delete"><Trash2 size={14} /></button>
                                  </td>
                              </tr>
                          ))}
                          {users.filter(u => u.role === 'TEACHER').length === 0 && (
                              <tr>
                                  <td colSpan={6} className="p-8 text-center text-slate-500 font-bold">No teachers registered yet.</td>
                              </tr>
                          )}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

      {/* --- USERS TAB (Enhanced) --- */}
      {activeTab === 'USERS' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center gap-4 mb-6"><button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button><h3 className="text-xl font-black text-slate-800">User Management</h3></div>
              <div className="relative mb-6">
                  <Search className="absolute left-3 top-3 text-slate-500" size={18} />
                  <input type="text" placeholder="Search by Name or ID..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
              <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 border-b border-slate-100 text-slate-600"><tr className="uppercase text-xs"><th className="p-4">User</th><th className="p-4">Credits</th><th className="p-4">Role</th><th className="p-4 text-right">Actions</th></tr></thead>
                      <tbody className="divide-y divide-slate-50">
                          {users.filter(u => (u.name || '').toLowerCase().includes((searchTerm || '').toLowerCase()) || (u.id || '').includes(searchTerm)).map(u => (
                              <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                                  <td className="p-4"><p className="font-bold text-slate-800">{u.name}</p><p className="text-xs text-slate-500 font-mono">{u.id}</p></td>
                                  <td className="p-4 font-bold text-blue-600">{u.credits}</td>
                                  <td className="p-4"><span className={`px-2 py-1 rounded text-xs font-bold ${u.role === 'ADMIN' ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600'}`}>{u.role}</span></td>
                                  <td className="p-4 text-right flex justify-end gap-2">
                                      {u.role !== 'ADMIN' && (
                                          <>
                                              <button onClick={() => setViewingUserHistory(u)} className="p-2 text-slate-500 hover:text-purple-600 bg-slate-50 rounded-lg" title="View Full History"><Activity size={16} /></button>
                                              <button onClick={() => setDmUser(u)} className="p-2 text-slate-500 hover:text-blue-600 bg-slate-50 rounded-lg" title="Message"><MessageSquare size={16} /></button>
                                              <button onClick={() => openEditUser(u)} className="p-2 text-slate-500 hover:text-orange-600 bg-slate-50 rounded-lg" title="Edit"><Edit3 size={16} /></button>
                                              <button onClick={() => {
                                                  if(confirm(`Login as ${u.name}? You will be switched to their dashboard.`)) {
                                                      onImpersonate && onImpersonate(u);
                                                  }
                                              }} className="p-2 text-slate-500 hover:text-green-600 bg-slate-50 rounded-lg" title="Impersonate (Login as User)"><Eye size={16} /></button>
                                              <button onClick={() => deleteUser(u.id)} className="p-2 text-slate-500 hover:text-red-600 bg-slate-50 rounded-lg" title="Delete"><Trash2 size={16} /></button>
                                          </>
                                      )}
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

      {/* --- USER HISTORY MODAL --- */}
      {viewingUserHistory && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
              <div className="bg-white p-6 rounded-2xl w-full max-w-4xl shadow-2xl max-h-[90vh] overflow-y-auto animate-in fade-in">
                  <div className="flex justify-between items-center mb-6 border-b pb-4">
                      <div>
                          <h3 className="text-xl font-black text-slate-800 flex items-center gap-2"><Activity className="text-purple-600"/> Student History</h3>
                          <p className="text-sm text-slate-600">
                              Activity for: <span className="font-bold text-purple-600">{viewingUserHistory.name}</span> (ID: {viewingUserHistory.id})
                          </p>
                      </div>
                      <button onClick={() => setViewingUserHistory(null)} className="p-2 hover:bg-slate-100 rounded-full">
                          <X size={24} className="text-slate-500" />
                      </button>
                  </div>

                  <div className="space-y-8">
                      {/* STATISTICAL SUMMARY (Non-AI) */}
                      <div className="bg-gradient-to-r from-slate-50 to-blue-50 p-4 rounded-2xl border border-slate-200">
                          <h4 className="font-bold text-slate-700 mb-3 text-xs uppercase tracking-widest">Performance Summary (Calculated)</h4>
                          <div className="grid grid-cols-4 gap-4">
                              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                                  <p className="text-[10px] font-bold text-slate-500 uppercase">Total Tests</p>
                                  <p className="text-xl font-black text-slate-800">{viewingUserHistory.mcqHistory?.length || 0}</p>
                              </div>
                              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                                  <p className="text-[10px] font-bold text-slate-500 uppercase">Avg. Score</p>
                                  <p className="text-xl font-black text-blue-600">
                                      {viewingUserHistory.mcqHistory && viewingUserHistory.mcqHistory.length > 0
                                          ? Math.round(viewingUserHistory.mcqHistory.reduce((acc: any, h: any) => acc + (h.totalQuestions > 0 ? (h.score/h.totalQuestions)*100 : 0), 0) / viewingUserHistory.mcqHistory.length)
                                          : 0}%
                                  </p>
                              </div>
                              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                                  <p className="text-[10px] font-bold text-slate-500 uppercase">Accuracy</p>
                                  <p className="text-xl font-black text-green-600">
                                      {(() => {
                                          const hist = viewingUserHistory.mcqHistory || [];
                                          const totalQ = hist.reduce((acc: any, h: any) => acc + h.totalQuestions, 0);
                                          const correct = hist.reduce((acc: any, h: any) => acc + h.correctCount, 0);
                                          return totalQ > 0 ? Math.round((correct/totalQ)*100) : 0;
                                      })()}%
                                  </p>
                              </div>
                              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                                  <p className="text-[10px] font-bold text-slate-500 uppercase">Avg Time/Q</p>
                                  <p className="text-xl font-black text-purple-600">
                                      {(() => {
                                          const hist = viewingUserHistory.mcqHistory || [];
                                          const totalQ = hist.reduce((acc: any, h: any) => acc + h.totalQuestions, 0);
                                          const totalTime = hist.reduce((acc: any, h: any) => acc + h.totalTimeSeconds, 0);
                                          return totalQ > 0 ? (totalTime/totalQ).toFixed(1) : 0;
                                      })()}s
                                  </p>
                              </div>
                          </div>
                      </div>

                      {/* 1. MCQ RESULTS */}
                      <div>
                          <h4 className="font-bold text-slate-700 mb-3 flex items-center gap-2"><CheckCircle size={18}/> Test Performance</h4>
                          <div className="max-h-60 overflow-y-auto border rounded-xl">
                              <table className="w-full text-left text-xs">
                                  <thead className="bg-slate-50 font-bold text-slate-600 uppercase sticky top-0">
                                      <tr>
                                          <th className="p-3">Date</th>
                                          <th className="p-3">Test/Chapter</th>
                                          <th className="p-3">Score</th>
                                          <th className="p-3">Time</th>
                                          <th className="p-3">Tag</th>
                                      </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100">
                                      {(!viewingUserHistory.mcqHistory || viewingUserHistory.mcqHistory.length === 0) && (
                                          <tr><td colSpan={5} className="p-4 text-center text-slate-500">No tests taken yet.</td></tr>
                                      )}
                                      {(viewingUserHistory.mcqHistory || []).map((res: any) => (
                                          <tr key={res.id} className="hover:bg-slate-50">
                                              <td className="p-3 text-slate-600">{res.date && !isNaN(new Date(res.date).getTime()) ? new Date(res.date).toLocaleDateString() : 'N/A'}</td>
                                              <td className="p-3 font-bold text-slate-700">{res.chapterTitle}</td>
                                              <td className="p-3 font-bold text-blue-600">{res.score}/{res.totalQuestions} ({Math.round(res.score/res.totalQuestions*100)}%)</td>
                                              <td className="p-3 text-slate-600">{Math.round(res.totalTimeSeconds || 0)}s</td>
                                              <td className="p-3">
                                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                                      res.performanceTag === 'EXCELLENT' ? 'bg-green-100 text-green-700' : 
                                                      res.performanceTag === 'GOOD' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'
                                                  }`}>
                                                      {res.performanceTag}
                                                  </span>
                                              </td>
                                          </tr>
                                      ))}
                                  </tbody>
                              </table>
                          </div>
                      </div>

                      {/* 2. AI ANALYSIS HISTORY */}
                      <div>
                          <h4 className="font-bold text-slate-700 mb-3 flex items-center gap-2"><BrainCircuit size={18}/> AI Analysis Reports</h4>
                          <div className="max-h-60 overflow-y-auto border rounded-xl bg-slate-50 p-4 space-y-3">
                              {analysisLogs.filter(l => l.userId === viewingUserHistory.id).length === 0 && (
                                  <p className="text-slate-500 text-center text-xs">No analysis reports found.</p>
                              )}
                              {analysisLogs.filter(l => l.userId === viewingUserHistory.id).map(log => (
                                  <div key={log.id} className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                                      <div className="flex justify-between items-start mb-2">
                                          <p className="font-bold text-xs text-slate-700">{log.chapter} ({log.subject})</p>
                                          <span className="text-[10px] text-slate-500">{log.date && !isNaN(new Date(log.date).getTime()) ? new Date(log.date).toLocaleString() : 'N/A'}</span>
                                      </div>
                                      <div className="text-[10px] text-slate-600 bg-slate-50 p-2 rounded whitespace-pre-wrap font-mono max-h-20 overflow-y-auto">
                                          {log.aiResponse}
                                      </div>
                                  </div>
                              ))}
                          </div>
                      </div>

                      {/* 3. USAGE LOGS */}
                      <div>
                          <h4 className="font-bold text-slate-700 mb-3 flex items-center gap-2"><ListChecks size={18}/> Activity Log</h4>
                          <div className="max-h-60 overflow-y-auto border rounded-xl">
                              <table className="w-full text-left text-xs">
                                  <thead className="bg-slate-50 font-bold text-slate-600 uppercase sticky top-0">
                                      <tr>
                                          <th className="p-3">Time</th>
                                          <th className="p-3">Action</th>
                                          <th className="p-3">Details</th>
                                      </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100">
                                      {(!viewingUserHistory.usageHistory || viewingUserHistory.usageHistory.length === 0) && (
                                          <tr><td colSpan={3} className="p-4 text-center text-slate-500">No activity recorded.</td></tr>
                                      )}
                                      {(viewingUserHistory.usageHistory || []).map((act: any) => (
                                          <tr key={act.id} className="hover:bg-slate-50">
                                              <td className="p-3 text-slate-600 whitespace-nowrap">{act.timestamp && !isNaN(new Date(act.timestamp).getTime()) ? new Date(act.timestamp).toLocaleString() : 'N/A'}</td>
                                              <td className="p-3 font-bold text-slate-700">{act.type}</td>
                                              <td className="p-3 text-slate-600">{act.itemTitle} {act.amount ? `(${act.amount})` : ''}</td>
                                          </tr>
                                      ))}
                                  </tbody>
                              </table>
                          </div>
                      </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end">
                       <button onClick={() => setViewingUserHistory(null)} className="px-6 py-2 bg-slate-800 text-white font-bold rounded-lg hover:bg-slate-900">Close History</button>
                  </div>
              </div>
          </div>
      )}


      {/* --- EDIT USER MODAL --- */}
      {editingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
              <div className="bg-white p-6 rounded-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
                  <h3 className="text-lg font-bold mb-4">Edit User: {editingUser.name}</h3>
                  <div className="space-y-4">
                      {/* CREDITS */}
                      <div>
                          <label className="text-xs font-bold text-slate-600 uppercase">💎 Credits</label>
                          <input type="number" value={editUserCredits} onChange={e => setEditUserCredits(Number(e.target.value))} className="w-full p-2 border rounded-lg" />
                      </div>
                      
                      {/* PASSWORD */}
                      <div>
                          <label className="text-xs font-bold text-slate-600 uppercase">🔐 Password</label>
                          <input type="text" value={editUserPass} onChange={e => setEditUserPass(e.target.value)} className="w-full p-2 border rounded-lg" />
                      </div>

                      {/* SUBSCRIPTION TIER */}
                      <div className="border-t pt-3">
                          <label className="text-xs font-bold text-slate-600 uppercase">👑 Grant Subscription</label>
                          <div className="grid grid-cols-2 gap-2 mt-2">
                              <button onClick={() => { setEditSubscriptionTier('FREE'); setEditSubscriptionPrice(0); }} className={`p-2 rounded font-bold text-xs ${editSubscriptionTier === 'FREE' ? 'bg-slate-200 text-slate-800' : 'bg-slate-100 text-slate-600'}`}>FREE</button>
                              <button onClick={() => { setEditSubscriptionTier('WEEKLY'); updatePriceForSelection('WEEKLY', editSubscriptionLevel); }} className={`p-2 rounded font-bold text-xs ${editSubscriptionTier === 'WEEKLY' ? 'bg-green-200 text-green-800' : 'bg-green-50 text-green-600'}`}>⏰ WEEKLY</button>
                              <button onClick={() => { setEditSubscriptionTier('MONTHLY'); updatePriceForSelection('MONTHLY', editSubscriptionLevel); }} className={`p-2 rounded font-bold text-xs ${editSubscriptionTier === 'MONTHLY' ? 'bg-blue-200 text-blue-800' : 'bg-blue-50 text-blue-600'}`}>📆 MONTHLY</button>
                              <button onClick={() => { setEditSubscriptionTier('3_MONTHLY'); updatePriceForSelection('3_MONTHLY', editSubscriptionLevel); }} className={`p-2 rounded font-bold text-xs ${editSubscriptionTier === '3_MONTHLY' ? 'bg-indigo-200 text-indigo-800' : 'bg-indigo-50 text-indigo-600'}`}>📅 3 MONTHLY</button>
                              <button onClick={() => { setEditSubscriptionTier('YEARLY'); updatePriceForSelection('YEARLY', editSubscriptionLevel); }} className={`p-2 rounded font-bold text-xs ${editSubscriptionTier === 'YEARLY' ? 'bg-purple-200 text-purple-800' : 'bg-purple-50 text-purple-600'}`}>📅 YEARLY</button>
                              <button onClick={() => { setEditSubscriptionTier('LIFETIME'); updatePriceForSelection('LIFETIME', editSubscriptionLevel); }} className={`p-2 rounded font-bold text-xs ${editSubscriptionTier === 'LIFETIME' ? 'bg-yellow-200 text-yellow-800' : 'bg-yellow-50 text-yellow-600'}`}>🌟 LIFETIME</button>
                              <button onClick={() => { setEditSubscriptionTier('CUSTOM'); setEditSubscriptionPrice(0); }} className={`p-2 rounded font-bold text-xs ${editSubscriptionTier === 'CUSTOM' ? 'bg-pink-200 text-pink-800' : 'bg-pink-50 text-pink-600'}`}>⚙️ CUSTOMIZED</button>
                          </div>
                      </div>

                      {/* SUBSCRIPTION LEVEL */}
                      {editSubscriptionTier !== 'FREE' && (
                          <div className="mt-2">
                              <label className="text-xs font-bold text-slate-600 uppercase">Level (For Real Users)</label>
                              <div className="grid grid-cols-2 gap-2 mt-1">
                                  <button onClick={() => { setEditSubscriptionLevel('BASIC'); updatePriceForSelection(editSubscriptionTier, 'BASIC'); }} className={`p-2 rounded font-bold text-xs border ${editSubscriptionLevel === 'BASIC' ? 'bg-blue-100 border-blue-300 text-blue-800' : 'bg-white border-slate-200'}`}>BASIC</button>
                                  <button onClick={() => { setEditSubscriptionLevel('ULTRA'); updatePriceForSelection(editSubscriptionTier, 'ULTRA'); }} className={`p-2 rounded font-bold text-xs border ${editSubscriptionLevel === 'ULTRA' ? 'bg-purple-100 border-purple-300 text-purple-800' : 'bg-white border-slate-200'}`}>ULTRA</button>
                              </div>
                          </div>
                      )}

                      {editSubscriptionTier === 'CUSTOM' && (
                          <div className="space-y-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                              <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase">Custom Name (Hidden)</label>
                                  <input 
                                      type="text" 
                                      placeholder="Basic Ultra" 
                                      value={editCustomSubName} 
                                      onChange={e => setEditCustomSubName(e.target.value)}
                                      className="w-full p-2 border rounded-lg text-sm"
                                  />
                              </div>
                              <div className="grid grid-cols-3 gap-2">
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-bold text-slate-500 uppercase">Y</label>
                                      <input type="number" value={editSubscriptionYears} onChange={e => setEditSubscriptionYears(Number(e.target.value))} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-bold text-slate-500 uppercase">M</label>
                                      <input type="number" value={editSubscriptionMonths} onChange={e => setEditSubscriptionMonths(Number(e.target.value))} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-bold text-slate-500 uppercase">D</label>
                                      <input type="number" value={editSubscriptionDays} onChange={e => setEditSubscriptionDays(Number(e.target.value))} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-bold text-slate-500 uppercase">H</label>
                                      <input type="number" value={editSubscriptionHours} onChange={e => setEditSubscriptionHours(Number(e.target.value))} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-bold text-slate-500 uppercase">Min</label>
                                      <input type="number" value={editSubscriptionMinutes} onChange={e => setEditSubscriptionMinutes(Number(e.target.value))} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                                  <div className="space-y-1">
                                      <label className="text-[10px] font-bold text-slate-500 uppercase">Sec</label>
                                      <input type="number" value={editSubscriptionSeconds} onChange={e => setEditSubscriptionSeconds(Number(e.target.value))} className="w-full p-2 border rounded-lg text-sm" />
                                  </div>
                              </div>
                          </div>
                      )}

                      {/* SUBSCRIPTION LEVEL */}
                      {editSubscriptionTier !== 'FREE' && (
                          <div className="mt-2">
                              <label className="text-xs font-bold text-slate-600 uppercase">Level (For Real Users)</label>
                              <div className="grid grid-cols-2 gap-2 mt-1">
                                  <button onClick={() => { setEditSubscriptionLevel('BASIC'); updatePriceForSelection(editSubscriptionTier, 'BASIC'); }} className={`p-2 rounded font-bold text-xs border ${editSubscriptionLevel === 'BASIC' ? 'bg-blue-100 border-blue-300 text-blue-800' : 'bg-white border-slate-200'}`}>BASIC</button>
                                  <button onClick={() => { setEditSubscriptionLevel('ULTRA'); updatePriceForSelection(editSubscriptionTier, 'ULTRA'); }} className={`p-2 rounded font-bold text-xs border ${editSubscriptionLevel === 'ULTRA' ? 'bg-purple-100 border-purple-300 text-purple-800' : 'bg-white border-slate-200'}`}>ULTRA</button>
                              </div>
                          </div>
                      )}

                      {/* STANDARD DURATION INFO (NON-EDITABLE) */}
                      {editSubscriptionTier !== 'FREE' && editSubscriptionTier !== 'CUSTOM' && (
                          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                              <label className="text-xs font-bold text-slate-600 uppercase mb-1 block">📅 Duration (Fixed)</label>
                              <p className="font-black text-slate-800">
                                  {editSubscriptionTier === 'WEEKLY' ? '7 Days' :
                                   editSubscriptionTier === 'MONTHLY' ? '30 Days' :
                                   editSubscriptionTier === '3_MONTHLY' ? '90 Days (3 Months)' :
                                   editSubscriptionTier === 'YEARLY' ? '365 Days (1 Year)' :
                                   editSubscriptionTier === 'LIFETIME' ? 'Lifetime (Forever)' : 'Custom'}
                              </p>
                          </div>
                      )}

                      {/* SUBSCRIPTION PRICE */}
                      {editSubscriptionTier !== 'FREE' && (
                          <div>
                              <label className="text-xs font-bold text-slate-600 uppercase">💰 Subscription Price (₹)</label>
                              <input 
                                  type="number" 
                                  value={editSubscriptionPrice} 
                                  onChange={e => setEditSubscriptionPrice(Number(e.target.value))} 
                                  className={`w-full p-2 border rounded-lg ${editSubscriptionTier !== 'CUSTOM' ? 'bg-slate-100 text-slate-600' : 'bg-white font-bold'}`}
                                  disabled={editSubscriptionTier !== 'CUSTOM'}
                              />
                              <p className="text-[10px] text-slate-600 mt-1">
                                  {editSubscriptionTier === 'CUSTOM' 
                                      ? "Set custom price manually." 
                                      : "Price automatically set based on Store Plans."}
                              </p>
                          </div>
                      )}

                      {/* BUTTONS (SPLIT FOR FREE VS PAID) */}
                      <div className="flex gap-2 pt-4 border-t">
                          <button onClick={() => setEditingUser(null)} className="flex-1 py-2 text-slate-600 hover:bg-slate-100 rounded font-bold text-xs">Cancel</button>
                          
                          {/* ONLY MAIN ADMIN CAN GRANT FREE SUB */}
                          {currentUser?.role === 'ADMIN' && (
                              <button onClick={() => handleGrantSubscription('FREE')} className="flex-1 py-2 bg-green-600 text-white rounded-lg font-bold text-xs hover:bg-green-700 shadow">
                                  🎁 Grant Free
                              </button>
                          )}
                          
                          <button onClick={() => handleGrantSubscription('PAID')} className="flex-1 py-2 bg-blue-600 text-white rounded-lg font-bold text-xs hover:bg-blue-700 shadow">
                              💳 Record Paid
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* --- DM USER MODAL WITH GIFT --- */}
      {dmUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
              <div className="bg-white p-6 rounded-2xl w-full shadow-2xl animate-in fade-in max-h-[90vh] overflow-y-auto">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                      <Gift className="text-pink-500" /> Gift & Message
                  </h3>
                  <p className="text-xs text-slate-600 mb-2">To: <span className="font-bold text-slate-800">{dmUser.name}</span></p>
                  
                  <textarea 
                      value={dmText} 
                      onChange={e => setDmText(e.target.value)} 
                      className="w-full h-24 p-3 border rounded-xl mb-4 text-sm" 
                      placeholder="Write a message..." 
                  />

                  <div className="bg-pink-50 p-4 rounded-xl border border-pink-100 mb-4">
                      <label className="text-xs font-bold text-pink-700 uppercase block mb-2">Attach Gift</label>
                      <select 
                          value={giftType} 
                          onChange={e => setGiftType(e.target.value as any)} 
                          className="w-full p-2 border rounded-lg text-sm mb-2"
                      >
                          <option value="NONE">None</option>
                          <option value="CREDITS">Credits (Coins)</option>
                          <option value="SUBSCRIPTION">Subscription</option>
                          {/* <option value="ANIMATION">Unlock Animation</option> */}
                      </select>

                      {giftType === 'CREDITS' && (
                          <input 
                              type="number" 
                              placeholder="Amount (e.g. 100)" 
                              value={giftValue} 
                              onChange={e => setGiftValue(Number(e.target.value))} 
                              className="w-full p-2 border rounded-lg text-sm"
                          />
                      )}

                      {giftType === 'SUBSCRIPTION' && (
                          <div className="space-y-2">
                              <select 
                                  value={giftValue} 
                                  onChange={e => setGiftValue(e.target.value)} 
                                  className="w-full p-2 border rounded-lg text-sm"
                              >
                                  <option value="">Select Plan</option>
                                  <option value="WEEKLY_BASIC">Weekly Basic</option>
                                  <option value="WEEKLY_ULTRA">Weekly Ultra</option>
                                  <option value="MONTHLY_BASIC">Monthly Basic</option>
                                  <option value="MONTHLY_ULTRA">Monthly Ultra</option>
                                  <option value="YEARLY_BASIC">Yearly Basic</option>
                                  <option value="YEARLY_ULTRA">Yearly Ultra</option>
                              </select>
                              <div className="flex gap-2 items-center">
                                  <label className="text-xs text-slate-600">Duration (Days):</label>
                                  <input 
                                      type="number" 
                                      value={giftDuration / 24}
                                      onChange={e => setGiftDuration(Number(e.target.value) * 24)}
                                      className="w-20 p-2 border rounded-lg text-sm"
                                      min="1"
                                  />
                              </div>
                          </div>
                      )}
                  </div>

                  <div className="flex gap-2">
                      <button onClick={() => {setDmUser(null); setGiftType('NONE');}} className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 rounded-xl">Cancel</button>
                      <button onClick={sendDirectMessage} className="flex-1 py-3 bg-pink-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg hover:bg-pink-700">
                          <Gift size={18} /> Send Gift
                      </button>
                  </div>
              </div>
          </div>
      )}

      {activeTab === 'UNIVERSAL_PLAYLIST' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-rose-800">Universal Video Playlist</h3>
              </div>
              
              <div className="bg-rose-50 p-6 rounded-xl border border-rose-200">
                  <div className="flex items-center gap-2 mb-4">
                      <Youtube size={24} className="text-rose-600" />
                      <h4 className="font-bold text-rose-900">Manage Universal Videos</h4>
                  </div>
                  <p className="text-xs text-rose-700 mb-6 bg-white p-3 rounded-lg border border-rose-100">
                      These videos will be visible to ALL students on their dashboard. Use this for announcements, special lectures, or featured content.
                  </p>

                  <div className="space-y-4 mb-6">
                      {universalVideos.map((vid, i) => (
                          <div key={i} className="flex flex-col gap-2 bg-white p-4 rounded-xl border border-rose-100 shadow-sm">
                              <div className="flex gap-2 items-center">
                                  <span className="w-8 text-center text-xs font-bold text-rose-500 bg-rose-50 rounded py-2">{i + 1}</span>
                                  <input 
                                      type="text" 
                                      value={vid.title} 
                                      onChange={(e) => {
                                          const updated = [...universalVideos];
                                          updated[i] = {...updated[i], title: e.target.value};
                                          setUniversalVideos(updated);
                                      }}
                                      placeholder="Video Title"
                                      className="flex-1 p-2 border border-slate-200 rounded text-xs font-bold"
                                  />
                                  <select 
                                      value={vid.access || 'FREE'} 
                                      onChange={(e) => {
                                          const updated = [...universalVideos];
                                          updated[i] = {...updated[i], access: e.target.value};
                                          setUniversalVideos(updated);
                                      }}
                                      className="w-24 p-2 border border-slate-200 rounded text-xs bg-slate-50"
                                  >
                                      <option value="FREE">Free</option>
                                      <option value="BASIC">Basic</option>
                                      <option value="ULTRA">Ultra</option>
                                  </select>
                                  <button 
                                      onClick={() => {
                                          const updated = universalVideos.filter((_, idx) => idx !== i);
                                          setUniversalVideos(updated);
                                      }}
                                      className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                                  >
                                      <Trash2 size={16} />
                                  </button>
                              </div>
                              <input 
                                  type="text" 
                                  value={vid.url || ''} 
                                  onChange={(e) => {
                                      const updated = [...universalVideos];
                                      updated[i] = {...updated[i], url: e.target.value};
                                      setUniversalVideos(updated);
                                  }}
                                  placeholder="YouTube URL (e.g. https://youtu.be/...)"
                                  className="w-full p-2 border border-slate-200 rounded text-xs font-mono text-blue-600 bg-slate-50" 
                              />
                          </div>
                      ))}
                  </div>

                  <div className="flex gap-2">
                      <button 
                          onClick={() => setUniversalVideos([...universalVideos, {title: '', url: '', price: 0, access: 'FREE'}])}
                          className="flex-1 py-3 bg-white border border-rose-200 text-rose-600 font-bold rounded-xl hover:bg-rose-50 transition dashed"
                      >
                          + Add Universal Video
                      </button>
                      <button onClick={() => saveUniversalPlaylist()} className="flex-1 bg-rose-600 text-white font-bold py-3 rounded-xl shadow hover:bg-rose-700 transition">
                          💾 Save Playlist
                      </button>
                  </div>
              </div>
          </div>
      )}


      {activeTab === 'TOPIC_NOTES_MANAGER' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-cyan-800">Topic Notes 2.0</h3>
              </div>

              <div className="bg-cyan-50 p-6 rounded-xl border border-cyan-200">
                  <div className="flex items-center gap-2 mb-4">
                      <BookOpen size={24} className="text-cyan-600" />
                      <h4 className="font-bold text-cyan-900">Manage Topic-Specific Notes</h4>
                  </div>
                  <p className="text-xs text-cyan-700 mb-6 bg-white p-3 rounded-lg border border-cyan-100">
                      These notes are linked to specific topics within a chapter. They will <b>NOT</b> appear on the main course page list, but can be accessed via search or recommendations.
                  </p>

                  <SubjectSelector />

                  <div className="space-y-4 mb-6">
                      {!editingChapterId ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[60vh] overflow-y-auto pr-2">
                              {selChapters.length === 0 && <p className="col-span-full text-center text-slate-500 text-sm py-8">Select a subject to view lessons.</p>}
                              {selChapters.map((ch) => {
                                  // We can't easily filter topicNotes here without loading them all, so we show counts if possible or just button
                                  return (
                                      <div key={ch.id} className="bg-white p-3 rounded-xl border border-cyan-100 shadow-sm flex flex-col gap-2">
                                          <div className="flex justify-between items-center">
                                              <h5 className="font-bold text-slate-800 text-xs truncate w-3/4" title={ch.title}>{ch.title}</h5>
                                          </div>
                                          <button
                                              onClick={() => loadChapterContent(ch.id)}
                                              className="mt-2 w-full py-2 bg-cyan-600 text-white rounded-lg text-xs font-bold shadow-md hover:bg-cyan-700 flex items-center justify-center gap-2"
                                          >
                                              <Edit3 size={14} /> Manage Topic Notes
                                          </button>
                                      </div>
                                  );
                              })}
                          </div>
                      ) : (
                          <div className="bg-white p-4 rounded-xl border border-cyan-200">
                              <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-3">
                                  <div>
                                      <h4 className="font-black text-slate-800 text-lg">{selChapters.find(c => c.id === editingChapterId)?.title}</h4>
                                      <p className="text-xs text-slate-600">Managing Hidden Topic Notes</p>
                                  </div>
                                  <button onClick={() => setEditingChapterId(null)} className="text-xs font-bold text-slate-500 hover:text-slate-600">Close Editor</button>
                              </div>

                              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2 pb-24">
                                  {topicNotes.map((note, idx) => (
                                      <div key={note.id || idx} className="flex flex-col gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
                                          <div className="flex gap-2 items-center">
                                              <span className="w-6 text-center text-xs font-bold text-slate-500">{idx + 1}</span>
                                              <input
                                                  type="text"
                                                  value={note.topic}
                                                  onChange={(e) => {
                                                      const oldTopic = note.topic;
                                                      const newTopic = e.target.value;

                                                      // 1. Update Note
                                                      const updatedNotes = [...topicNotes];
                                                      updatedNotes[idx] = { ...updatedNotes[idx], topic: newTopic, title: `Note: ${newTopic}` };
                                                      setTopicNotes(updatedNotes);

                                                      // 2. Sync Linked MCQs (Prevent orphans)
                                                      if (oldTopic && oldTopic !== newTopic) {
                                                          const updatedMcqs = editingMcqs.map(q =>
                                                              (q.topic && (q.topic || '').toLowerCase() === (oldTopic || '').toLowerCase())
                                                                  ? { ...q, topic: newTopic }
                                                                  : q
                                                          );
                                                          setEditingMcqs(updatedMcqs);
                                                      }
                                                  }}
                                                  placeholder="Topic Name (e.g. Newton's Law)"
                                                  className="flex-1 p-2 border border-slate-200 rounded text-xs font-bold"
                                              />
                                              <div className="flex items-center gap-2">
                                                  <label className="text-[10px] font-bold text-slate-600">Premium?</label>
                                                  <input
                                                      type="checkbox"
                                                      checked={note.isPremium}
                                                      onChange={(e) => {
                                                          const updated = [...topicNotes];
                                                          updated[idx] = { ...updated[idx], isPremium: e.target.checked };
                                                          setTopicNotes(updated);
                                                      }}
                                                  />
                                              </div>
                                              <button
                                                  onClick={() => {
                                                      const updated = topicNotes.filter((_, i) => i !== idx);
                                                      setTopicNotes(updated);
                                                  }}
                                                  className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                                              >
                                                  <Trash2 size={16} />
                                              </button>
                                          </div>
                                          <textarea
                                              value={note.content || ''}
                                              onChange={(e) => {
                                                  const updated = [...topicNotes];
                                                  updated[idx] = { ...updated[idx], content: e.target.value };
                                                  setTopicNotes(updated);
                                              }}
                                              placeholder="HTML Content for Note..."
                                              className="w-full h-24 p-2 border border-slate-200 rounded text-xs font-mono text-slate-600 bg-white ml-8"
                                          />

                                          {/* LINKED MCQS MANAGER */}
                                          <div className="ml-8 mt-2 p-3 bg-white border border-dashed border-cyan-300 rounded-lg">
                                              <div className="flex justify-between items-center mb-2">
                                                  <div>
                                                      <h5 className="text-[10px] font-bold text-cyan-700 uppercase flex items-center gap-1">
                                                          <CheckCircle size={12} /> Linked MCQs ({editingMcqs.filter(q => q.topic && (q.topic || '').toLowerCase() === (note.topic || '').toLowerCase()).length})
                                                      </h5>
                                                      <p className="text-[9px] text-slate-500">These will appear in Revision Hub.</p>
                                                  </div>
                                                  <button
                                                      onClick={() => {
                                                          const newQ: MCQItem = {
                                                              question: 'New Question',
                                                              options: ['A', 'B', 'C', 'D'],
                                                              correctAnswer: 0,
                                                              explanation: '',
                                                              topic: note.topic // Auto-link
                                                          };
                                                          setEditingMcqs([...editingMcqs, newQ]);
                                                      }}
                                                      className="text-[9px] bg-cyan-100 text-cyan-700 px-2 py-1 rounded font-bold hover:bg-cyan-200"
                                                  >
                                                      + Add MCQ
                                                  </button>
                                              </div>

                                              {/* LIST LINKED MCQS */}
                                              <div className="space-y-2">
                                                  {editingMcqs.map((q, qIdx) => {
                                                      // Only show matching topics
                                                      if (!q.topic || (q.topic || '').toLowerCase() !== (note.topic || '').toLowerCase()) return null;

                                                      return (
                                                          <div key={qIdx} className="p-2 border border-slate-100 rounded bg-slate-50 relative group">
                                                              <div className="flex gap-2 mb-1">
                                                                  <input
                                                                      type="text"
                                                                      value={q.question}
                                                                      onChange={e => {
                                                                          const updated = [...editingMcqs];
                                                                          updated[qIdx].question = e.target.value;
                                                                          setEditingMcqs(updated);
                                                                      }}
                                                                      className="flex-1 p-1 text-xs border rounded font-bold"
                                                                      placeholder="Question"
                                                                  />
                                                                  <button
                                                                      onClick={() => {
                                                                          const updated = editingMcqs.filter((_, i) => i !== qIdx);
                                                                          setEditingMcqs(updated);
                                                                      }}
                                                                      className="text-red-400 hover:text-red-600"
                                                                  >
                                                                      <Trash2 size={12} />
                                                                  </button>
                                                              </div>

                                                              <div className="grid grid-cols-2 gap-1 mb-1">
                                                                  {q.options.map((opt, oIdx) => (
                                                                      <div key={oIdx} className="flex items-center gap-1">
                                                                          <input
                                                                              type="radio"
                                                                              checked={q.correctAnswer === oIdx}
                                                                              onChange={() => {
                                                                                  const updated = [...editingMcqs];
                                                                                  updated[qIdx].correctAnswer = oIdx;
                                                                                  setEditingMcqs(updated);
                                                                              }}
                                                                              className="w-3 h-3 accent-green-600"
                                                                          />
                                                                          <input
                                                                              type="text"
                                                                              value={opt}
                                                                              onChange={e => {
                                                                                  const updated = [...editingMcqs];
                                                                                  updated[qIdx].options[oIdx] = e.target.value;
                                                                                  setEditingMcqs(updated);
                                                                              }}
                                                                              className="flex-1 p-1 text-[10px] border rounded"
                                                                          />
                                                                      </div>
                                                                  ))}
                                                              </div>
                                                              <textarea
                                                                  value={q.explanation || ''}
                                                                  onChange={e => {
                                                                      const updated = [...editingMcqs];
                                                                      updated[qIdx].explanation = e.target.value;
                                                                      setEditingMcqs(updated);
                                                                  }}
                                                                  placeholder="Explanation..."
                                                                  className="w-full p-1 text-[10px] border rounded bg-white h-8 resize-none"
                                                              />
                                                          </div>
                                                      );
                                                  })}
                                              </div>
                                          </div>
                                      </div>
                                  ))}
                              </div>

                              <div className="mt-4 flex gap-2">
                                  <button
                                      onClick={() => setTopicNotes([...topicNotes, {
                                          id: `note-${Date.now()}`,
                                          title: 'New Note',
                                          topic: '',
                                          content: '',
                                          isPremium: true
                                      }])}
                                      className="flex-1 py-3 bg-cyan-50 text-cyan-600 rounded-xl text-xs font-bold border border-cyan-100 hover:bg-cyan-100 flex items-center justify-center gap-2 border-dashed"
                                  >
                                      <Plus size={16} /> Add Topic Note
                                  </button>
                              <div className="flex gap-2">
                                  <button onClick={() => generateDirectCode('NOTES', editingChapterId!)} className="px-4 bg-yellow-400 text-black font-bold py-3 rounded-xl shadow hover:bg-yellow-500 flex items-center justify-center gap-2 md:flex">
                                      <Key size={16} /> Code
                                  </button>
                                  <button onClick={saveChapterContent} className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl shadow hover:bg-blue-700 transition flex items-center justify-center gap-2 md:flex">
                                      <Save size={16} /> Save Changes
                                  </button>
                              </div>
                                  <div className="flex gap-2 mt-2">
                                  <button onClick={() => generateDirectCode('MCQ', editingChapterId!)} className="px-4 bg-yellow-400 text-black font-bold py-3 rounded-xl shadow hover:bg-yellow-500 flex items-center justify-center gap-2 md:flex">
                                          <Key size={16} /> Code
                                      </button>
                                  <button onClick={saveChapterContent} className="flex-1 bg-cyan-600 text-white font-bold py-3 rounded-xl shadow hover:bg-cyan-700 transition flex items-center justify-center gap-2 md:flex">
                                          <Save size={16} /> Save Changes
                                      </button>
                                  </div>
                                  <div className="sticky bottom-0 left-0 w-full p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-50 mt-4 md:static md:bg-transparent md:border-t-0 md:p-0 rounded-b-2xl md:rounded-none shadow-[0_-8px_15px_-3px_rgba(0,0,0,0.1)] md:shadow-none">
                                      <button onClick={saveChapterContent} className="w-full bg-cyan-600 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-cyan-700 transition flex items-center justify-center gap-2 border-2 border-white">
                                          <Save size={18} /> SAVE ALL CHANGES
                                      </button>
                                  </div>
                              </div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}


      {activeTab === 'UNIVERSAL_NOTES' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              {/* Header */}
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Universal Recommended Notes</h3>
              </div>

              {/* Add New Note Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                  {/* FREE NOTES (HTML) */}
                  <div className="bg-orange-50 p-6 rounded-xl border border-orange-200">
                      <h4 className="font-bold text-orange-900 mb-4 flex items-center gap-2">
                          <FileText size={20} /> Add Free Note (HTML)
                      </h4>
                      <div className="space-y-3">
                          <input
                              type="text"
                              id="free-note-title"
                              placeholder="Note Title"
                              className="w-full p-2 border border-slate-200 rounded text-sm font-bold"
                          />
                          <input
                              type="text"
                              id="free-note-topic"
                              placeholder="Topic (e.g. Algebra)"
                              className="w-full p-2 border border-slate-200 rounded text-sm"
                          />
                          <textarea
                              id="free-note-content"
                              placeholder="HTML Content (e.g. <h1>Summary</h1><p>...</p>)"
                              className="w-full h-32 p-2 border border-slate-200 rounded text-sm font-mono"
                          />
                          <button
                              onClick={() => {
                                  const title = (document.getElementById('free-note-title') as HTMLInputElement).value;
                                  const topic = (document.getElementById('free-note-topic') as HTMLInputElement).value;
                                  const content = (document.getElementById('free-note-content') as HTMLTextAreaElement).value;
                                  if(!title || !content) return alert("Title and Content required!");

                                  const newNote = {
                                      id: Date.now(),
                                      title,
                                      topic,
                                      type: 'HTML',
                                      content,
                                      access: 'FREE'
                                  };
                                  setUniversalNotes([...universalNotes, newNote]);
                                  // Clear inputs
                                  (document.getElementById('free-note-title') as HTMLInputElement).value = '';
                                  (document.getElementById('free-note-content') as HTMLTextAreaElement).value = '';
                              }}
                              className="w-full py-2 bg-orange-600 text-white font-bold rounded-lg hover:bg-orange-700"
                          >
                              Add Free Note
                          </button>
                      </div>
                  </div>

                  {/* PREMIUM NOTES (PDF) */}
                  <div className="bg-red-50 p-6 rounded-xl border border-red-200">
                      <h4 className="font-bold text-red-900 mb-4 flex items-center gap-2">
                          <Link size={20} /> Add Premium Note (PDF)
                      </h4>
                      <div className="space-y-3">
                          <input
                              type="text"
                              id="prem-note-title"
                              placeholder="Note Title"
                              className="w-full p-2 border border-slate-200 rounded text-sm font-bold"
                          />
                          <input
                              type="text"
                              id="prem-note-topic"
                              placeholder="Topic (e.g. Geometry)"
                              className="w-full p-2 border border-slate-200 rounded text-sm"
                          />
                          <input
                              type="text"
                              id="prem-note-url"
                              placeholder="PDF URL (e.g. https://...)"
                              className="w-full p-2 border border-slate-200 rounded text-sm text-blue-600"
                          />
                          <button
                              onClick={() => {
                                  const title = (document.getElementById('prem-note-title') as HTMLInputElement).value;
                                  const topic = (document.getElementById('prem-note-topic') as HTMLInputElement).value;
                                  const url = (document.getElementById('prem-note-url') as HTMLInputElement).value;
                                  if(!title || !url) return alert("Title and URL required!");

                                  const newNote = {
                                      id: Date.now(),
                                      title,
                                      topic,
                                      type: 'PDF',
                                      url,
                                      access: 'PREMIUM'
                                  };
                                  setUniversalNotes([...universalNotes, newNote]);
                                  (document.getElementById('prem-note-title') as HTMLInputElement).value = '';
                                  (document.getElementById('prem-note-url') as HTMLInputElement).value = '';
                              }}
                              className="w-full py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700"
                          >
                              Add Premium Note
                          </button>
                      </div>
                  </div>
              </div>

              {/* List of Notes */}
              <div className="space-y-4">
                  <h4 className="font-bold text-slate-800 text-lg border-b pb-2">Manage Current Notes ({universalNotes.length})</h4>
                  {universalNotes.length === 0 && <p className="text-slate-500 italic">No notes added yet.</p>}

                  {universalNotes.map((note, idx) => (
                      <div key={idx} className={`p-4 rounded-xl border flex justify-between items-center ${note.type === 'HTML' ? 'bg-orange-50 border-orange-100' : 'bg-red-50 border-red-100'}`}>
                          <div>
                              <p className="font-bold text-slate-800">{note.title}</p>
                              <div className="flex gap-2 mt-1">
                                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-white border">{note.topic || 'General'}</span>
                                  <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded text-white ${note.type === 'HTML' ? 'bg-orange-500' : 'bg-red-500'}`}>
                                      {note.type} • {note.access}
                                  </span>
                              </div>
                              {note.type === 'PDF' && <a href={note.url} target="_blank" className="text-xs text-blue-600 hover:underline mt-1 block truncate w-full">{note.url}</a>}
                              {note.type === 'HTML' && <p className="text-xs text-slate-600 mt-1 truncate w-full">{note.content.substring(0, 50)}...</p>}
                          </div>
                          <button
                              onClick={() => {
                                  const updated = universalNotes.filter((_, i) => i !== idx);
                                  setUniversalNotes(updated);
                              }}
                              className="p-2 text-red-400 hover:text-red-600 hover:bg-red-100 rounded-lg"
                          >
                              <Trash2 size={18} />
                          </button>
                      </div>
                  ))}
              </div>

              <div className="mt-8 flex justify-end">
                  <button
                      onClick={() => saveUniversalNotes()}
                      className="px-6 py-3 bg-green-600 text-white font-bold rounded-xl shadow-lg hover:bg-green-700 flex items-center gap-2"
                  >
                      <Save size={20} /> Save All Notes
                  </button>
              </div>
          </div>
      )}


      {activeTab === 'WHATSAPP_CONNECT' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-green-800">WhatsApp Connection</h3>
              </div>
              
              <div className="flex flex-col items-center justify-center min-h-[400px] gap-6">
                  <div className={`p-4 rounded-full ${whatsappStatus === 'CONNECTED' ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-500'}`}>
                      <MessageSquare size={48} />
                  </div>
                  
                  <h2 className="text-2xl font-black text-slate-800">
                      {whatsappStatus === 'CONNECTED' ? 'WhatsApp Connected ✅' : 'Scan to Connect'}
                  </h2>

                  {whatsappStatus === 'SCAN_QR' && whatsappQr && (
                      <div className="p-4 bg-white rounded-xl border-2 border-slate-900 shadow-2xl">
                          <QRCode value={whatsappQr} size={256} />
                      </div>
                  )}

                  <p className="text-slate-600 font-medium text-center w-full">
                      {whatsappStatus === 'CONNECTED' 
                          ? "Your admin WhatsApp is linked. You can now send automated updates and respond to student queries directly."
                          : "Open WhatsApp on your phone > Linked Devices > Link a Device > Scan this QR Code."}
                  </p>
                  
                  {whatsappStatus === 'CONNECTED' && (
                      <button 
                        onClick={() => {
                             if(confirm("To disconnect, please use WhatsApp on your phone (Linked Devices -> Log out). The server will detect it automatically.")) {
                                 // Optional: Reset local status if needed, but server sync is better.
                             }
                        }}
                        className="px-6 py-3 bg-red-100 text-red-600 font-bold rounded-xl hover:bg-red-200"
                      >
                          How to Disconnect?
                      </button>
                  )}
              </div>
          </div>
      )}

      {activeTab === 'RECYCLE' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-bottom-4">
              <div className="flex items-center gap-4 mb-6"><button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button><h3 className="text-xl font-black text-slate-800">Recycle Bin (90 Days)</h3></div>
              <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 border-b border-slate-100 text-slate-600"><tr className="uppercase text-xs"><th className="p-4">Item</th><th className="p-4">Type</th><th className="p-4">Deleted</th><th className="p-4 text-right">Actions</th></tr></thead>
                      <tbody className="divide-y divide-slate-50">
                          {recycleBin.length === 0 && <tr><td colSpan={4} className="p-8 text-center text-slate-500">Bin is empty.</td></tr>}
                          {recycleBin.map(item => (
                              <tr key={item.id} className="hover:bg-red-50 transition-colors">
                                  <td className="p-4 font-bold text-slate-700">{item.name}</td>
                                  <td className="p-4"><span className="bg-slate-100 px-2 py-1 rounded text-xs font-bold text-slate-600">{item.type}</span></td>
                                  <td className="p-4 text-xs text-slate-600">{new Date(item.deletedAt).toLocaleDateString()}</td>
                                  <td className="p-4 text-right flex justify-end gap-2">
                                      <button onClick={() => handleRestoreItem(item)} className="p-2 text-green-600 bg-green-50 rounded-lg hover:bg-green-100"><RotateCcw size={16} /></button>
                                      <button onClick={() => handlePermanentDelete(item.id)} className="p-2 text-red-600 bg-red-50 rounded-lg hover:bg-red-100"><X size={16} /></button>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

      {activeTab === 'BLOGGER_HUB' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Blogger Hub (Custom Page)</h3>
              </div>
              
              <div className="space-y-4">
                  <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 mb-4">
                      <p className="text-sm text-orange-800 font-bold">
                          Create your own custom page! Whatever HTML/CSS you write here will be displayed in the app's "Custom Page" section.
                      </p>
                  </div>

                  <div>
                      <label className="text-xs font-bold text-slate-600 uppercase block mb-2">HTML / CSS / JS Code</label>
                      <textarea 
                          value={customBloggerCode}
                          onChange={(e) => setCustomBloggerCode(e.target.value)}
                          placeholder="<h1>Hello World</h1>"
                          className="w-full h-96 p-4 bg-slate-900 text-green-400 font-mono text-sm rounded-xl focus:ring-2 focus:ring-orange-200"
                      />
                  </div>

                  <div className="flex gap-2">
                      <button 
                          onClick={() => {
                              localStorage.setItem('nst_custom_blogger_page', customBloggerCode);
                              if(isFirebaseConnected) {
                                  // Sync to Firebase for Universal Access
                                  set(ref(rtdb, 'custom_blogger_page'), customBloggerCode);
                              }
                              alert("Saved! Students will see this on the Custom Page.");
                          }}
                          className="w-full bg-orange-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-orange-700"
                      >
                          Save Page
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* CROPPER MODAL */}
      {cropImageSrc && (
          <ImageCropper 
              imageSrc={cropImageSrc} 
              onCropComplete={handleCropComplete} 
              onCancel={() => setCropImageSrc(null)} 
          />
      )}

      <CustomAlert 
          isOpen={alertConfig.isOpen} 
          message={alertConfig.message} 
          onClose={() => setAlertConfig({...alertConfig, isOpen: false})} 
      />

      {codeModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
              <div className="bg-white p-6 rounded-2xl w-full shadow-2xl">
                  <h3 className="text-xl font-black text-slate-800 mb-2 flex items-center gap-2">
                      <Key className="text-yellow-500" /> Generate Code
                  </h3>
                  <p className="text-xs text-slate-600 mb-6">
                      Create a unique redeem code for <b>{codeModal.type}</b> (ID: {codeModal.contentId}).
                  </p>

                  <div className="space-y-4">
                      <div>
                          <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Validity Duration (Hours)</label>
                          <input
                              type="number"
                              value={codeDuration}
                              onChange={e => setCodeDuration(Number(e.target.value))}
                              className="w-full p-3 border border-slate-200 rounded-xl font-bold text-slate-800"
                              min="1"
                          />
                          <div className="flex gap-2 mt-2">
                              <button onClick={() => setCodeDuration(1)} className="px-2 py-1 bg-slate-100 rounded text-[10px] font-bold">1h</button>
                              <button onClick={() => setCodeDuration(24)} className="px-2 py-1 bg-slate-100 rounded text-[10px] font-bold">24h</button>
                              <button onClick={() => setCodeDuration(168)} className="px-2 py-1 bg-slate-100 rounded text-[10px] font-bold">7d</button>
                              <button onClick={() => setCodeDuration(720)} className="px-2 py-1 bg-slate-100 rounded text-[10px] font-bold">30d</button>
                          </div>
                      </div>

                      <div>
                          <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Max Users (Usage Limit)</label>
                          <input
                              type="number"
                              value={codeMaxUses}
                              onChange={e => setCodeMaxUses(Number(e.target.value))}
                              className="w-full p-3 border border-slate-200 rounded-xl font-bold text-slate-800"
                              min="1"
                          />
                      </div>
                  </div>

                  <div className="flex gap-3 mt-8">
                      <button onClick={() => setCodeModal(null)} className="flex-1 py-3 text-slate-600 font-bold hover:bg-slate-50 rounded-xl">Cancel</button>
                      <button onClick={handleGenerateCodeConfirm} className="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg hover:bg-blue-700">Generate</button>
                  </div>
              </div>
          </div>
      )}
      
      {showChat && <UniversalChat user={{id: 'ADMIN', name: 'Admin', role: 'ADMIN'} as any} onClose={() => setShowChat(false)} isAdmin={true} />}

      {/* SUB-ADMIN REPORT MODAL */}
      {viewingSubAdminReport && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
              <div className="bg-white p-6 rounded-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto animate-in fade-in">
                  <div className="flex justify-between items-center mb-6 border-b pb-4">
                      <div>
                          <h3 className="text-xl font-black text-slate-800">Sub-Admin Sales Report</h3>
                          <p className="text-sm text-slate-600">
                              Activity for: <span className="font-bold text-indigo-600">{users.find(u => u.id === viewingSubAdminReport)?.name}</span>
                          </p>
                      </div>
                      <button onClick={() => setViewingSubAdminReport(null)} className="p-2 hover:bg-slate-100 rounded-full">
                          <X size={24} className="text-slate-500" />
                      </button>
                  </div>

                  {(() => {
                      // Calculate Report Data on Render
                      const report = users.reduce((acc, u) => {
                          const userSales = (u.subscriptionHistory || []).filter(h => h.grantedBy === viewingSubAdminReport);
                          userSales.forEach(sale => {
                              acc.items.push({
                                  studentName: u.name,
                                  studentId: u.id,
                                  ...sale
                              });
                              acc.totalValue += (sale.originalPrice || 0);
                              acc.totalCollected += (sale.price || 0);
                          });
                          return acc;
                      }, { items: [] as any[], totalValue: 0, totalCollected: 0 });

                      const sortedItems = report.items.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());

                      return (
                          <div className="space-y-6">
                              <div className="grid grid-cols-3 gap-4">
                                  <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl">
                                      <p className="text-xs font-bold text-indigo-600 uppercase">Total Grants</p>
                                      <p className="text-2xl font-black text-indigo-900">{report.items.length}</p>
                                  </div>
                                  <div className="p-4 bg-green-50 border border-green-100 rounded-xl">
                                      <p className="text-xs font-bold text-green-600 uppercase">Total Value</p>
                                      <p className="text-2xl font-black text-green-900">₹{report.totalValue}</p>
                                  </div>
                                  <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl">
                                      <p className="text-xs font-bold text-blue-600 uppercase">Paid Collected</p>
                                      <p className="text-2xl font-black text-blue-900">₹{report.totalCollected}</p>
                                  </div>
                              </div>

                              <div>
                                  <h4 className="font-bold text-slate-800 mb-3">Transaction History</h4>
                                  <div className="max-h-60 overflow-y-auto border rounded-xl">
                                      <table className="w-full text-left text-xs">
                                          <thead className="bg-slate-50 font-bold text-slate-600 uppercase">
                                              <tr>
                                                  <th className="p-3">Date</th>
                                                  <th className="p-3">Student</th>
                                                  <th className="p-3">Plan</th>
                                                  <th className="p-3 text-right">Value</th>
                                              </tr>
                                          </thead>
                                          <tbody className="divide-y divide-slate-100">
                                              {sortedItems.length === 0 && (
                                                  <tr><td colSpan={4} className="p-4 text-center text-slate-500">No subscriptions granted yet.</td></tr>
                                              )}
                                              {sortedItems.map((item, idx) => (
                                                  <tr key={idx} className="hover:bg-slate-50">
                                                      <td className="p-3 text-slate-600">
                                                          {new Date(item.startDate).toLocaleDateString()}
                                                          <div className="text-[10px]">{new Date(item.startDate).toLocaleTimeString()}</div>
                                                      </td>
                                                      <td className="p-3 font-bold text-slate-700">
                                                          {item.studentName}
                                                          <div className="text-[9px] font-normal text-slate-500">{item.studentId}</div>
                                                      </td>
                                                      <td className="p-3">
                                                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.isFree ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700'}`}>
                                                              {item.isFree ? 'FREE GRANT' : 'PAID'}
                                                          </span>
                                                          <div className="mt-1 font-bold text-slate-600">{item.tier} • {item.level}</div>
                                                      </td>
                                                      <td className="p-3 text-right font-bold text-slate-800">₹{item.originalPrice}</td>
                                                  </tr>
                                              ))}
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      );
                  })()}
                  
                  <div className="mt-6 text-right">
                       <button onClick={() => setViewingSubAdminReport(null)} className="px-6 py-2 bg-slate-800 text-white font-bold rounded-lg hover:bg-slate-900">Close Report</button>
                  </div>
              </div>
          </div>
      )}

      {/* --- FEATURE CONTROL MATRIX (Advanced Settings) --- */}
      {activeTab === 'POWER_MANAGER' && (
          <div className="bg-white rounded-3xl shadow-sm border border-slate-200">
              <div className="p-4 border-b">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200 text-slate-600"><ArrowLeft size={20} /></button>
                  <span className="ml-4 font-bold text-slate-600">Advanced Settings (Power Manager)</span>
              </div>
              <AdminPowerManager
                  settings={localSettings}
                  onUpdate={(newSettings) => {
                      setLocalSettings(newSettings);
                      handleSaveSettings(newSettings);
                  }}
              />
          </div>
      )}

      {/* --- SYLLABUS MANAGER (NEW AUDIT TOOL) --- */}
      {activeTab === 'SYLLABUS_MANAGER' && (
          <div className="bg-white rounded-3xl shadow-sm border border-slate-200">
              <div className="p-4 border-b flex items-center gap-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200 text-slate-600"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Syllabus Audit Manager</h3>
              </div>
              <div className="p-6">
                  <SyllabusManager board={adminBoardContext} />
              </div>
          </div>
      )}

      {/* --- DOCUMENTATION TAB --- */}
      {activeTab === 'DOCUMENTATION' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">System Documentation</h3>
              </div>
              <DocumentationTab />
          </div>
      )}

            {/* --- REVISION LOGIC CONFIGURATION --- */}
      {activeTab === 'REVISION_LOGIC' && (
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right mb-8">
          <div className="flex items-center gap-4 mb-6 border-b pb-4">
              <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
              <h3 className="text-xl font-black text-slate-800">Revision Engine Config</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Strong Topic (Min %)</label>
              <input
                  type="number"
                  value={localSettings.revisionConfig?.thresholds.strong ?? 80}
                  onChange={(e) => setLocalSettings({
                      ...localSettings,
                      revisionConfig: {
                          ...localSettings.revisionConfig!,
                          thresholds: {
                              ...localSettings.revisionConfig?.thresholds!,
                              strong: parseInt(e.target.value) || 0
                          }
                      } as any
                  })}
                  className="w-full p-2 border rounded-lg font-bold"
              />
              <p className="text-[10px] text-slate-500 mt-1">Scores above this are "Strong"</p>
          </div>
          <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Average Topic (Min %)</label>
              <input
                  type="number"
                  value={localSettings.revisionConfig?.thresholds.average ?? 50}
                  onChange={(e) => setLocalSettings({
                      ...localSettings,
                      revisionConfig: {
                          ...localSettings.revisionConfig!,
                          thresholds: {
                              ...localSettings.revisionConfig?.thresholds!,
                              average: parseInt(e.target.value) || 0
                          }
                      } as any
                  })}
                  className="w-full p-2 border rounded-lg font-bold"
              />
              <p className="text-[10px] text-slate-500 mt-1">Scores between this and Strong are "Average"</p>
          </div>
          <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Mastery Score (Min %)</label>
              <input
                  type="number"
                  value={localSettings.revisionConfig?.thresholds.mastery ?? 80}
                  onChange={(e) => setLocalSettings({
                      ...localSettings,
                      revisionConfig: {
                          ...localSettings.revisionConfig!,
                          thresholds: {
                              ...localSettings.revisionConfig?.thresholds!,
                              mastery: parseInt(e.target.value) || 0
                          }
                      } as any
                  })}
                  className="w-full p-2 border rounded-lg font-bold"
              />
              <p className="text-[10px] text-slate-500 mt-1">Score needed to count towards Mastery</p>
          </div>
          <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Mastery Count</label>
              <input
                  type="number"
                  value={localSettings.revisionConfig?.mastery.requiredCount ?? 2}
                  onChange={(e) => setLocalSettings({
                      ...localSettings,
                      revisionConfig: {
                          ...localSettings.revisionConfig!,
                          mastery: {
                              requiredCount: parseInt(e.target.value) || 1
                          }
                      } as any
                  })}
                  className="w-full p-2 border rounded-lg font-bold"
              />
              <p className="text-[10px] text-slate-500 mt-1">How many times user must score high to Master a topic</p>
          </div>
      </div>

      {/* TIME INTERVALS */}
      <div className="space-y-6">
          {['weak', 'average', 'strong', 'mastered'].map(status => {
              // Helper to get seconds safely
              const getSeconds = (type: 'revision' | 'mcq') => {
                  // @ts-ignore
                  return localSettings.revisionConfig?.intervals?.[status]?.[type] || 0;
              };

              // Helper to update seconds
              const updateSeconds = (type: 'revision' | 'mcq', totalSeconds: number) => {
                      const newIntervals = {
                          weak: { revision: 86400, mcq: 259200 },
                          average: { revision: 259200, mcq: 432000 },
                          strong: { revision: 604800, mcq: 864000 },
                          mastered: { revision: 2592000, mcq: 864000 },
                          ...(localSettings.revisionConfig?.intervals || {})
                      };
                      // @ts-ignore
                      newIntervals[status] = {
                          // @ts-ignore
                          ...newIntervals[status],
                          [type]: totalSeconds
                      };

                      setLocalSettings({
                          ...localSettings,
                          revisionConfig: {
                              thresholds: localSettings.revisionConfig?.thresholds || { strong: 80, average: 50, mastery: 80 },
                              mastery: localSettings.revisionConfig?.mastery || { requiredCount: 2 },
                              intervals: newIntervals
                          }
                      });
              };

              const renderTimeInput = (label: string, type: 'revision' | 'mcq', color: string) => {
                  const totalSeconds = getSeconds(type);
                  const d = Math.floor(totalSeconds / (24 * 3600));
                  const h = Math.floor((totalSeconds % (24 * 3600)) / 3600);
                  const m = Math.floor((totalSeconds % 3600) / 60);

                  return (
                      <div className={`p-3 rounded-xl border ${color} bg-white flex flex-col gap-2`}>
                          <span className="text-[10px] font-bold uppercase">{label}</span>
                          <div className="flex items-center gap-2">
                              <input type="number" value={d} onChange={e => updateSeconds(type, (parseInt(e.target.value||'0')*86400) + h*3600 + m*60)} className="w-12 p-1 border rounded text-xs font-bold text-center" /> d
                              <input type="number" value={h} onChange={e => updateSeconds(type, d*86400 + (parseInt(e.target.value||'0')*3600) + m*60)} className="w-12 p-1 border rounded text-xs font-bold text-center" /> h
                          </div>
                      </div>
                  );
              };

              return (
                  <div key={status} className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <h4 className="font-bold text-slate-700 capitalize mb-3">{status} Status Topic</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {renderTimeInput('Next Revision Note Date', 'revision', 'border-blue-200 text-blue-700')}
                          {renderTimeInput('Next MCQ Practice Date', 'mcq', 'border-purple-200 text-purple-700')}
                      </div>
                  </div>
              );
          })}
      </div>
      <div className="mt-8 flex justify-end">
          <button onClick={handleSaveSettings} className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-colors">
              <Save size={20} /> Save Configuration
          </button>
      </div>
      </div>
      )}

      {activeTab === 'NSTA_CONTROL' && (
          <NstaFeatureManager settings={localSettings} onUpdateSettings={setLocalSettings} onBack={() => setActiveTab('DASHBOARD')} />
      )}

            {/* --- VISIBILITY CONTROL (Legacy Restored) --- */}
      {activeTab === 'CONFIG_VISIBILITY' && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 animate-in slide-in-from-right">
              <div className="flex items-center gap-4 mb-6 border-b pb-4">
                  <button onClick={() => setActiveTab('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-black text-slate-800">Student Dashboard Visibility</h3>
              </div>

              <div className="mb-6 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <h4 className="font-bold text-slate-800 mb-2">Configure Tier Visibility</h4>
                  <p className="text-xs text-slate-600 mb-4">Select which tiers can see and access specific sections of the app.</p>

                  <div className="space-y-4">
                      {ALL_FEATURES.filter(f => !f.adminVisible).map(feature => {
                          const config = localSettings.featureConfig?.[feature.id] || { visible: true, allowedTiers: ['FREE', 'BASIC', 'ULTRA'] };
                          const isAllowed = (tier: string) => config.allowedTiers.includes(tier);

                          return (
                              <div key={feature.id} className="flex flex-col md:flex-row md:items-center justify-between bg-white p-3 rounded-lg border border-slate-200 shadow-sm gap-4">
                                  <div className="flex items-center gap-2">
                                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
                                          <Eye size={14} />
                                      </div>
                                      <div>
                                          <p className="font-bold text-sm text-slate-800">{feature.label}</p>
                                          <p className="text-[10px] text-slate-500 font-mono">{feature.id}</p>
                                      </div>
                                  </div>

                                  <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded-lg border border-slate-200">
                                      <button
                                          onClick={() => {
                                              const newTiers = isAllowed('FREE') ? config.allowedTiers.filter(t => t !== 'FREE') : [...config.allowedTiers, 'FREE'];
                                              setLocalSettings({
                                                  ...localSettings,
                                                  featureConfig: {
                                                      ...localSettings.featureConfig,
                                                      [feature.id]: { ...config, allowedTiers: newTiers }
                                                  }
                                              });
                                          }}
                                          className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${isAllowed('FREE') ? 'bg-green-100 text-green-700' : 'bg-white text-slate-500'}`}
                                      >
                                          FREE
                                      </button>
                                      <button
                                          onClick={() => {
                                              const newTiers = isAllowed('BASIC') ? config.allowedTiers.filter(t => t !== 'BASIC') : [...config.allowedTiers, 'BASIC'];
                                              setLocalSettings({
                                                  ...localSettings,
                                                  featureConfig: {
                                                      ...localSettings.featureConfig,
                                                      [feature.id]: { ...config, allowedTiers: newTiers }
                                                  }
                                              });
                                          }}
                                          className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${isAllowed('BASIC') ? 'bg-blue-100 text-blue-700' : 'bg-white text-slate-500'}`}
                                      >
                                          BASIC
                                      </button>
                                      <button
                                          onClick={() => {
                                              const newTiers = isAllowed('ULTRA') ? config.allowedTiers.filter(t => t !== 'ULTRA') : [...config.allowedTiers, 'ULTRA'];
                                              setLocalSettings({
                                                  ...localSettings,
                                                  featureConfig: {
                                                      ...localSettings.featureConfig,
                                                      [feature.id]: { ...config, allowedTiers: newTiers }
                                                  }
                                              });
                                          }}
                                          className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${isAllowed('ULTRA') ? 'bg-purple-100 text-purple-700' : 'bg-white text-slate-500'}`}
                                      >
                                          ULTRA
                                      </button>
                                  </div>
                              </div>
                          );
                      })}
                  </div>
              </div>

              <div className="mt-8 flex justify-end">
                  <button
                      onClick={() => handleSaveSettings()}
                      disabled={isSettingsSaving}
                      className={`bg-slate-800 text-white px-8 py-3 rounded-xl font-bold shadow-xl hover:bg-slate-900 transition-all flex items-center gap-2 ${isSettingsSaving ? 'opacity-70 cursor-wait' : ''}`}
                  >
                      {isSettingsSaving ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
                      {isSettingsSaving ? 'Saving...' : 'Save Visibility Settings'}
                  </button>
              </div>
          </div>
      )}

      {/* MOVE CHAPTER MODAL */}
      {movingChapter && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
              <div className="bg-white rounded-3xl p-8 w-full shadow-2xl">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-black text-slate-800">Move Chapter</h3>
                      <button onClick={() => setMovingChapter(null)} className="p-2 text-slate-400 hover:bg-slate-100 rounded-full"><X size={20} /></button>
                  </div>

                  <div className="bg-indigo-50 p-4 rounded-2xl mb-6 border border-indigo-100">
                      <p className="text-sm text-indigo-900 font-medium">You are moving:</p>
                      <p className="text-lg font-black text-indigo-700">{movingChapter.chapter.title}</p>
                      <p className="text-xs text-indigo-500 mt-1">From: {selClass} - {selSubject?.name}</p>
                  </div>

                  <div className="space-y-4 mb-6">
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Target Class</label>
                          <select value={moveTargetClass} onChange={e => setMoveTargetClass(e.target.value as ClassLevel)} className="w-full p-3 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 bg-slate-50">
                              {['6','7','8','9','10','11','12','COMPETITION'].map(c => <option key={c} value={c}>Class {c}</option>)}
                          </select>
                      </div>

                      {['11', '12'].includes(moveTargetClass) && (
                          <div>
                              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Target Stream</label>
                              <select value={moveTargetStream || 'Science'} onChange={e => setMoveTargetStream(e.target.value as Stream)} className="w-full p-3 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 bg-slate-50">
                                  {['Science', 'Commerce', 'Arts'].map(s => <option key={s} value={s}>{s}</option>)}
                              </select>
                          </div>
                      )}

                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Target Subject</label>
                          <select value={moveTargetSubject?.name || ''} onChange={e => {
                              const list = getSubjectsList(moveTargetBoard, moveTargetClass, moveTargetStream);
                              const sub = list.find(s => s.name === e.target.value) || list[0];
                              setMoveTargetSubject(sub);
                          }} className="w-full p-3 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 bg-slate-50">
                              <option value="">-- Select Subject --</option>
                              {getSubjectsList(moveTargetBoard, moveTargetClass, moveTargetStream).map(s => (
                                  <option key={s.name} value={s.name}>{s.name}</option>
                              ))}
                          </select>
                      </div>
                  </div>

                  <div className="flex gap-3">
                      <button onClick={() => setMovingChapter(null)} className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 hover:bg-slate-200 rounded-xl">Cancel</button>
                      <button onClick={handleConfirmMoveChapter} disabled={isMoving || !moveTargetSubject} className="flex-1 py-3 text-white font-bold bg-indigo-600 hover:bg-indigo-700 rounded-xl flex items-center justify-center gap-2 disabled:opacity-50">
                          {isMoving ? <Loader2 size={16} className="animate-spin" /> : <ArrowRight size={16} />}
                          {isMoving ? 'Moving...' : 'Confirm Move'}
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
